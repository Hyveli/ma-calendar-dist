<?php
/**
 * Branding Settings - Logo and Email Templates Admin Page for WP Booking Calendar
 */

if (!defined('ABSPATH')) {
    exit;
}

class WPBC_Branding_Settings {

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'add_settings_page'], 20);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_admin_scripts']);
    }

    public static function add_settings_page() {
        add_submenu_page(
            'wpbc-bookings',  // Correct parent menu slug
            'Email Branding',
            'Email Branding',
            'manage_options',
            'wpbc-branding-settings',
            [__CLASS__, 'render_settings_page']
        );
    }

    public static function register_settings() {
        // Logo settings (reuse existing SEC options)
        register_setting('wpbc_branding_settings', 'sec_logo_url');
        register_setting('wpbc_branding_settings', 'sec_logo_png_fallback_url', [
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => '',
        ]);

        // Email sender settings (reuse existing SEC options)
        register_setting('wpbc_branding_settings', 'sec_email_from_name', [
            'default' => get_bloginfo('name')
        ]);
        register_setting('wpbc_branding_settings', 'sec_email_from_email', [
            'default' => get_option('admin_email')
        ]);

        // Email styling (reuse existing SEC options)
        register_setting('wpbc_branding_settings', 'sec_email_header_gradient_start', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_hex_color',
            'default' => '#3b82f6',
        ]);
        register_setting('wpbc_branding_settings', 'sec_email_header_gradient_end', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_hex_color',
            'default' => '#0ea5e9',
        ]);

        // Email footer settings (reuse existing SEC options)
        register_setting('wpbc_branding_settings', 'sec_email_legal_name', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ]);
        register_setting('wpbc_branding_settings', 'sec_email_physical_address', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ]);
        register_setting('wpbc_branding_settings', 'sec_email_footer_template', [
            'type' => 'string',
            'sanitize_callback' => 'wp_kses_post',
            'default' => '© {{year}} {{company_name}}. All rights reserved.<br>{{legal_name}}<br>{{physical_address}}',
        ]);

        // Email-specific From addresses for booking calendar emails
        register_setting('wpbc_branding_settings', 'wpbc_confirmation_from_email', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default' => '',
        ]);
        register_setting('wpbc_branding_settings', 'wpbc_cancellation_from_email', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default' => '',
        ]);
        register_setting('wpbc_branding_settings', 'wpbc_reschedule_from_email', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default' => '',
        ]);
        register_setting('wpbc_branding_settings', 'wpbc_reminder_from_email', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default' => '',
        ]);
        register_setting('wpbc_branding_settings', 'wpbc_admin_notification_from_email', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default' => '',
        ]);

        // Confirmation email template
        register_setting('wpbc_branding_settings', 'wpbc_confirmation_email_subject', [
            'default' => 'Appointment Confirmed – {Day, Month Date} at {Time}'
        ]);
        register_setting('wpbc_branding_settings', 'wpbc_confirmation_email_body', [
            'default' => self::get_default_confirmation_template()
        ]);

        // Cancellation email template
        register_setting('wpbc_branding_settings', 'wpbc_cancellation_email_subject', [
            'default' => 'Appointment Canceled – {Day, Month Date} at {Time}'
        ]);
        register_setting('wpbc_branding_settings', 'wpbc_cancellation_email_body', [
            'default' => self::get_default_cancellation_template()
        ]);

        // Reschedule email template
        register_setting('wpbc_branding_settings', 'wpbc_reschedule_email_subject', [
            'default' => 'Appointment Rescheduled – New Date: {Day, Month Date} at {Time}'
        ]);
        register_setting('wpbc_branding_settings', 'wpbc_reschedule_email_body', [
            'default' => self::get_default_reschedule_template()
        ]);

        // Reminder 24h email template
        register_setting('wpbc_branding_settings', 'wpbc_reminder_24h_email_subject', [
            'default' => 'Reminder: Your appointment is tomorrow at {Time}'
        ]);
        register_setting('wpbc_branding_settings', 'wpbc_reminder_24h_email_body', [
            'default' => self::get_default_reminder_24h_template()
        ]);

        // Reminder 1h email template
        register_setting('wpbc_branding_settings', 'wpbc_reminder_1h_email_subject', [
            'default' => 'Reminder: Your appointment is in 1 hour – {Time} today'
        ]);
        register_setting('wpbc_branding_settings', 'wpbc_reminder_1h_email_body', [
            'default' => self::get_default_reminder_1h_template()
        ]);

        // Admin notification email
        register_setting('wpbc_branding_settings', 'wpbc_admin_notification_subject', [
            'default' => '[New Appointment] {Name} – {Date} at {Time}'
        ]);
    }

    public static function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'wpbc-branding-settings') === false) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_style('wpbc-branding-admin', plugins_url('../assets/css/admin-branding.css', __FILE__), [], '1.0.0');
        wp_enqueue_script('wpbc-branding-admin', plugins_url('../assets/js/admin-branding.js', __FILE__), ['jquery'], '1.0.0', true);

        wp_localize_script('wpbc-branding-admin', 'wpbcBrandingData', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wpbc_branding_nonce'),
            'default_test_email' => wp_get_current_user()->user_email
        ]);
    }

    public static function render_settings_page() {
        $logo_url = get_option('sec_logo_url', '');
        $logo_png_fallback_url = get_option('sec_logo_png_fallback_url', '');
        $from_name = get_option('sec_email_from_name', get_bloginfo('name'));
        $from_email = get_option('sec_email_from_email', get_option('admin_email'));
        $header_gradient_start = sanitize_hex_color(get_option('sec_email_header_gradient_start', '#3b82f6')) ?: '#3b82f6';
        $header_gradient_end = sanitize_hex_color(get_option('sec_email_header_gradient_end', '#0ea5e9')) ?: '#0ea5e9';

        $confirmation_subject = get_option('wpbc_confirmation_email_subject', 'Appointment Confirmed – {Day, Month Date} at {Time}');
        $confirmation_body = get_option('wpbc_confirmation_email_body', self::get_default_confirmation_template());

        $cancellation_subject = get_option('wpbc_cancellation_email_subject', 'Appointment Canceled – {Day, Month Date} at {Time}');
        $cancellation_body = get_option('wpbc_cancellation_email_body', self::get_default_cancellation_template());

        $reschedule_subject = get_option('wpbc_reschedule_email_subject', 'Appointment Rescheduled – New Date: {Day, Month Date} at {Time}');
        $reschedule_body = get_option('wpbc_reschedule_email_body', self::get_default_reschedule_template());

        $reminder_24h_subject = get_option('wpbc_reminder_24h_email_subject', 'Reminder: Your appointment is tomorrow at {Time}');
        $reminder_24h_body = get_option('wpbc_reminder_24h_email_body', self::get_default_reminder_24h_template());

        $reminder_1h_subject = get_option('wpbc_reminder_1h_email_subject', 'Reminder: Your appointment is in 1 hour – {Time} today');
        $reminder_1h_body = get_option('wpbc_reminder_1h_email_body', self::get_default_reminder_1h_template());

        $admin_notification_subject = get_option('wpbc_admin_notification_subject', '[New Appointment] {Name} – {Date} at {Time}');
        ?>
        <div class="wrap wpbc-branding-wrap">
            <h1>Email Branding Settings</h1>
            <p class="wpbc-branding-subtitle">Customize your logo and email templates for a consistent brand experience.</p>

            <form method="post" action="options.php" class="wpbc-branding-form">
                <?php settings_fields('wpbc_branding_settings'); ?>

                <!-- Logo Section -->
                <div class="wpbc-branding-card">
                    <h2>Company Logo</h2>
                    <p class="description">Upload your logo to appear in emails and admin pages.</p>

                    <div class="wpbc-logo-upload-area">
                        <?php if ($logo_url): ?>
                            <div class="wpbc-logo-preview">
                                <img src="<?php echo esc_url($logo_url); ?>" alt="Company Logo">
                                <button type="button" class="button wpbc-remove-logo">Remove Logo</button>
                            </div>
                        <?php else: ?>
                            <div class="wpbc-logo-placeholder">
                                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                                    <circle cx="8.5" cy="8.5" r="1.5"/>
                                    <polyline points="21 15 16 10 5 21"/>
                                </svg>
                                <p>No logo uploaded</p>
                            </div>
                        <?php endif; ?>
                        <button type="button" class="button button-primary wpbc-upload-logo">
                            <?php echo $logo_url ? 'Change Logo' : 'Upload Logo'; ?>
                        </button>
                        <input type="hidden" name="sec_logo_url" id="sec_logo_url" value="<?php echo esc_attr($logo_url); ?>">
                    </div>
                    <div style="margin-top:14px;">
                        <label for="sec_logo_png_fallback_url" style="font-weight:600;">PNG Fallback Logo (for Email/PDF)</label>
                        <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin-top:6px;">
                            <input type="url" name="sec_logo_png_fallback_url" id="sec_logo_png_fallback_url"
                                   value="<?php echo esc_attr($logo_png_fallback_url); ?>" class="regular-text"
                                   placeholder="https://.../logo-fallback.png">
                            <button type="button" class="button wpbc-upload-logo-png-fallback">Upload PNG Fallback</button>
                        </div>
                        <p class="description">Use this when your main logo is SVG. Email clients and PDF rendering are most reliable with PNG.</p>
                    </div>
                </div>

                <!-- Email Sender Settings -->
                <div class="wpbc-branding-card">
                    <h2>Email Sender Information</h2>
                    <p class="description">This will appear in the "From" field of all emails.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_email_from_name">From Name</label></th>
                            <td>
                                <input type="text" name="sec_email_from_name" id="sec_email_from_name"
                                       value="<?php echo esc_attr($from_name); ?>" class="regular-text">
                                <p class="description">e.g., "MarketingAid Support"</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_email_from_email">From Email</label></th>
                            <td>
                                <input type="email" name="sec_email_from_email" id="sec_email_from_email"
                                       value="<?php echo esc_attr($from_email); ?>" class="regular-text">
                                <p class="description">Must be a verified email address.</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Email-Specific From Addresses -->
                <div class="wpbc-branding-card">
                    <h2>Email-Specific From Addresses (Aliases)</h2>
                    <p class="description">Use different email addresses for different appointment email types. Leave blank to use the default "From Email" above.</p>
                    <p class="description" style="background:#f0f9ff; border-left:3px solid #0ea5e9; padding:10px; margin-top:10px;">
                        <strong>Tip:</strong> If using Google Workspace with WP Mail SMTP, authenticate with your primary account (e.g., hello@yourdomain.com)
                        and use these aliases for sending. Make sure aliases are set up in Google Workspace Admin.
                    </p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="wpbc_confirmation_from_email">Confirmation Emails</label></th>
                            <td>
                                <input type="email" name="wpbc_confirmation_from_email" id="wpbc_confirmation_from_email"
                                       value="<?php echo esc_attr(get_option('wpbc_confirmation_from_email', '')); ?>" class="regular-text"
                                       placeholder="appointments@yourdomain.com">
                                <p class="description">From address for appointment confirmation emails</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="wpbc_cancellation_from_email">Cancellation Emails</label></th>
                            <td>
                                <input type="email" name="wpbc_cancellation_from_email" id="wpbc_cancellation_from_email"
                                       value="<?php echo esc_attr(get_option('wpbc_cancellation_from_email', '')); ?>" class="regular-text"
                                       placeholder="appointments@yourdomain.com">
                                <p class="description">From address for appointment cancellation emails</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="wpbc_reschedule_from_email">Reschedule Emails</label></th>
                            <td>
                                <input type="email" name="wpbc_reschedule_from_email" id="wpbc_reschedule_from_email"
                                       value="<?php echo esc_attr(get_option('wpbc_reschedule_from_email', '')); ?>" class="regular-text"
                                       placeholder="appointments@yourdomain.com">
                                <p class="description">From address for appointment reschedule emails</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="wpbc_reminder_from_email">Reminder Emails</label></th>
                            <td>
                                <input type="email" name="wpbc_reminder_from_email" id="wpbc_reminder_from_email"
                                       value="<?php echo esc_attr(get_option('wpbc_reminder_from_email', '')); ?>" class="regular-text"
                                       placeholder="reminders@yourdomain.com">
                                <p class="description">From address for appointment reminder emails (24h and 1h)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="wpbc_admin_notification_from_email">Admin Notification Emails</label></th>
                            <td>
                                <input type="email" name="wpbc_admin_notification_from_email" id="wpbc_admin_notification_from_email"
                                       value="<?php echo esc_attr(get_option('wpbc_admin_notification_from_email', '')); ?>" class="regular-text"
                                       placeholder="alerts@yourdomain.com">
                                <p class="description">From address for internal admin notifications about new appointments</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Email Styling Settings -->
                <div class="wpbc-branding-card">
                    <h2>Email Styling</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_email_header_gradient_start">Header Gradient</label></th>
                            <td>
                                <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                                    <label for="sec_email_header_gradient_start" style="display:flex; align-items:center; gap:6px;">
                                        Start
                                        <input type="color" id="sec_email_header_gradient_start_picker" value="<?php echo esc_attr($header_gradient_start); ?>">
                                        <input type="text" name="sec_email_header_gradient_start" id="sec_email_header_gradient_start"
                                               value="<?php echo esc_attr($header_gradient_start); ?>" class="small-text" placeholder="#3b82f6">
                                    </label>
                                    <label for="sec_email_header_gradient_end" style="display:flex; align-items:center; gap:6px;">
                                        End
                                        <input type="color" id="sec_email_header_gradient_end_picker" value="<?php echo esc_attr($header_gradient_end); ?>">
                                        <input type="text" name="sec_email_header_gradient_end" id="sec_email_header_gradient_end"
                                               value="<?php echo esc_attr($header_gradient_end); ?>" class="small-text" placeholder="#0ea5e9">
                                    </label>
                                </div>
                                <p class="description">Controls the email header gradient behind your logo.</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Confirmation Email Template -->
                <div class="wpbc-branding-card">
                    <h2>Confirmation Email</h2>
                    <p class="description">Sent when an appointment is successfully booked.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="wpbc_confirmation_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="wpbc_confirmation_email_subject" id="wpbc_confirmation_email_subject"
                                       value="<?php echo esc_attr($confirmation_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="wpbc_confirmation_email_body">Email Body</label></th>
                            <td>
                                <textarea name="wpbc_confirmation_email_body" id="wpbc_confirmation_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($confirmation_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{date}}, {{time}}, {{calendar_links}}, {{manage_booking_button}}
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Cancellation Email Template -->
                <div class="wpbc-branding-card">
                    <h2>Cancellation Email</h2>
                    <p class="description">Sent when an appointment is canceled.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="wpbc_cancellation_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="wpbc_cancellation_email_subject" id="wpbc_cancellation_email_subject"
                                       value="<?php echo esc_attr($cancellation_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="wpbc_cancellation_email_body">Email Body</label></th>
                            <td>
                                <textarea name="wpbc_cancellation_email_body" id="wpbc_cancellation_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($cancellation_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{date}}, {{time}}
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Reschedule Email Template -->
                <div class="wpbc-branding-card">
                    <h2>Reschedule Email</h2>
                    <p class="description">Sent when an appointment is rescheduled to a new date/time.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="wpbc_reschedule_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="wpbc_reschedule_email_subject" id="wpbc_reschedule_email_subject"
                                       value="<?php echo esc_attr($reschedule_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="wpbc_reschedule_email_body">Email Body</label></th>
                            <td>
                                <textarea name="wpbc_reschedule_email_body" id="wpbc_reschedule_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($reschedule_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{old_date}}, {{old_time}}, {{new_date}}, {{new_time}}, {{calendar_links}}, {{manage_booking_button}}
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Reminder 24h Email Template -->
                <div class="wpbc-branding-card">
                    <h2>24-Hour Reminder Email</h2>
                    <p class="description">Sent 24 hours before the scheduled appointment.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="wpbc_reminder_24h_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="wpbc_reminder_24h_email_subject" id="wpbc_reminder_24h_email_subject"
                                       value="<?php echo esc_attr($reminder_24h_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="wpbc_reminder_24h_email_body">Email Body</label></th>
                            <td>
                                <textarea name="wpbc_reminder_24h_email_body" id="wpbc_reminder_24h_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($reminder_24h_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{date}}, {{time}}, {{calendar_links}}, {{manage_booking_button}}
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Reminder 1h Email Template -->
                <div class="wpbc-branding-card">
                    <h2>1-Hour Reminder Email</h2>
                    <p class="description">Sent 1 hour before the scheduled appointment.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="wpbc_reminder_1h_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="wpbc_reminder_1h_email_subject" id="wpbc_reminder_1h_email_subject"
                                       value="<?php echo esc_attr($reminder_1h_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="wpbc_reminder_1h_email_body">Email Body</label></th>
                            <td>
                                <textarea name="wpbc_reminder_1h_email_body" id="wpbc_reminder_1h_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($reminder_1h_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{date}}, {{time}}, {{calendar_links}}, {{manage_booking_button}}
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Admin Notification Email -->
                <div class="wpbc-branding-card">
                    <h2>Admin Notification Email</h2>
                    <p class="description">Sent to site admin when a new appointment is created.</p>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="wpbc_admin_notification_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="wpbc_admin_notification_subject" id="wpbc_admin_notification_subject"
                                       value="<?php echo esc_attr($admin_notification_subject); ?>" class="large-text">
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{customer_email}}, {{customer_phone}}, {{date}}, {{time}}, {{booking_id}}
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Email Footer Settings -->
                <div class="wpbc-branding-card">
                    <h2>Email Footer Template</h2>
                    <p class="description">Customize the footer that appears at the bottom of all customer emails.</p>
                    <p class="description" style="background:#fff9e6; border-left:3px solid #f59e0b; padding:10px; margin-top:10px;">
                        <strong>Important:</strong> The footer is optimized for mobile Gmail rendering. Keep it concise and use placeholders for dynamic content.
                    </p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_email_legal_name">Legal Business Name</label></th>
                            <td>
                                <input type="text" name="sec_email_legal_name" id="sec_email_legal_name"
                                       value="<?php echo esc_attr(get_option('sec_email_legal_name', '')); ?>" class="regular-text"
                                       placeholder="Marketing Aid LLC">
                                <p class="description">Your legal entity name for compliance (e.g., "Marketing Aid LLC")</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_email_physical_address">Physical Address</label></th>
                            <td>
                                <input type="text" name="sec_email_physical_address" id="sec_email_physical_address"
                                       value="<?php echo esc_attr(get_option('sec_email_physical_address', '')); ?>" class="large-text"
                                       placeholder="123 Main St, City, State 12345">
                                <p class="description">Your business's physical address (required for CAN-SPAM compliance)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_email_footer_template">Footer Template</label></th>
                            <td>
                                <textarea name="sec_email_footer_template" id="sec_email_footer_template"
                                          rows="4" class="large-text code" style="font-family: monospace;"><?php
                                    echo esc_textarea(get_option('sec_email_footer_template',
                                        '© {{year}} {{company_name}}. All rights reserved.<br>{{legal_name}}<br>{{physical_address}}'
                                    ));
                                ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong><br>
                                    <code>{{year}}</code> - Current year (e.g., 2026)<br>
                                    <code>{{company_name}}</code> - From Name (set above)<br>
                                    <code>{{legal_name}}</code> - Legal entity name<br>
                                    <code>{{physical_address}}</code> - Your business address<br><br>
                                    <strong>Formatting:</strong> Use <code>&lt;br&gt;</code> for line breaks to ensure proper rendering across all email clients, especially mobile.<br><br>
                                    <strong>Example:</strong> © {{year}} {{company_name}}. All rights reserved.<br>{{legal_name}}<br>{{physical_address}}
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <?php submit_button('Save Branding Settings', 'primary large'); ?>
            </form>
        </div>
        <script>
            (function() {
                const startPicker = document.getElementById('sec_email_header_gradient_start_picker');
                const endPicker = document.getElementById('sec_email_header_gradient_end_picker');
                const startText = document.getElementById('sec_email_header_gradient_start');
                const endText = document.getElementById('sec_email_header_gradient_end');

                if (!startPicker || !endPicker || !startText || !endText) {
                    return;
                }

                startPicker.addEventListener('input', function() { startText.value = this.value; });
                endPicker.addEventListener('input', function() { endText.value = this.value; });

                startText.addEventListener('input', function() {
                    if (/^#[0-9A-Fa-f]{6}$/.test(this.value)) {
                        startPicker.value = this.value;
                    }
                });
                endText.addEventListener('input', function() {
                    if (/^#[0-9A-Fa-f]{6}$/.test(this.value)) {
                        endPicker.value = this.value;
                    }
                });
            })();
        </script>
        <?php
    }

    private static function get_default_confirmation_template() {
        return 'Hi {{customer_name}},

Your appointment has been confirmed! Here are the details:

Date: {{date}}
Time: {{time}}

We look forward to seeing you!

{{calendar_links}}
{{manage_booking_button}}';
    }

    private static function get_default_cancellation_template() {
        return 'Hi {{customer_name}},

Your appointment has been canceled.

Date: {{date}}
Time: {{time}}

If you\'d like to book a new appointment, please visit our website.';
    }

    private static function get_default_reschedule_template() {
        return 'Hi {{customer_name}},

Your appointment has been rescheduled.

Previous: {{old_date}} at {{old_time}}
New Date: {{new_date}}
New Time: {{new_time}}

We look forward to seeing you!

{{calendar_links}}
{{manage_booking_button}}';
    }

    private static function get_default_reminder_24h_template() {
        return 'Hi {{customer_name}},

This is a friendly reminder that your appointment is tomorrow.

Date: {{date}}
Time: {{time}}

We look forward to seeing you!

{{calendar_links}}
{{manage_booking_button}}';
    }

    private static function get_default_reminder_1h_template() {
        return 'Hi {{customer_name}},

This is a friendly reminder that your appointment is in 1 hour.

Date: {{date}}
Time: {{time}}

We look forward to seeing you!

{{calendar_links}}
{{manage_booking_button}}';
    }
}

WPBC_Branding_Settings::init();
