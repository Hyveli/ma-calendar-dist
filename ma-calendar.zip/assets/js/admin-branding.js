jQuery(document).ready(function($) {
    'use strict';

    // Upload logo using WordPress media library
    $('.wpbc-upload-logo').on('click', function(e) {
        e.preventDefault();

        var mediaUploader = wp.media({
            title: 'Upload Company Logo',
            button: {
                text: 'Use this logo'
            },
            multiple: false,
            library: {
                type: 'image'
            }
        });

        mediaUploader.on('select', function() {
            var attachment = mediaUploader.state().get('selection').first().toJSON();

            $('#sec_logo_url').val(attachment.url);

            $('.wpbc-logo-placeholder').remove();
            $('.wpbc-logo-preview').remove();

            var preview = `
                <div class="wpbc-logo-preview">
                    <img src="${attachment.url}" alt="Company Logo">
                    <button type="button" class="button wpbc-remove-logo">Remove Logo</button>
                </div>
            `;

            $('.wpbc-logo-upload-area').prepend(preview);
            $('.wpbc-upload-logo').text('Change Logo');
        });

        mediaUploader.open();
    });

    // Upload PNG fallback logo (email/pdf-safe)
    $('.wpbc-upload-logo-png-fallback').on('click', function(e) {
        e.preventDefault();

        var mediaUploader = wp.media({
            title: 'Upload PNG Fallback Logo',
            button: { text: 'Use this PNG' },
            multiple: false,
            library: { type: 'image' }
        });

        mediaUploader.on('select', function() {
            var attachment = mediaUploader.state().get('selection').first().toJSON();
            $('#sec_logo_png_fallback_url').val(attachment.url);
        });

        mediaUploader.open();
    });

    // Remove logo
    $(document).on('click', '.wpbc-remove-logo', function(e) {
        e.preventDefault();

        if (!confirm('Are you sure you want to remove the logo?')) {
            return;
        }

        $('#sec_logo_url').val('');
        $('.wpbc-logo-preview').remove();

        var placeholder = `
            <div class="wpbc-logo-placeholder">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                    <circle cx="8.5" cy="8.5" r="1.5"/>
                    <polyline points="21 15 16 10 5 21"/>
                </svg>
                <p>No logo uploaded</p>
            </div>
        `;

        $('.wpbc-logo-upload-area').prepend(placeholder);
        $('.wpbc-upload-logo').text('Upload Logo');
    });
});
