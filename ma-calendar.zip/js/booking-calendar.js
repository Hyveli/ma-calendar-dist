/**
 * WP Booking Calendar - Modern Tab Layout with WebSocket
 */
(function($) {
    'use strict';

    // Debug: Check if dependencies loaded
    console.log('[WPBC] Script loaded');
    console.log('[WPBC] wpbcSettings:', typeof wpbcSettings !== 'undefined' ? wpbcSettings : 'NOT FOUND');
    console.log('[WPBC] io (Socket.io):', typeof io !== 'undefined' ? 'loaded' : 'NOT FOUND');
    console.log('[WPBC] flatpickr:', typeof flatpickr !== 'undefined' ? 'loaded' : 'NOT FOUND');

    // Check for required dependencies
    if (typeof wpbcSettings === 'undefined') {
        console.error('[WPBC] ERROR: wpbcSettings not found. Plugin not properly initialized.');
        return;
    }
    if (typeof flatpickr === 'undefined') {
        console.error('[WPBC] ERROR: Flatpickr not loaded.');
        return;
    }

    // Configuration from WordPress
    const WEBSOCKET_URL = wpbcSettings.websocketUrl;
    const WEBSOCKET_TOKEN = wpbcSettings.websocketToken || '';
    const SITE_ID = wpbcSettings.siteId;
    const CALENDAR_ID = wpbcSettings.calendarId;
    const USER_ID = wpbcSettings.userId;
    const AJAX_URL = wpbcSettings.ajaxUrl;
    const NONCE = wpbcSettings.nonce;

    console.log('[WPBC] Config - URL:', WEBSOCKET_URL, 'Site:', SITE_ID, 'Calendar:', CALENDAR_ID);

    // State
    let socket = null;
    let selectedDate = null;
    let selectedTime = null;
    let availableSlots = {};
    let bookedSlots = {};
    let availabilityLevel = {};
    let fp = null;
    let currentTab = 0;
    let verifiedToken = null;
    let pendingBookingData = null;

    // Time slots from plugin settings (falls back to hardcoded defaults)
    const ALL_TIME_SLOTS = (wpbcSettings.timeSlots && wpbcSettings.timeSlots.length)
        ? wpbcSettings.timeSlots
        : ['9:00 AM', '10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM'];

    // Available weekdays: 1=Mon…7=Sun (PHP date('N') convention), from plugin settings
    const AVAILABLE_DAYS = (wpbcSettings.availableDays && wpbcSettings.availableDays.length)
        ? wpbcSettings.availableDays
        : [1, 2, 3, 4, 5];

    // Convert a slot label like "9:00 AM" to minutes since midnight for time comparisons
    function slotToMinutes(label) {
        var m = label.match(/^(\d+):(\d+)\s*(AM|PM)$/i);
        if (!m) return 0;
        var h = parseInt(m[1], 10), min = parseInt(m[2], 10);
        if (m[3].toUpperCase() === 'PM' && h !== 12) h += 12;
        if (m[3].toUpperCase() === 'AM' && h === 12) h = 0;
        return h * 60 + min;
    }

    // Generate available slots AND availability levels for the next 60 days
    function generateAvailableSlots() {
        var slots = {};
        var now = new Date();
        var nowMins = now.getHours() * 60 + now.getMinutes();
        // Build today's YYYY-MM-DD in LOCAL timezone
        var todayStr = now.getFullYear() + '-' +
            String(now.getMonth() + 1).padStart(2, '0') + '-' +
            String(now.getDate()).padStart(2, '0');

        // Reset availability level
        availabilityLevel = {};

        for (var i = 0; i <= 180; i++) {
            var d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i);
            var dateStr = d.getFullYear() + '-' +
                String(d.getMonth() + 1).padStart(2, '0') + '-' +
                String(d.getDate()).padStart(2, '0');

            // Convert JS getDay() (0=Sun…6=Sat) → PHP N (1=Mon…7=Sun)
            var jsDay  = d.getDay();
            var phpDay = jsDay === 0 ? 7 : jsDay;
            if (AVAILABLE_DAYS.indexOf(phpDay) === -1) continue;

            var booked = bookedSlots[dateStr] || [];
            var isToday = (dateStr === todayStr);

            slots[dateStr] = ALL_TIME_SLOTS.filter(function(slot) {
                if (booked.indexOf(slot) !== -1) return false;
                // Hide slots whose start time has already passed today
                if (isToday && slotToMinutes(slot) <= nowMins) return false;
                return true;
            });

            // Calculate availability level for this date
            var openSlots = slots[dateStr].length;
            if (openSlots > 3) {
                availabilityLevel[dateStr] = 'open';
            } else if (openSlots >= 1) {
                availabilityLevel[dateStr] = 'limited';
            } else {
                availabilityLevel[dateStr] = 'booked';
            }
        }
        return slots;
    }

    // Load booked slots from database
    function loadBookedSlots(callback) {
        console.log('[WPBC] Loading booked slots from database...');

        $.post(AJAX_URL, {
            action: 'wpbc_get_booked_slots'
        }, function(response) {
            console.log('[WPBC] Get slots response:', response);
            if (response.success) {
                bookedSlots = (response.data && response.data.slots !== undefined)
                    ? response.data.slots
                    : (response.data || {});
                console.log('[WPBC] Booked slots loaded:', bookedSlots);
                if (callback) callback();
            } else {
                console.error('[WPBC] Failed to load booked slots:', response.data);
                if (callback) callback();
            }
        }).fail(function(xhr, status, error) {
            console.error('[WPBC] AJAX error loading booked slots:', status, error);
            if (callback) callback();
        });
    }

    // Initialize WebSocket connection
    function initWebSocket() {
        if (typeof io === 'undefined') {
            console.warn('[WPBC] Socket.io not available, real-time updates disabled');
            updateConnectionStatus('disconnected');
            return;
        }

        console.log('[WPBC] Connecting to:', WEBSOCKET_URL);

        if (window.location.protocol === 'https:' && WEBSOCKET_URL.startsWith('http://')) {
            console.error('[WPBC] ERROR: Mixed content blocked!');
            updateConnectionStatus('disconnected');
            return;
        }

        try {
            socket = io(WEBSOCKET_URL, {
                transports: ['websocket', 'polling'],
                reconnection: true,
                reconnectionDelay: 1000,
                reconnectionAttempts: 5,
                auth: { token: WEBSOCKET_TOKEN }
            });
        } catch (e) {
            console.error('[WPBC] Failed to create socket:', e);
            updateConnectionStatus('disconnected');
            return;
        }

        socket.on('connect', function() {
            console.log('[WPBC] Connected to WebSocket server!');
            updateConnectionStatus('connected');

            socket.emit('join-calendar', {
                siteId: SITE_ID,
                calendarId: CALENDAR_ID,
                userId: USER_ID
            });
        });

        socket.on('disconnect', function(reason) {
            console.log('[WPBC] Disconnected from server. Reason:', reason);
            updateConnectionStatus('disconnected');
        });

        socket.on('connect_error', function(error) {
            console.error('[WPBC] Connection error:', error.message);
            updateConnectionStatus('disconnected');
        });

        socket.on('slot-unavailable', function(data) {
            console.log('[WPBC] Slot booked by another user:', data.date, data.time);

            if (!bookedSlots[data.date]) {
                bookedSlots[data.date] = [];
            }
            if (bookedSlots[data.date].indexOf(data.time) === -1) {
                bookedSlots[data.date].push(data.time);
            }

            availableSlots = generateAvailableSlots();
            refreshCalendarDates();
            colorCalendarCells();

            // Check if user is on form panel (tab 1) with THIS slot selected
            if (currentTab === 1 && selectedDate === data.date && selectedTime === data.time) {
                // Their selected slot was just taken - redirect back gracefully
                showNotification('Sorry! The ' + data.time + ' slot was just booked. Please select another time.', 'error');
                selectedTime = null;
                // Small delay so they see the message before redirect
                setTimeout(function() {
                    showTab(0);
                }, 1500);
            } else if (currentTab === 0 && selectedDate === data.date) {
                displayTimeSlots(data.date);
                showNotification('Time slot ' + data.time + ' was just booked!', 'info');
            } else {
                showNotification('Time slot ' + data.time + ' was just booked!', 'info');
            }
        });

        socket.on('slot-available', function(data) {
            console.log('[WPBC] Slot became available:', data.date, data.time);

            if (bookedSlots[data.date]) {
                var idx = bookedSlots[data.date].indexOf(data.time);
                if (idx > -1) {
                    bookedSlots[data.date].splice(idx, 1);
                }
            }

            availableSlots = generateAvailableSlots();
            refreshCalendarDates();
            colorCalendarCells();

            showNotification('Time slot ' + data.time + ' is now available!', 'success');
            if (currentTab === 0 && selectedDate === data.date) {
                displayTimeSlots(data.date);
            }
        });

        socket.on('user-joined', function(data) {
            // Viewer count display removed - no action needed
        });

        socket.on('user-left', function(data) {
            // Viewer count display removed - no action needed
        });

        socket.on('booking-cancelled', function(data) {
            console.log('[WPBC] Booking cancelled:', data.date, data.time);

            if (bookedSlots[data.date]) {
                var idx = bookedSlots[data.date].indexOf(data.time);
                if (idx > -1) {
                    bookedSlots[data.date].splice(idx, 1);
                }
            }

            availableSlots = generateAvailableSlots();
            refreshCalendarDates();
            colorCalendarCells();

            if (currentTab === 0 && selectedDate === data.date) {
                displayTimeSlots(data.date);
            }
        });

        // Admin blocked all remaining slots for today
        socket.on('block-today', function(data) {
            console.log('[WPBC] Today blocked by admin:', data.date);
            if (!bookedSlots[data.date]) bookedSlots[data.date] = [];
            ALL_TIME_SLOTS.forEach(function(slot) {
                if (bookedSlots[data.date].indexOf(slot) === -1) {
                    bookedSlots[data.date].push(slot);
                }
            });
            availableSlots = generateAvailableSlots();
            refreshCalendarDates();
            colorCalendarCells();

            // Check if user is on form or time tab with this date selected
            if ((currentTab === 0 || currentTab === 1) && selectedDate === data.date) {
                showNotification('Sorry! All remaining slots for today are now unavailable. Please select another date.', 'error');
                selectedDate = null;
                selectedTime = null;
                setTimeout(function() {
                    if (fp) fp.clear();
                    showTab(0);
                }, 1500);
            }
        });

        // Admin unblocked today — reload from server for accurate state
        socket.on('unblock-today', function(data) {
            console.log('[WPBC] Today unblocked by admin:', data.date);
            loadBookedSlots(function() {
                availableSlots = generateAvailableSlots();
                refreshCalendarDates();
                colorCalendarCells();
                if (currentTab === 0 && selectedDate === data.date) {
                    displayTimeSlots(data.date);
                }
            });
        });

    } // end initWebSocket

    // Update connection status UI
    function updateConnectionStatus(status) {
        var statusEl = document.getElementById('wpbc-connection-status');
        if (!statusEl) return;

        statusEl.className = 'wpbc-connection-status wpbc-status-' + status;

        // Toggle offline class on calendar and slots
        var calendarCol = document.querySelector('.wpbc-calendar-col');
        var slotsCol = document.querySelector('.wpbc-slots-col');

        if (status === 'connected') {
            statusEl.textContent = 'Live';
            if (calendarCol) calendarCol.classList.remove('offline');
            if (slotsCol) slotsCol.classList.remove('offline');
        } else if (status === 'connecting') {
            statusEl.textContent = 'Connecting...';
            if (calendarCol) calendarCol.classList.add('offline');
            if (slotsCol) slotsCol.classList.add('offline');
        } else {
            statusEl.textContent = 'Offline';
            if (calendarCol) calendarCol.classList.add('offline');
            if (slotsCol) slotsCol.classList.add('offline');
        }
    }

    // Update viewer count
    function updateViewerCount(count) {
        var el = document.getElementById('wpbc-viewer-count');
        if (el) {
            el.textContent = count + ' viewing';
        }
    }

    // Refresh calendar enabled dates
    function refreshCalendarDates() {
        if (fp) {
            fp.set('enable', Object.keys(availableSlots).filter(function(date) {
                return availableSlots[date] && availableSlots[date].length > 0;
            }));
        }
    }

    // Color calendar cells based on availability level
    function colorCalendarCells() {
        if (!fp || !fp.calendarContainer) return;

        var cells = fp.calendarContainer.querySelectorAll('.flatpickr-day');
        cells.forEach(function(cell) {
            var ariaLabel = cell.getAttribute('aria-label');
            if (!ariaLabel) return;

            // Parse date from aria-label (format: "Month Day, Year")
            try {
                var dateObj = new Date(ariaLabel);
                if (isNaN(dateObj.getTime())) return;

                var dateStr = dateObj.getFullYear() + '-' +
                    String(dateObj.getMonth() + 1).padStart(2, '0') + '-' +
                    String(dateObj.getDate()).padStart(2, '0');

                // Set data-availability attribute
                var level = availabilityLevel[dateStr] || 'booked';

                // Disabled cells are always booked
                if (cell.classList.contains('flatpickr-disabled')) {
                    level = 'booked';
                }

                cell.setAttribute('data-availability', level);
            } catch (e) {
                // Ignore parse errors
            }
        });
    }

    // Flatpickr may re-render day nodes after interactions; repaint on next frame.
    function repaintCalendarCells() {
        colorCalendarCells();
        window.requestAnimationFrame(function() {
            colorCalendarCells();
        });
        setTimeout(colorCalendarCells, 0);
    }

    // Show notification
    function showNotification(message, type) {
        type = type || 'info';
        var notification = $('<div class="wpbc-notification ' + type + '">' + message + '</div>');
        $('body').append(notification);

        setTimeout(function() {
            notification.fadeOut(function() {
                notification.remove();
            });
        }, 4000);
    }

    // ============= TAB NAVIGATION =============

    function showTab(n) {
        currentTab = n;

        // Toggle panel visibility
        $('.wpbc-tab-panel').removeClass('active');
        $('.wpbc-tab-panel[data-panel="' + n + '"]').addClass('active');

        // Update tab button states
        $('.wpbc-tab').removeClass('active');
        $('.wpbc-tab[data-tab="' + n + '"]').addClass('active');

        // Update progress indicator position
        $('.wpbc-tab-bar').attr('data-active', n);

        // Tab 1 is locked unless date and time are selected
        if (n === 0) {
            // On tab 0, tab 1 might be locked
            if (selectedDate && selectedTime) {
                $('.wpbc-tab[data-tab="1"]').removeClass('locked');
            } else {
                $('.wpbc-tab[data-tab="1"]').addClass('locked');
            }
        } else if (n === 1) {
            $('.wpbc-tab[data-tab="1"]').removeClass('locked');
        }

        // Hide tab bar on confirmation screen (tab 2)
        var tabBar = document.getElementById('wpbc-tab-bar');
        if (tabBar) {
            if (n === 2) {
                tabBar.style.display = 'none';
            } else {
                tabBar.style.display = 'flex';
            }
        }
    }

    // Update Continue button state
    function updateContinueBtn() {
        var btn = document.getElementById('wpbc-continue-btn');
        if (btn) {
            btn.disabled = !(selectedDate && selectedTime);
        }
    }

    // ============= CALENDAR (TAB 0) =============

    function initCalendar() {
        var calendarCol = document.querySelector('.wpbc-calendar-col');
        if (!calendarCol) return;

        fp = flatpickr('#wpbc-calendar', {
            inline: true,
            minDate: 'today',
            maxDate: new Date().fp_incr(180),
            showMonths: 1,
            monthSelectorType: 'dropdown',
            locale: {
                firstDayOfWeek: 0 // 0 = Sunday, 1 = Monday
            },
            appendTo: calendarCol,
            enable: Object.keys(availableSlots).filter(function(date) {
                return availableSlots[date] && availableSlots[date].length > 0;
            }),
            onReady: function(selectedDates, dateStr, instance) {
                // Remove the year input (numInput) from the calendar header
                var yearInput = instance.calendarContainer.querySelector('.numInput.cur-year');
                if (yearInput) {
                    yearInput.parentNode.removeChild(yearInput);
                }
                // Also remove the year increment/decrement arrows
                var yearArrows = instance.calendarContainer.querySelectorAll('.arrowUp, .arrowDown');
                yearArrows.forEach(function(el) { el.parentNode.removeChild(el); });

                // Add calendar legend after calendar
                addCalendarLegend(instance);

                // Initialize Choices.js for month dropdown (desktop only)
                initMonthDropdown(instance);

                repaintCalendarCells();
            },
            onMonthChange: function(selectedDates, dateStr, instance) {
                repaintCalendarCells();
                updateMonthNavigation(instance);
            },
            onChange: function(selectedDates, dateStr) {
                if (dateStr) {
                    selectedDate = dateStr;
                    selectedTime = null;
                    displayTimeSlots(dateStr);
                    updateContinueBtn();
                    repaintCalendarCells();
                }
            }
        });
    }

    // Add calendar legend below the calendar
    function addCalendarLegend(instance) {
        // Check if legend already exists
        if (document.querySelector('.wpbc-calendar-legend')) {
            return;
        }

        var legend = document.createElement('div');
        legend.className = 'wpbc-calendar-legend';
        legend.innerHTML = `
            <div class="wpbc-legend-item">
                <div class="wpbc-legend-dot open"></div>
                <span>Open</span>
            </div>
            <div class="wpbc-legend-item">
                <div class="wpbc-legend-dot limited"></div>
                <span>Few left</span>
            </div>
            <div class="wpbc-legend-item">
                <div class="wpbc-legend-dot full"></div>
                <span>Full</span>
            </div>
        `;

        // Insert legend after calendar
        var calendarCol = document.querySelector('.wpbc-calendar-col');
        if (calendarCol) {
            calendarCol.appendChild(legend);
        }
    }

    // Disable month dropdown on ALL devices and manage navigation arrows
    function initMonthDropdown(instance) {
        var select = instance.calendarContainer.querySelector('.flatpickr-monthDropdown-months');
        if (select) {
            // Disable dropdown completely on ALL devices
            select.disabled = true;
            select.style.pointerEvents = 'none';
            select.style.cursor = 'default';
        }

        // Hide back button if on current month
        updateMonthNavigation(instance);
    }

    // Update month navigation arrows based on current month
    function updateMonthNavigation(instance) {
        if (!instance || !instance.currentYear || !instance.currentMonth === undefined) {
            return;
        }

        var now = new Date();
        var currentYear = now.getFullYear();
        var currentMonth = now.getMonth();

        var prevArrow = instance.calendarContainer.querySelector('.flatpickr-prev-month');

        // Hide back button if we're on current month
        if (instance.currentYear === currentYear && instance.currentMonth === currentMonth) {
            if (prevArrow) {
                prevArrow.style.visibility = 'hidden';
            }
        } else {
            if (prevArrow) {
                prevArrow.style.visibility = 'visible';
            }
        }
    }

    // ============= TIME SELECTION =============

    function displayTimeSlots(date) {
        const container = document.getElementById('wpbc-slots-col');
        if (!container) return;

        // Add loading class to fade out existing content
        container.classList.add('wpbc-slots-loading');
        container.classList.remove('wpbc-slots-loaded');

        // Small delay to allow fade-out animation
        setTimeout(function() {
            // Clear existing content
            container.innerHTML = '';

            const slots = availableSlots[date] || [];

            if (slots.length === 0) {
                container.innerHTML = '<div class="wpbc-slots-empty-state"><span class="wpbc-calendar-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg></span><p>No available time slots for this date</p></div>';

                // Remove has-content class for smaller min-height
                container.classList.remove('wpbc-has-content');

                // Fade in empty state
                requestAnimationFrame(function() {
                    container.classList.remove('wpbc-slots-loading');
                    container.classList.add('wpbc-slots-loaded');
                });
                return;
            }

            // Add date indicator in "MAY 11" format
            var dateObj = new Date(date + 'T00:00:00');
            var month = dateObj.toLocaleDateString('en-US', { month: 'short' }).toUpperCase();
            var day = dateObj.getDate();
            var formattedDate = month + ' ' + day;

            var indicator = document.createElement('div');
            indicator.className = 'wpbc-selected-date-indicator';
            indicator.textContent = formattedDate;
            container.appendChild(indicator);

            // Create slots grid
            var grid = document.createElement('div');
            grid.className = 'wpbc-slots-grid';

            // Display all time slots
            ALL_TIME_SLOTS.forEach(function(time) {
                const isAvailable = slots.indexOf(time) !== -1;
                const slot = document.createElement('button');
                slot.className = 'wpbc-time-slot' + (isAvailable ? '' : ' disabled');
                slot.textContent = time;
                slot.type = 'button';

                if (isAvailable) {
                    slot.addEventListener('click', function() {
                        selectTimeSlot(time);
                    });
                } else {
                    slot.disabled = true;
                }

                grid.appendChild(slot);
            });

            container.appendChild(grid);

            // Add has-content class to grow the container
            container.classList.add('wpbc-has-content');

            // Trigger fade-in animation after content is added to DOM
            requestAnimationFrame(function() {
                requestAnimationFrame(function() {
                    container.classList.remove('wpbc-slots-loading');
                    container.classList.add('wpbc-slots-loaded');
                    grid.classList.add('wpbc-fade-in');
                });
            });
        }, 150); // Small delay for fade-out
    }

    function selectTimeSlot(time) {
        selectedTime = time;

        // Update visual selection
        var slots = document.querySelectorAll('.wpbc-time-slot');
        slots.forEach(function(slot) {
            if (slot.textContent === time && !slot.classList.contains('disabled')) {
                slot.classList.add('selected');
            } else {
                slot.classList.remove('selected');
            }
        });

        updateContinueBtn();
    }

    // ============= BOOKING PILL (TAB 1) =============

    function updatePill() {
        if (!selectedDate || !selectedTime) return;

        const dateObj = new Date(selectedDate + 'T00:00:00');
        const formattedDate = dateObj.toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric'
        });

        var dateEl = document.getElementById('wpbc-summary-date');
        var timeEl = document.getElementById('wpbc-summary-time');

        if (dateEl) dateEl.textContent = formattedDate;
        if (timeEl) timeEl.textContent = selectedTime;

        // Clear form
        var form = document.getElementById('wpbc-booking-form');
        if (form) {
            form.reset();
            $('.wpbc-field-error').removeClass('wpbc-field-error');
            $('.wpbc-error-message').hide();
            hideEmailSuggestion();
        }
    }

    // ============= FORM VALIDATION =============

    function validateEmail(email) {
        var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    function validatePhone(phone) {
        if (!phone) return true;
        return normalizePhone(phone) !== null;
    }

    function normalizePhone(phone) {
        if (!phone) return '';
        var trimmed = String(phone).trim();
        if (!trimmed) return '';

        var hasLeadingPlus = trimmed.charAt(0) === '+';
        var digits = trimmed.replace(/\D/g, '');
        if (!digits) return '';

        if (hasLeadingPlus) {
            if (digits.length < 8 || digits.length > 15) {
                return null;
            }
            return '+' + digits;
        }

        // Default plain US numbers to +1 when country code is omitted.
        if (digits.length === 10) {
            return '+1' + digits;
        }
        if (digits.length === 11 && digits.charAt(0) === '1') {
            return '+' + digits;
        }

        if (digits.length >= 8 && digits.length <= 15) {
            return '+' + digits;
        }

        return null;
    }

    function formatPhone(phone) {
        if (!phone) {
            return '';
        }

        var normalized = normalizePhone(phone);
        if (!normalized) {
            return String(phone).trim();
        }

        var digits = normalized.replace(/\D/g, '');
        if (digits.length === 11 && digits.charAt(0) === '1') {
            return '+1 (' + digits.slice(1, 4) + ') ' + digits.slice(4, 7) + '-' + digits.slice(7, 11);
        }

        return '+' + digits;
    }

    function cleanPhoneInput(rawValue) {
        var raw = String(rawValue || '');
        var cleaned = raw.replace(/[^\d+\s().-]/g, '');
        if (!cleaned) return '';

        // Keep only one plus sign and only at the start.
        cleaned = cleaned.replace(/\+/g, '');
        if (raw.trim().charAt(0) === '+') {
            cleaned = '+' + cleaned;
        }
        return cleaned;
    }

    function normalizePhoneField($field) {
        var rawPhone = ($field.val() || '').trim();
        if (!rawPhone) {
            $field.removeData('wpbcPhoneNormalized');
            return '';
        }

        var normalized = normalizePhone(rawPhone);
        if (!normalized) {
            return null;
        }

        $field.data('wpbcPhoneNormalized', normalized);
        $field.val(formatPhone(normalized));
        return normalized;
    }

    function escapeHtml(value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function showFieldError($field, message) {
        $field.addClass('wpbc-field-error');
        var $error = $field.siblings('.wpbc-error-message');
        if ($error.length === 0) {
            $error = $('<span class="wpbc-error-message"></span>');
            $field.after($error);
        }
        $error.text(message).show();
    }

    function clearFieldError($field) {
        $field.removeClass('wpbc-field-error');
        $field.siblings('.wpbc-error-message').hide();
    }

    // Email typo detection
    var commonDomains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'aol.com', 'icloud.com'];

    function levenshteinDistance(a, b) {
        var matrix = [];
        for (var i = 0; i <= b.length; i++) {
            matrix[i] = [i];
        }
        for (var j = 0; j <= a.length; j++) {
            matrix[0][j] = j;
        }
        for (i = 1; i <= b.length; i++) {
            for (j = 1; j <= a.length; j++) {
                if (b.charAt(i-1) === a.charAt(j-1)) {
                    matrix[i][j] = matrix[i-1][j-1];
                } else {
                    matrix[i][j] = Math.min(
                        matrix[i-1][j-1] + 1,
                        matrix[i][j-1] + 1,
                        matrix[i-1][j] + 1
                    );
                }
            }
        }
        return matrix[b.length][a.length];
    }

    function checkEmailTypo(email) {
        if (!email || email.indexOf('@') === -1) return null;

        var parts = email.split('@');
        var domain = parts[1].toLowerCase();

        for (var i = 0; i < commonDomains.length; i++) {
            var commonDomain = commonDomains[i];
            if (domain !== commonDomain && levenshteinDistance(domain, commonDomain) <= 2) {
                return parts[0] + '@' + commonDomain;
            }
        }
        return null;
    }

    function showEmailSuggestion(suggestion) {
        hideEmailSuggestion();
        var $suggestion = $('<div class="wpbc-email-suggestion">Did you mean <a href="#" class="wpbc-suggestion-link">' + suggestion + '</a>?</div>');
        $('#wpbc-email').after($suggestion);
    }

    function hideEmailSuggestion() {
        $('.wpbc-email-suggestion').remove();
    }

    function validateForm() {
        var isValid = true;
        var $name = $('#wpbc-name');
        var $email = $('#wpbc-email');
        var $phone = $('#wpbc-phone');

        // Validate name
        var name = $name.val().trim();
        if (!name) {
            showFieldError($name, 'Name is required');
            isValid = false;
        } else if (name.length < 2) {
            showFieldError($name, 'Please enter your full name');
            isValid = false;
        } else {
            clearFieldError($name);
        }

        // Validate email
        var email = $email.val().trim();
        if (!email) {
            showFieldError($email, 'Email is required');
            isValid = false;
        } else if (!validateEmail(email)) {
            showFieldError($email, 'Please enter a valid email address');
            isValid = false;
        } else {
            clearFieldError($email);
        }

        // Validate phone (optional)
        var phone = $phone.val().trim();
        if (phone && !normalizePhoneField($phone)) {
            showFieldError($phone, 'Please enter a valid phone number (at least 10 digits)');
            isValid = false;
        } else {
            clearFieldError($phone);
        }

        return isValid;
    }

    function setupFormValidation() {
        // Email validation and typo detection
        $('#wpbc-email').on('blur', function() {
            var email = $(this).val().trim();
            if (email && !validateEmail(email)) {
                showFieldError($(this), 'Please enter a valid email address');
            } else {
                clearFieldError($(this));
                var suggestion = checkEmailTypo(email);
                if (suggestion) {
                    showEmailSuggestion(suggestion);
                } else {
                    hideEmailSuggestion();
                }
            }
        });

        // Email suggestion click
        $(document).on('click', '.wpbc-suggestion-link', function(e) {
            e.preventDefault();
            var suggestion = $(this).text();
            $('#wpbc-email').val(suggestion);
            hideEmailSuggestion();
            clearFieldError($('#wpbc-email'));
        });

        // Phone formatting / normalization
        $('#wpbc-phone').on('input', function() {
            $(this).val(cleanPhoneInput($(this).val()));
        });

        $('#wpbc-phone').on('blur', function() {
            var normalized = normalizePhoneField($(this));
            if (normalized === null) {
                showFieldError($(this), 'Please enter a valid phone number');
            } else {
                clearFieldError($(this));
            }
        });

        // Name validation
        $('#wpbc-name').on('blur', function() {
            var name = $(this).val().trim();
            if (!name) {
                showFieldError($(this), 'Name is required');
            } else if (name.length < 2) {
                showFieldError($(this), 'Please enter your full name');
            } else {
                clearFieldError($(this));
            }
        });

        // Clear errors on focus
        $('#wpbc-name, #wpbc-email, #wpbc-phone').on('focus', function() {
            clearFieldError($(this));
        });
    }

    // ============= SUBMIT BOOKING =============

    function submitBooking(e) {
        if (e) e.preventDefault();

        if (!validateForm()) {
            return;
        }

        // Store booking data for later use (after verification)
        pendingBookingData = {
            date: selectedDate,
            time: selectedTime,
            name: $('#wpbc-name').val().trim(),
            email: $('#wpbc-email').val().trim(),
            phone: $('#wpbc-phone').data('wpbcPhoneNormalized') || normalizePhone($('#wpbc-phone').val()) || '',
            address: $('#wpbc-address').val()
        };

        // Show verification modal and send code
        showVerificationModal(pendingBookingData.email);
    }

    function actuallySubmitBooking() {
        if (!pendingBookingData || !verifiedToken) {
            showNotification('Verification required', 'error');
            return;
        }

        var $btn = $('.wpbc-submit-btn');
        var originalText = $btn.text();
        $btn.prop('disabled', true).text('Booking...');

        var postData = {
            action: 'wpbc_create_booking',
            nonce: NONCE,
            date: pendingBookingData.date,
            time: pendingBookingData.time,
            name: pendingBookingData.name,
            email: pendingBookingData.email,
            phone: pendingBookingData.phone,
            address: pendingBookingData.address,
            verified_token: verifiedToken
        };

        console.log('[WPBC] Submitting booking with verification:', postData);

        $.post(AJAX_URL, postData, function(response) {
            console.log('[WPBC] Create booking response:', response);
            if (response.success) {
                console.log('[WPBC] Booking saved to database:', response.data);

                // Close verification modal
                closeVerificationModal();

                // Broadcast via WebSocket
                if (socket && socket.connected) {
                    socket.emit('slot-booked', {
                        siteId: SITE_ID,
                        calendarId: CALENDAR_ID,
                        date: selectedDate,
                        time: selectedTime,
                        userId: USER_ID,
                        bookingId: response.data.booking_id
                    });
                }

                // Update local state
                if (!bookedSlots[selectedDate]) {
                    bookedSlots[selectedDate] = [];
                }
                bookedSlots[selectedDate].push(selectedTime);
                availableSlots = generateAvailableSlots();

                // Refresh calendar
                refreshCalendarDates();
                colorCalendarCells();

                // Generate confirmation ID
                var confirmId = 'CB-' + Math.random().toString(36).slice(2, 8).toUpperCase();
                var confirmIdEl = document.getElementById('wpbc-confirm-id');
                if (confirmIdEl) {
                    confirmIdEl.textContent = confirmId;
                }

                // Build confirmation details
                var detailsEl = document.getElementById('wpbc-confirm-details');
                if (detailsEl) {
                    var dateObj = new Date(selectedDate + 'T00:00:00');
                    var formattedDate = dateObj.toLocaleDateString('en-US', {
                        weekday: 'long',
                        month: 'long',
                        day: 'numeric',
                        year: 'numeric'
                    });

                    var phone = formatPhone(postData.phone) || 'Not provided';

                    detailsEl.innerHTML =
                        '<div class="wpbc-confirm-row"><span class="wpbc-confirm-key">Date</span><span class="wpbc-confirm-val">' + escapeHtml(formattedDate) + '</span></div>' +
                        '<div class="wpbc-confirm-row"><span class="wpbc-confirm-key">Time</span><span class="wpbc-confirm-val">' + escapeHtml(selectedTime) + '</span></div>' +
                        '<div class="wpbc-confirm-row"><span class="wpbc-confirm-key">Name</span><span class="wpbc-confirm-val">' + escapeHtml($('#wpbc-name').val()) + '</span></div>' +
                        '<div class="wpbc-confirm-row"><span class="wpbc-confirm-key">Email</span><span class="wpbc-confirm-val">' + escapeHtml($('#wpbc-email').val()) + '</span></div>' +
                        '<div class="wpbc-confirm-row"><span class="wpbc-confirm-key">Phone</span><span class="wpbc-confirm-val">' + escapeHtml(phone) + '</span></div>';
                }

                // Show confirmation screen (tab 2)
                showTab(2);

                // Reset button state and clear verification state
                $btn.prop('disabled', false).text(originalText);
                verifiedToken = null;
                pendingBookingData = null;

            } else {
                showNotification('Error: ' + response.data, 'error');
                $btn.prop('disabled', false).text(originalText);
                closeVerificationModal();
            }
        }).fail(function(xhr, status, error) {
            console.error('[WPBC] Create booking AJAX error:', status, error);
            showNotification('Connection error. Please try again.', 'error');
            $btn.prop('disabled', false).text(originalText);
            closeVerificationModal();
        });
    }

    // ============= EMAIL VERIFICATION =============

    function showVerificationModal(email) {
        // Update email display
        $('#wpbc-verify-email-display').text(email);

        // Clear input and error
        $('#wpbc-verify-code-input').val('');
        $('#wpbc-verify-error').hide();

        // Show modal
        $('#wpbc-verify-modal').fadeIn(200);

        // Focus on input
        setTimeout(function() {
            $('#wpbc-verify-code-input').focus();
        }, 250);

        // Send verification code
        sendVerificationCode(email);
    }

    function closeVerificationModal() {
        $('#wpbc-verify-modal').fadeOut(200);
        $('#wpbc-verify-code-input').val('');
        $('#wpbc-verify-error').hide();
    }

    function sendVerificationCode(email) {
        console.log('[WPBC] Sending verification code to:', email);

        var $btn = $('#wpbc-verify-submit-btn');
        $btn.prop('disabled', true).text('Sending code...');

        $.post(AJAX_URL, {
            action: 'wpbc_send_verification_code',
            nonce: NONCE,
            email: email
        }, function(response) {
            console.log('[WPBC] Verification code response:', response);
            $btn.prop('disabled', false).text('Verify & Book');

            if (response.success) {
                showNotification('Verification code sent to your email!', 'success');
            } else {
                showNotification('Failed to send code: ' + response.data, 'error');
                closeVerificationModal();
            }
        }).fail(function(xhr, status, error) {
            console.error('[WPBC] Send verification code error:', status, error);
            showNotification('Connection error. Please try again.', 'error');
            $btn.prop('disabled', false).text('Verify & Book');
            closeVerificationModal();
        });
    }

    function verifyCode() {
        var code = $('#wpbc-verify-code-input').val().trim();
        var email = pendingBookingData.email;

        if (!code || code.length !== 6) {
            showVerifyError('Please enter a 6-digit code');
            return;
        }

        var $btn = $('#wpbc-verify-submit-btn');
        var originalText = $btn.text();
        $btn.prop('disabled', true).text('Verifying...');

        console.log('[WPBC] Verifying code:', code);

        $.post(AJAX_URL, {
            action: 'wpbc_verify_code',
            nonce: NONCE,
            email: email,
            code: code
        }, function(response) {
            console.log('[WPBC] Verify code response:', response);

            if (response.success) {
                verifiedToken = response.data.verified_token;
                showNotification('Email verified!', 'success');
                // Proceed with actual booking
                actuallySubmitBooking();
            } else {
                showVerifyError(response.data);
                $btn.prop('disabled', false).text(originalText);
            }
        }).fail(function(xhr, status, error) {
            console.error('[WPBC] Verify code error:', status, error);
            showVerifyError('Connection error. Please try again.');
            $btn.prop('disabled', false).text(originalText);
        });
    }

    function showVerifyError(message) {
        $('#wpbc-verify-error').text(message).fadeIn(200);
    }

    function hideVerifyError() {
        $('#wpbc-verify-error').fadeOut(200);
    }

    // ============= INITIALIZATION =============

    function init() {
        console.log('[WPBC] Initializing modern calendar...');

        // Move verification modal to body element to ensure proper z-index layering
        // This prevents site headers or other elements from appearing above the modal
        var $modal = $('#wpbc-verify-modal');
        if ($modal.length && $modal.parent()[0] !== document.body) {
            $modal.appendTo('body');
            console.log('[WPBC] Verification modal moved to body for proper layering');
        }

        // Initialize slots column with empty state
        var slotsCol = document.getElementById('wpbc-slots-col');
        if (slotsCol && slotsCol.innerHTML.trim() === '') {
            slotsCol.innerHTML = '<div class="wpbc-slots-empty-state"><span class="wpbc-calendar-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg></span><p>Select a date to see available times</p></div>';
            slotsCol.classList.add('wpbc-slots-loaded');
        }

        // Load booked slots first, then set up calendar
        loadBookedSlots(function() {
            availableSlots = generateAvailableSlots();
            initCalendar();
            showTab(0);
            updateContinueBtn();
            console.log('[WPBC] Calendar initialized with', Object.keys(availableSlots).length, 'available dates');
        });

        // Tab button click handlers
        $(document).on('click', '.wpbc-tab[data-tab]', function() {
            var targetTab = parseInt($(this).data('tab'));

            // Tab 0 is always accessible
            if (targetTab === 0) {
                showTab(0);
                return;
            }

            // Tab 1 requires date and time selection
            if (targetTab === 1) {
                if (selectedDate && selectedTime) {
                    showTab(1);
                } else {
                    showNotification('Please select a date and time first.', 'info');
                }
            }
        });

        // Continue button click handler
        $(document).on('click', '#wpbc-continue-btn', function() {
            if (selectedDate && selectedTime) {
                updatePill();
                showTab(1);
            }
        });

        // Change button click handler
        $(document).on('click', '#wpbc-change-btn', function() {
            showTab(0);
        });

        // Reset button click handler
        $(document).on('click', '#wpbc-reset-btn', function() {
            // Clear state
            selectedDate = null;
            selectedTime = null;

            // Reset form
            var form = document.getElementById('wpbc-booking-form');
            if (form) {
                form.reset();
                $('.wpbc-field-error').removeClass('wpbc-field-error');
                $('.wpbc-error-message').hide();
                hideEmailSuggestion();
            }

            // Clear flatpickr
            if (fp) fp.clear();

            // Reset slots column to empty state
            var slotsCol = document.getElementById('wpbc-slots-col');
            if (slotsCol) {
                slotsCol.innerHTML = '<div class="wpbc-slots-empty-state"><span class="wpbc-calendar-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg></span><p>Select a date to see available times</p></div>';
                slotsCol.classList.remove('wpbc-has-content', 'wpbc-slots-loading');
                slotsCol.classList.add('wpbc-slots-loaded');
            }

            // Regenerate availability
            availabilityLevel = {};
            availableSlots = generateAvailableSlots();
            refreshCalendarDates();
            colorCalendarCells();

            // Update continue button
            updateContinueBtn();

            // Return to tab 0
            showTab(0);
        });

        // Set up form validation
        setupFormValidation();

        // Set up form submit
        $('#wpbc-booking-form').on('submit', submitBooking);

        // Email verification modal handlers
        $('#wpbc-verify-close, .wpbc-verify-overlay').on('click', function() {
            closeVerificationModal();
        });

        $('#wpbc-verify-submit-btn').on('click', function() {
            verifyCode();
        });

        $('#wpbc-verify-resend-btn').on('click', function() {
            if (pendingBookingData && pendingBookingData.email) {
                sendVerificationCode(pendingBookingData.email);
            }
        });

        // Allow Enter key to submit verification code
        $('#wpbc-verify-code-input').on('keypress', function(e) {
            if (e.which === 13) {
                verifyCode();
            }
        });

        // Clear error when user starts typing
        $('#wpbc-verify-code-input').on('input', function() {
            hideVerifyError();
        });

        // Initialize WebSocket
        initWebSocket();
    }

    // Wait for DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})(jQuery);

