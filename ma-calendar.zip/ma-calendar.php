<?php
/**
 * Plugin Name: MA Calendar
 * Description: Real-time booking calendar with WebSocket support
 * Version: 1.0.01
 * Author: MarketingAid
 * License: GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

// Load SEC_Survey_Email class
require_once dirname(__FILE__) . '/inspo/class-survey-email.php';

// Activation hook must be at file level, not inside class
register_activation_hook(__FILE__, 'wpbc_activate_plugin');

function wpbc_activate_plugin() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'wpbc_bookings';
    $blocks_table = $wpdb->prefix . 'wpbc_blocks';
    $charset_collate = $wpdb->get_charset_collate();

    // Schedule rewrite flush so the wpbc_r query var is recognised immediately
    update_option('wpbc_flush_rewrite_rules', '1');

    // Bookings table
    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        booking_date date NOT NULL,
        booking_time varchar(20) NOT NULL,
        customer_name varchar(255) NOT NULL,
        customer_email varchar(255) NOT NULL,
        customer_phone varchar(50) DEFAULT '',
        customer_address text DEFAULT '',
        status varchar(20) DEFAULT 'confirmed',
        cancel_token varchar(64) DEFAULT '',
        notes text DEFAULT '',
        reminder_24h_sent tinyint(1) DEFAULT 0,
        reminder_1h_sent tinyint(1) DEFAULT 0,
        cal_short_url varchar(255) DEFAULT '',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY booking_date (booking_date),
        KEY status (status),
        KEY customer_email (customer_email),
        KEY cancel_token (cancel_token)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Manual blocks table (for admin to block specific slots/days)
    $sql_blocks = "CREATE TABLE $blocks_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        block_date date NOT NULL,
        block_time varchar(20) DEFAULT '',
        block_type varchar(20) DEFAULT 'slot',
        reason varchar(255) DEFAULT '',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY date_time (block_date, block_time),
        KEY block_date (block_date),
        KEY block_type (block_type)
    ) $charset_collate;";
    dbDelta($sql_blocks);

    // Store version for future upgrades
    update_option('wpbc_db_version', '1.2.0');
}

class WP_Booking_Calendar {

    private static $instance = null;
    private $table_name;
    private $blocks_table;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'wpbc_bookings';
        $this->blocks_table = $wpdb->prefix . 'wpbc_blocks';

        // Check if table exists, create if not (fallback)
        $this->maybe_create_table();

        // Admin
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));

        // Frontend
        add_shortcode('booking_calendar', array($this, 'render_calendar'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));

        // AJAX handlers (for both logged in and non-logged in users)
        add_action('wp_ajax_wpbc_get_booked_slots', array($this, 'ajax_get_booked_slots'));
        add_action('wp_ajax_nopriv_wpbc_get_booked_slots', array($this, 'ajax_get_booked_slots'));
        add_action('wp_ajax_wpbc_create_booking', array($this, 'ajax_create_booking'));
        add_action('wp_ajax_nopriv_wpbc_create_booking', array($this, 'ajax_create_booking'));

        // Admin AJAX
        add_action('wp_ajax_wpbc_cancel_booking', array($this, 'ajax_cancel_booking'));
        add_action('wp_ajax_wpbc_update_booking', array($this, 'ajax_update_booking'));
        add_action('wp_ajax_wpbc_get_available_slots', array($this, 'ajax_get_available_slots'));
        add_action('wp_ajax_nopriv_wpbc_get_available_slots', array($this, 'ajax_get_available_slots'));

        // Token-based cancellation/reschedule
        add_action('template_redirect', array($this, 'handle_token_cancellation'));

        // Custom short URL redirect (/prefix/TOKEN  or  ?wpbc_r=TOKEN)
        add_action('template_redirect', array($this, 'handle_short_redirect'));
        add_filter('query_vars', array($this, 'register_short_redirect_query_var'));

        // Register path-based rewrite rule for short URLs (must run on every init)
        add_action('init', array($this, 'add_short_redirect_rewrite_rules'));

        // Flush rewrite rules once after activation (or prefix change) so the rule is picked up
        add_action('init', array($this, 'maybe_flush_rewrite_rules'));

        // Trigger a rewrite flush whenever the prefix or domain setting is updated
        add_action('update_option_wpbc_short_prefix', array($this, 'schedule_rewrite_flush'));
        add_action('update_option_wpbc_short_domain', array($this, 'schedule_rewrite_flush'));

        // Reminder email cron system
        add_action('wpbc_send_reminders', array($this, 'send_reminder_emails'));
        add_action('wp', array($this, 'schedule_reminder_cron'));

        // AJAX for reschedule page
        add_action('wp_ajax_wpbc_reschedule_booking', array($this, 'ajax_reschedule_booking'));
        add_action('wp_ajax_nopriv_wpbc_reschedule_booking', array($this, 'ajax_reschedule_booking'));

        // Email Testing AJAX handlers (admin only)
        add_action('wp_ajax_wpbc_set_simulated_time', array($this, 'ajax_set_simulated_time'));
        add_action('wp_ajax_wpbc_clear_simulated_time', array($this, 'ajax_clear_simulated_time'));
        add_action('wp_ajax_wpbc_trigger_reminder_check', array($this, 'ajax_trigger_reminder_check'));
        add_action('wp_ajax_wpbc_send_test_reminder', array($this, 'ajax_send_test_reminder'));
        add_action('wp_ajax_wpbc_reset_reminder_flags', array($this, 'ajax_reset_reminder_flags'));
        add_action('wp_ajax_wpbc_schedule_reminder_cron', array($this, 'ajax_schedule_reminder_cron'));
        add_action('wp_ajax_wpbc_fix_missing_tokens', array($this, 'ajax_fix_missing_tokens'));

        // Block rest of today (admin-only quick toggle)
        add_action('wp_ajax_wpbc_block_today',   array($this, 'ajax_block_today'));
        add_action('wp_ajax_wpbc_unblock_today', array($this, 'ajax_unblock_today'));

        // Manual slot/day blocking (admin availability management)
        add_action('wp_ajax_wpbc_toggle_block', array($this, 'ajax_toggle_block'));
        add_action('wp_ajax_wpbc_get_blocks', array($this, 'ajax_get_blocks'));
        add_action('wp_ajax_wpbc_get_calendar_data', array($this, 'ajax_get_calendar_data'));

        // ICS file download (works for both logged-in and non-logged-in users)
        add_action('wp_ajax_wpbc_download_ics', array($this, 'ajax_download_ics'));
        add_action('wp_ajax_nopriv_wpbc_download_ics', array($this, 'ajax_download_ics'));
    }

    /**
     * Create table if it doesn't exist (fallback)
     */
    private function maybe_create_table() {
        global $wpdb;

        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->table_name}'") === $this->table_name;

        if (!$table_exists) {
            wpbc_activate_plugin();
        } else {
            // Check if cancel_token column exists, add if not (for upgrades)
            $column_exists = $wpdb->get_var(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                 AND TABLE_NAME = '{$this->table_name}'
                 AND COLUMN_NAME = 'cancel_token'"
            );

            if (!$column_exists) {
                $wpdb->query("ALTER TABLE {$this->table_name} ADD COLUMN cancel_token varchar(64) DEFAULT '' AFTER status");
                $wpdb->query("ALTER TABLE {$this->table_name} ADD INDEX cancel_token (cancel_token)");
            }

            // Check if reminder columns exist, add if not (for upgrades)
            $reminder_24h_exists = $wpdb->get_var(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                 AND TABLE_NAME = '{$this->table_name}'
                 AND COLUMN_NAME = 'reminder_24h_sent'"
            );

            if (!$reminder_24h_exists) {
                $wpdb->query("ALTER TABLE {$this->table_name} ADD COLUMN reminder_24h_sent tinyint(1) DEFAULT 0 AFTER notes");
                $wpdb->query("ALTER TABLE {$this->table_name} ADD COLUMN reminder_1h_sent tinyint(1) DEFAULT 0 AFTER reminder_24h_sent");
            }

            // Check if cal_short_url column exists, add if not (v1.1.0 upgrade)
            $cal_short_url_exists = $wpdb->get_var(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                 AND TABLE_NAME = '{$this->table_name}'
                 AND COLUMN_NAME = 'cal_short_url'"
            );

            if (!$cal_short_url_exists) {
                $wpdb->query("ALTER TABLE {$this->table_name} ADD COLUMN cal_short_url varchar(255) DEFAULT '' AFTER reminder_1h_sent");
            }
        }

        // Check if blocks table exists, create if not
        $blocks_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->blocks_table}'") === $this->blocks_table;
        if (!$blocks_exists) {
            $charset_collate = $wpdb->get_charset_collate();
            $sql_blocks = "CREATE TABLE {$this->blocks_table} (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                block_date date NOT NULL,
                block_time varchar(20) DEFAULT '',
                block_type varchar(20) DEFAULT 'slot',
                reason varchar(255) DEFAULT '',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY date_time (block_date, block_time),
                KEY block_date (block_date),
                KEY block_type (block_type)
            ) $charset_collate;";
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql_blocks);
        }
    }

    /**
     * Build the list of allowed time slots from saved time-range settings.
     * Each range is "HH:MM-HH:MM" producing 1-hour slots between start and end.
     * Falls back to the original hardcoded defaults when nothing is saved yet.
     */
    public function get_time_slots() {
        $ranges_raw = get_option('wpbc_time_ranges', '');
        if (empty($ranges_raw)) {
            return array('9:00 AM', '10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM');
        }
        $ranges = json_decode($ranges_raw, true);
        if (!is_array($ranges) || empty($ranges)) {
            return array('9:00 AM', '10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM');
        }
        $slots = array();
        foreach ($ranges as $range) {
            if (empty($range['start']) || empty($range['end'])) continue;
            $start = strtotime('2000-01-01 ' . $range['start']);
            $end   = strtotime('2000-01-01 ' . $range['end']);
            if (!$start || !$end || $end <= $start) continue;
            for ($t = $start; $t < $end; $t += 3600) {
                $label = date('g:i A', $t);
                if (!in_array($label, $slots)) $slots[] = $label;
            }
        }
        return !empty($slots)
            ? $slots
            : array('9:00 AM', '10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM');
    }

    /**
     * Returns configured available weekday numbers using PHP date('N'): 1=Mon … 7=Sun.
     */
    public function get_available_days() {
        $saved = get_option('wpbc_available_days', '');
        if (empty($saved)) return array(1, 2, 3, 4, 5); // Mon–Fri default
        $days = json_decode($saved, true);
        return is_array($days) ? array_map('intval', $days) : array(1, 2, 3, 4, 5);
    }

    /** Returns true if $date_string falls on a configured available day. */
    private function is_available_day($date_string) {
        return in_array((int) date('N', strtotime($date_string)), $this->get_available_days(), true);
    }

    /**
     * AJAX: Block all remaining slots for today until midnight.
     */
    public function ajax_block_today() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        $today = current_time('Y-m-d');
        $ttl   = strtotime('tomorrow midnight', current_time('timestamp')) - current_time('timestamp');
        set_transient('wpbc_block_today', $today, max(1, $ttl));

        wp_send_json_success(array('date' => $today));
    }

    /**
     * AJAX: Unblock today — clears the transient.
     */
    public function ajax_unblock_today() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        delete_transient('wpbc_block_today');
        wp_send_json_success();
    }

    /**
     * AJAX: Get all booked slots.
     * Returns {slots: {...}, todayBlocked: bool} so the frontend can sync UI state.
     */
    public function ajax_get_booked_slots() {
        global $wpdb;

        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->table_name}'") === $this->table_name;
        if (!$table_exists) {
            error_log('WPBC: Table does not exist: ' . $this->table_name);
            wp_send_json_success(array('slots' => array(), 'todayBlocked' => false));
            return;
        }

        $bookings = $wpdb->get_results(
            "SELECT booking_date, booking_time FROM {$this->table_name}
             WHERE status = 'confirmed' AND booking_date >= CURDATE()"
        );

        if ($wpdb->last_error) {
            error_log('WPBC Query Error: ' . $wpdb->last_error);
        }

        $booked_slots = array();
        foreach ($bookings as $booking) {
            if (!isset($booked_slots[$booking->booking_date])) {
                $booked_slots[$booking->booking_date] = array();
            }
            $booked_slots[$booking->booking_date][] = $booking->booking_time;
        }

        // Include manual blocks from the blocks table
        $blocks = $wpdb->get_results(
            "SELECT block_date, block_time FROM {$this->blocks_table} WHERE block_date >= CURDATE()"
        );
        foreach ($blocks as $block) {
            if (!isset($booked_slots[$block->block_date])) {
                $booked_slots[$block->block_date] = array();
            }
            if (!in_array($block->block_time, $booked_slots[$block->block_date])) {
                $booked_slots[$block->block_date][] = $block->block_time;
            }
        }

        // If "block rest of today" is active, stuff every configured slot into today's booked list
        $today        = current_time('Y-m-d');
        $block_date   = get_transient('wpbc_block_today');
        $today_blocked = ($block_date === $today);

        if ($today_blocked) {
            if (!isset($booked_slots[$today])) $booked_slots[$today] = array();
            foreach ($this->get_time_slots() as $slot) {
                if (!in_array($slot, $booked_slots[$today])) {
                    $booked_slots[$today][] = $slot;
                }
            }
        }

        wp_send_json_success(array(
            'slots'        => $booked_slots,
            'todayBlocked' => $today_blocked,
        ));
    }

    /**
     * AJAX: Create a new booking
     */
    public function ajax_create_booking() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_booking_nonce')) {
            wp_send_json_error('Invalid security token');
        }

        // Sanitize input
        $date = sanitize_text_field($_POST['date']);
        $time = sanitize_text_field($_POST['time']);
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);
        $address = sanitize_textarea_field($_POST['address']);

        // Validate required fields
        if (empty($date) || empty($time) || empty($name) || empty($email)) {
            wp_send_json_error('Please fill in all required fields');
        }

        // Validate email format
        if (!is_email($email)) {
            wp_send_json_error('Please enter a valid email address');
        }

        // Validate phone format (if provided)
        if (!empty($phone)) {
            $phone_clean = preg_replace('/[^0-9+\-\s\(\)]/', '', $phone);
            if (strlen(preg_replace('/[^0-9]/', '', $phone_clean)) < 10) {
                wp_send_json_error('Please enter a valid phone number (at least 10 digits)');
            }
            $phone = $phone_clean;
        }

        // Validate date is in the future and on a configured available day
        $booking_date = strtotime($date);
        if ($booking_date < strtotime('today')) {
            wp_send_json_error('Cannot book dates in the past');
        }
        if (!$this->is_available_day($date)) {
            wp_send_json_error('Bookings are not available on that day');
        }

        // Validate time is one of the configured allowed slots
        $allowed_times = $this->get_time_slots();
        if (!in_array($time, $allowed_times)) {
            wp_send_json_error('Invalid time slot selected');
        }

        // Check if slot is still available
        global $wpdb;
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$this->table_name}
             WHERE booking_date = %s AND booking_time = %s AND status = 'confirmed'",
            $date, $time
        ));

        if ($existing) {
            wp_send_json_error('This time slot has already been booked');
        }

        // Generate unique cancel token
        $cancel_token = wp_generate_password(32, false, false);

        // Insert booking
        $result = $wpdb->insert(
            $this->table_name,
            array(
                'booking_date' => $date,
                'booking_time' => $time,
                'customer_name' => $name,
                'customer_email' => $email,
                'customer_phone' => $phone,
                'customer_address' => $address,
                'status' => 'confirmed',
                'cancel_token' => $cancel_token
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );

        if ($result) {
            $booking_id = $wpdb->insert_id;

            // Send confirmation email
            $this->send_booking_email('confirmation', array(
                'booking_id' => $booking_id,
                'date' => $date,
                'time' => $time,
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'address' => $address,
                'cancel_token' => $cancel_token
            ));

            wp_send_json_success(array(
                'booking_id' => $booking_id,
                'message' => 'Booking confirmed!'
            ));
        } else {
            error_log('WPBC Insert Error: ' . $wpdb->last_error);
            error_log('WPBC Table: ' . $this->table_name);
            wp_send_json_error('Failed to create booking. Please try again.');
        }
    }

    /**
     * Send booking-related emails using SEC_Survey_Email template system
     */
    public function send_booking_email($type, $data) {
        $to = $data['email'];
        $site_name = get_bloginfo('name');

        // Get custom email from/name settings or use defaults
        $from_name = get_option('wpbc_email_from_name', get_option('sec_email_from_name', $site_name));
        $from_email = get_option('wpbc_email_from_email', get_option('sec_email_from_email', get_option('admin_email')));
        $admin_email = get_option('admin_email');

        // Format date nicely
        $formatted_date = date('l, F j, Y', strtotime($data['date']));
        $day_month = date('l, F j', strtotime($data['date']));

        // Build plain-text body and subject based on type
        switch ($type) {
            case 'confirmation':
                $subject = "Booking Confirmed – {$day_month} at {$data['time']}";
                $cancel_url = add_query_arg(array(
                    'wpbc_cancel' => $data['cancel_token'],
                    'booking_id' => $data['booking_id']
                ), home_url('/'));

                $body = "Hi {$data['name']},\n\n";
                $body .= "Your appointment has been confirmed! Here are the details:\n\n";
                $body .= "Date: {$formatted_date}\n";
                $body .= "Time: {$data['time']}\n";
                $body .= "Booking ID: #{$data['booking_id']}\n\n";
                $body .= "We look forward to seeing you!\n\n";
                $body .= $this->generate_calendar_links(
                    $data['date'],
                    $data['time'],
                    'Appointment at ' . $site_name,
                    'Your appointment is scheduled for ' . $formatted_date . ' at ' . $data['time'] . '. Booking ID: #' . $data['booking_id']
                );
                $body .= "\n\nNeed to make changes?\n";
                $body .= "Visit: {$cancel_url}";
                break;

            case 'cancellation':
                $subject = "Booking Cancelled – {$day_month} at {$data['time']}";
                $body = "Hi {$data['name']},\n\n";
                $body .= "Your appointment has been cancelled.\n\n";
                $body .= "Date: {$formatted_date}\n";
                $body .= "Time: {$data['time']}\n\n";
                $body .= "If you'd like to book a new appointment, please visit our website.";
                break;

            case 'reschedule':
                $old_date = date('l, F j, Y', strtotime($data['old_date']));
                $new_date = date('l, F j, Y', strtotime($data['new_date']));
                $new_day_month = date('l, F j', strtotime($data['new_date']));
                $subject = "Booking Rescheduled – New Date: {$new_day_month} at {$data['new_time']}";

                $cancel_url = '';
                if (!empty($data['cancel_url'])) {
                    $cancel_url = $data['cancel_url'];
                } elseif (!empty($data['cancel_token']) && !empty($data['booking_id'])) {
                    $cancel_url = add_query_arg(array(
                        'wpbc_cancel' => $data['cancel_token'],
                        'booking_id' => $data['booking_id']
                    ), home_url('/'));
                }

                $body = "Hi {$data['name']},\n\n";
                $body .= "Your appointment has been rescheduled.\n\n";
                $body .= "Previous: {$old_date} at {$data['old_time']}\n\n";
                $body .= "New Date: {$new_date}\n";
                $body .= "New Time: {$data['new_time']}\n\n";
                $body .= "We look forward to seeing you!\n\n";
                $body .= $this->generate_calendar_links(
                    $data['new_date'],
                    $data['new_time'],
                    'Appointment at ' . $site_name,
                    'Your rescheduled appointment is on ' . $new_date . ' at ' . $data['new_time']
                );
                if (!empty($cancel_url)) {
                    $body .= "\n\nNeed to make changes?\n";
                    $body .= "Visit: {$cancel_url}";
                }
                break;

            case 'reminder':
                $reminder_type = isset($data['reminder_type']) ? $data['reminder_type'] : '24 hours';

                if ($reminder_type === '24 hours') {
                    $subject = "Reminder: Your appointment is tomorrow at {$data['time']}";
                    $reminder_text = "This is a friendly reminder that your appointment is tomorrow.";
                } else {
                    $subject = "Reminder: Your appointment is in 1 hour – {$data['time']} today";
                    $reminder_text = "This is a friendly reminder that your appointment is in 1 hour.";
                }

                $cancel_url = isset($data['cancel_url']) ? $data['cancel_url'] : '#';

                $body = "Hi {$data['name']},\n\n";
                $body .= "{$reminder_text}\n\n";
                $body .= "Date: {$formatted_date}\n";
                $body .= "Time: {$data['time']}\n";
                $body .= "Booking ID: #{$data['booking_id']}\n\n";
                $body .= "We look forward to seeing you!\n\n";
                $body .= $this->generate_calendar_links(
                    $data['date'],
                    $data['time'],
                    'Appointment at ' . $site_name,
                    'Your appointment is scheduled for ' . $formatted_date . ' at ' . $data['time'] . '. Booking ID: #' . $data['booking_id']
                );
                if ($cancel_url !== '#') {
                    $body .= "\n\nNeed to make changes?\n";
                    $body .= "Visit: {$cancel_url}";
                }
                break;

            case 'admin_notification':
                $subject = "[New Booking] {$data['name']} – {$day_month} at {$data['time']}";
                $body = "New booking received:\n\n";
                $body .= "Date: {$formatted_date}\n";
                $body .= "Time: {$data['time']}\n";
                $body .= "Booking ID: #{$data['booking_id']}\n\n";
                $body .= "Customer Details:\n";
                $body .= "Name: {$data['name']}\n";
                $body .= "Email: {$data['email']}\n";
                $body .= "Phone: {$data['phone']}\n";
                $body .= "Address: {$data['address']}";
                $to = $admin_email;
                break;

            default:
                return false;
        }

        // Set HTML headers
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            "From: {$from_name} <{$from_email}>"
        );

        // Build HTML email using SEC_Survey_Email template system
        $html = SEC_Survey_Email::get_email_header();
        $html .= '<div class="ma-content">' . SEC_Survey_Email::render_plaintext_body_html($body) . '</div>';
        $html .= SEC_Survey_Email::get_email_footer();

        // Send email
        $sent = wp_mail($to, $subject, $html, $headers);

        // Also notify admin for new bookings
        if ($type === 'confirmation') {
            $this->send_booking_email('admin_notification', $data);
        }

        return $sent;
    }

    /**
     * Generate "Add to Calendar" links for emails (plain text format)
     * Returns plain text with calendar provider URLs
     */
    private function generate_calendar_links($date, $time, $title, $description = '', $location = '') {
        $site_name = get_bloginfo('name');

        // Parse date and time to create proper datetime
        $datetime = strtotime($date . ' ' . $time);
        $end_datetime = $datetime + 3600; // 1 hour appointment

        // Get the site's timezone
        $timezone = wp_timezone_string();
        $tz_object = timezone_open($timezone);
        $tz_name = $tz_object ? timezone_name_get($tz_object) : 'America/New_York';

        // Format for different calendars - use local time (no Z suffix)
        $start_local = date('Ymd\THis', $datetime);
        $end_local = date('Ymd\THis', $end_datetime);

        // Google Calendar - use local time format without Z (Google will use user's timezone)
        $google_url = 'https://calendar.google.com/calendar/render?action=TEMPLATE'
            . '&text=' . urlencode($title)
            . '&dates=' . $start_local . '/' . $end_local
            . '&details=' . urlencode($description)
            . '&location=' . urlencode($location)
            . '&ctz=' . urlencode($tz_name);

        // Outlook.com / Office 365 - use ISO format with timezone
        $outlook_start = date('Y-m-d\TH:i:s', $datetime);
        $outlook_end = date('Y-m-d\TH:i:s', $end_datetime);
        $outlook_url = 'https://outlook.live.com/calendar/0/deeplink/compose?path=/calendar/action/compose&rru=addevent'
            . '&subject=' . urlencode($title)
            . '&startdt=' . urlencode($outlook_start)
            . '&enddt=' . urlencode($outlook_end)
            . '&body=' . urlencode($description)
            . '&location=' . urlencode($location);

        // Yahoo Calendar - use local time format
        $yahoo_url = 'https://calendar.yahoo.com/?v=60&view=d&type=20'
            . '&title=' . urlencode($title)
            . '&st=' . $start_local
            . '&et=' . $end_local
            . '&desc=' . urlencode($description)
            . '&in_loc=' . urlencode($location);

        // ICS file download URL (server-side endpoint)
        $ics_url = admin_url('admin-ajax.php') . '?action=wpbc_download_ics'
            . '&date=' . urlencode($date)
            . '&time=' . urlencode($time)
            . '&title=' . urlencode($title)
            . '&description=' . urlencode($description)
            . '&location=' . urlencode($location);

        // Return plain text links (will be converted to HTML by render_plaintext_body_html)
        $text = "Add to Calendar:\n";
        $text .= "Google: {$google_url}\n";
        $text .= "Outlook: {$outlook_url}\n";
        $text .= "Yahoo: {$yahoo_url}\n";
        $text .= "Apple/iCal: {$ics_url}";

        return $text;
    }

    /**
     * AJAX: Cancel a booking (admin only)
     */
    public function ajax_cancel_booking() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) {
            wp_send_json_error('Invalid security token');
        }

        $booking_id = intval($_POST['booking_id']);

        global $wpdb;

        // Get booking details before cancelling
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $booking_id
        ));

        if (!$booking) {
            wp_send_json_error('Booking not found');
        }

        $result = $wpdb->update(
            $this->table_name,
            array('status' => 'cancelled'),
            array('id' => $booking_id),
            array('%s'),
            array('%d')
        );

        if ($result !== false) {
            // Send cancellation email
            $this->send_booking_email('cancellation', array(
                'email' => $booking->customer_email,
                'name' => $booking->customer_name,
                'date' => $booking->booking_date,
                'time' => $booking->booking_time
            ));

            // Return booking data for WebSocket broadcast
            wp_send_json_success(array(
                'message' => 'Booking cancelled',
                'booking_id' => $booking_id,
                'date' => $booking->booking_date,
                'time' => $booking->booking_time,
                'customer_email' => $booking->customer_email,
                'customer_name' => $booking->customer_name
            ));
        } else {
            wp_send_json_error('Failed to cancel booking');
        }
    }

    /**
     * AJAX: Update a booking (admin only)
     */
    public function ajax_update_booking() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) {
            wp_send_json_error('Invalid security token');
        }

        $booking_id = intval($_POST['booking_id']);
        $new_date = sanitize_text_field($_POST['new_date']);
        $new_time = sanitize_text_field($_POST['new_time']);

        global $wpdb;

        // Get old booking details
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $booking_id
        ));

        if (!$booking) {
            wp_send_json_error('Booking not found');
        }

        // Check if new slot is available
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$this->table_name}
             WHERE booking_date = %s AND booking_time = %s AND status = 'confirmed' AND id != %d",
            $new_date, $new_time, $booking_id
        ));

        if ($existing) {
            wp_send_json_error('This time slot is not available');
        }

        $old_date = $booking->booking_date;
        $old_time = $booking->booking_time;

        $result = $wpdb->update(
            $this->table_name,
            array(
                'booking_date' => $new_date,
                'booking_time' => $new_time
            ),
            array('id' => $booking_id),
            array('%s', '%s'),
            array('%d')
        );

        if ($result !== false) {
            // Generate cancel URL
            $cancel_url = add_query_arg(array(
                'wpbc_cancel' => $booking->cancel_token,
                'booking_id' => $booking_id
            ), home_url('/'));

            // Send reschedule email
            $this->send_booking_email('reschedule', array(
                'email' => $booking->customer_email,
                'name' => $booking->customer_name,
                'old_date' => $old_date,
                'old_time' => $old_time,
                'new_date' => $new_date,
                'new_time' => $new_time,
                'booking_id' => $booking_id,
                'cancel_token' => $booking->cancel_token,
                'cancel_url' => $cancel_url
            ));

            // Return booking data for WebSocket broadcast
            wp_send_json_success(array(
                'message' => 'Booking updated',
                'booking_id' => $booking_id,
                'old_date' => $old_date,
                'old_time' => $old_time,
                'new_date' => $new_date,
                'new_time' => $new_time,
                'customer_email' => $booking->customer_email,
                'customer_name' => $booking->customer_name
            ));
        } else {
            wp_send_json_error('Failed to update booking');
        }
    }

    /**
     * AJAX: Get available time slots for a specific date
     */
    public function ajax_get_available_slots() {
        // Accept both GET and POST
        $date = isset($_POST['date']) ? sanitize_text_field($_POST['date']) : sanitize_text_field($_GET['date']);
        $booking_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : (isset($_GET['booking_id']) ? intval($_GET['booking_id']) : 0);

        if (empty($date)) {
            wp_send_json_error('Date required');
        }

        // Check if it's a configured available day
        if (!$this->is_available_day($date)) {
            wp_send_json_success(array()); // Not an available day
            return;
        }

        // All possible slots from settings
        $all_slots = $this->get_time_slots();

        // Get booked slots for this date (excluding current booking if provided)
        global $wpdb;

        if ($booking_id > 0) {
            $booked = $wpdb->get_col($wpdb->prepare(
                "SELECT booking_time FROM {$this->table_name}
                 WHERE booking_date = %s AND status = 'confirmed' AND id != %d",
                $date, $booking_id
            ));
        } else {
            $booked = $wpdb->get_col($wpdb->prepare(
                "SELECT booking_time FROM {$this->table_name}
                 WHERE booking_date = %s AND status = 'confirmed'",
                $date
            ));
        }

        // Get manually blocked slots for this date
        $blocked = $wpdb->get_col($wpdb->prepare(
            "SELECT block_time FROM {$this->blocks_table} WHERE block_date = %s",
            $date
        ));

        // Filter out booked AND blocked slots
        $unavailable = array_merge($booked, $blocked);
        $available = array_values(array_diff($all_slots, $unavailable));

        // If "block rest of today" is active, return no slots for today
        $today = current_time('Y-m-d');
        if ($date === $today && get_transient('wpbc_block_today') === $today) {
            wp_send_json_success(array());
            return;
        }

        wp_send_json_success($available);
    }

    /**
     * Handle token-based cancellation from email link
     */
    public function handle_token_cancellation() {
        if (!isset($_GET['wpbc_cancel']) || !isset($_GET['booking_id'])) {
            return;
        }

        $token = sanitize_text_field($_GET['wpbc_cancel']);
        $booking_id = intval($_GET['booking_id']);

        if (empty($token) || empty($booking_id)) {
            return;
        }

        global $wpdb;

        // Verify token and get booking
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d AND cancel_token = %s",
            $booking_id, $token
        ));

        if (!$booking) {
            $this->show_cancellation_page('error', 'Invalid or expired cancellation link.');
            exit;
        }

        if ($booking->status === 'cancelled') {
            $this->show_cancellation_page('already_cancelled', 'This booking has already been cancelled.');
            exit;
        }

        // Check if user is actually cancelling (action=cancel in URL)
        if (isset($_GET['action']) && $_GET['action'] === 'cancel') {
            $wpdb->update(
                $this->table_name,
                array('status' => 'cancelled'),
                array('id' => $booking_id),
                array('%s'),
                array('%d')
            );

            $this->send_booking_email('cancellation', array(
                'email' => $booking->customer_email,
                'name' => $booking->customer_name,
                'date' => $booking->booking_date,
                'time' => $booking->booking_time
            ));

            $this->show_cancellation_page('cancelled');
            exit;
        }

        // Check if user just rescheduled
        if (isset($_GET['rescheduled']) && $_GET['rescheduled'] === '1') {
            $this->show_cancellation_page('rescheduled');
            exit;
        }

        // Show manage page (cancel or reschedule)
        $this->show_cancellation_page('manage', null, $booking);
        exit;
    }

    /**
     * Display cancellation/manage booking page
     */
    private function show_cancellation_page($status, $message = null, $booking = null) {
        $site_name = get_bloginfo('name');
        $primary_color = '#667eea';
        $websocket_url = get_option('wpbc_websocket_url', 'http://localhost:3000');
        $site_id = get_option('wpbc_site_id', parse_url(home_url(), PHP_URL_HOST));
        $calendar_id = get_option('wpbc_calendar_id', '1');

        // Get booked slots for calendar (if showing manage page)
        $booked_slots = array();
        if ($status === 'manage' && $booking) {
            global $wpdb;
            // Include ALL confirmed bookings for visual display
            $bookings = $wpdb->get_results(
                "SELECT booking_date, booking_time FROM {$this->table_name}
                WHERE status = 'confirmed'"
            );
            foreach ($bookings as $b) {
                $booked_slots[] = array(
                    'date' => $b->booking_date,
                    'time' => $b->booking_time
                );
            }

            // Include manual blocks from blocks table
            $blocks = $wpdb->get_results(
                "SELECT block_date, block_time FROM {$this->blocks_table}"
            );
            foreach ($blocks as $block) {
                $booked_slots[] = array(
                    'date' => $block->block_date,
                    'time' => $block->block_time
                );
            }

            // If block-today is active, add all configured slots for today as booked
            $today      = current_time('Y-m-d');
            $block_date = get_transient('wpbc_block_today');
            if ($block_date === $today) {
                foreach ($this->get_time_slots() as $slot) {
                    $booked_slots[] = array('date' => $today, 'time' => $slot);
                }
            }
        }

        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?php echo ($status === 'manage') ? 'Manage' : 'Cancel'; ?> Booking - <?php echo esc_html($site_name); ?></title>
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
            <style>
                * { box-sizing: border-box; margin: 0; padding: 0; }
                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    background: linear-gradient(135deg, <?php echo $primary_color; ?> 0%, #764ba2 100%);
                    min-height: 100vh;
                    display: flex;
                    align-items: flex-start;
                    justify-content: center;
                    padding: 40px 20px;
                }
                .container {
                    background: white;
                    border-radius: 12px;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.2);
                    max-width: 600px;
                    width: 100%;
                    padding: 40px;
                }
                h1 { color: #374151; margin-bottom: 20px; }
                .booking-details {
                    background: #f0f4ff;
                    padding: 20px;
                    border-radius: 8px;
                    border-left: 4px solid <?php echo $primary_color; ?>;
                    margin: 20px 0;
                }
                .booking-details p { margin: 10px 0; color: #374151; }
                .booking-details strong { color: #374151; }
                .booking-details span { color: <?php echo $primary_color; ?>; }
                .button {
                    display: inline-block;
                    padding: 12px 24px;
                    border-radius: 6px;
                    text-decoration: none;
                    font-weight: 600;
                    cursor: pointer;
                    border: none;
                    font-size: 16px;
                    margin: 10px 10px 10px 0;
                }
                .button-primary {
                    background: <?php echo $primary_color; ?>;
                    color: white;
                }
                .button-secondary {
                    background: #6b7280;
                    color: white;
                }
                .button-danger {
                    background: #ef4444;
                    color: white;
                }
                .error-message {
                    background: #fef2f2;
                    border-left: 4px solid #ef4444;
                    padding: 20px;
                    border-radius: 8px;
                    color: #991b1b;
                    margin: 20px 0;
                }
                .success-message {
                    background: #f0fdf4;
                    border-left: 4px solid #10b981;
                    padding: 20px;
                    border-radius: 8px;
                    color: #065f46;
                    margin: 20px 0;
                }
                #reschedule-section {
                    display: none;
                    margin-top: 30px;
                    padding-top: 30px;
                    border-top: 1px solid #e5e7eb;
                }
                .flatpickr-calendar { margin: 20px 0; }
                .time-slots {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
                    gap: 10px;
                    margin: 20px 0;
                }
                .time-slot {
                    padding: 12px;
                    border: 2px solid #e5e7eb;
                    border-radius: 6px;
                    text-align: center;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                .time-slot:hover { border-color: <?php echo $primary_color; ?>; }
                .time-slot.selected {
                    background: <?php echo $primary_color; ?>;
                    color: white;
                    border-color: <?php echo $primary_color; ?>;
                }
                .time-slot.disabled {
                    opacity: 0.3;
                    cursor: not-allowed;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <?php if ($status === 'error'): ?>
                    <h1>Error</h1>
                    <div class="error-message"><?php echo esc_html($message); ?></div>

                <?php elseif ($status === 'already_cancelled'): ?>
                    <h1>Already Cancelled</h1>
                    <div class="error-message"><?php echo esc_html($message); ?></div>

                <?php elseif ($status === 'cancelled'): ?>
                    <h1>Booking Cancelled</h1>
                    <div class="success-message">Your booking has been successfully cancelled.</div>

                <?php elseif ($status === 'rescheduled'): ?>
                    <h1>Booking Rescheduled</h1>
                    <div class="success-message">Your booking has been successfully rescheduled. You will receive a confirmation email shortly.</div>

                <?php elseif ($status === 'manage' && $booking): ?>
                    <h1>Manage Your Booking</h1>

                    <div class="booking-details">
                        <p><strong>Name:</strong> <span><?php echo esc_html($booking->customer_name); ?></span></p>
                        <p><strong>Date:</strong> <span><?php echo esc_html(date('l, F j, Y', strtotime($booking->booking_date))); ?></span></p>
                        <p><strong>Time:</strong> <span><?php echo esc_html($booking->booking_time); ?></span></p>
                        <p><strong>Booking ID:</strong> <span>#<?php echo esc_html($booking->id); ?></span></p>
                    </div>

                    <button class="button button-primary" onclick="showReschedule()">Reschedule Appointment</button>
                    <button class="button button-danger" onclick="confirmCancel()">Cancel Appointment</button>

                    <div id="reschedule-section">
                        <h2 style="color: #374151; margin-bottom: 20px;">Choose a New Date & Time</h2>
                        <input type="text" id="reschedule-date" placeholder="Select a date" style="width: 100%; padding: 12px; border: 1px solid #e5e7eb; border-radius: 6px; font-size: 16px; margin-bottom: 20px;">
                        <div id="time-slots-container" class="time-slots"></div>
                        <button class="button button-primary" onclick="submitReschedule()" id="confirm-reschedule-btn" style="display: none;">Confirm Reschedule</button>
                        <button class="button button-secondary" onclick="hideReschedule()">Cancel</button>
                    </div>

                    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
                    <script src="https://cdn.socket.io/4.5.4/socket.io.min.js"></script>
                    <script>
                        const bookingId = <?php echo json_encode($booking->id); ?>;
                        const cancelToken = <?php echo json_encode($booking->cancel_token); ?>;
                        const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
                        const bookedSlots = <?php echo json_encode($booked_slots); ?>;
                        const availableDays = <?php echo json_encode($this->get_available_days()); ?>;

                        let selectedDate = null;
                        let selectedTime = null;
                        let availableSlots = [];

                        function showReschedule() {
                            document.getElementById('reschedule-section').style.display = 'block';
                        }

                        function hideReschedule() {
                            document.getElementById('reschedule-section').style.display = 'none';
                        }

                        function confirmCancel() {
                            if (confirm('Are you sure you want to cancel this appointment?')) {
                                window.location.href = '?wpbc_cancel=' + cancelToken + '&booking_id=' + bookingId + '&action=cancel';
                            }
                        }

                        // Initialize Flatpickr
                        const fp = flatpickr('#reschedule-date', {
                            inline: true,
                            minDate: 'today',
                            dateFormat: 'Y-m-d',
                            disable: [
                                function(date) {
                                    const dayOfWeek = date.getDay() === 0 ? 7 : date.getDay();
                                    return !availableDays.includes(dayOfWeek);
                                }
                            ],
                            onChange: function(selectedDates, dateStr) {
                                selectedDate = dateStr;
                                selectedTime = null;
                                loadAvailableSlots(dateStr);
                            }
                        });

                        function loadAvailableSlots(date) {
                            fetch(ajaxUrl + '?action=wpbc_get_available_slots&date=' + date + '&booking_id=' + bookingId)
                                .then(res => res.json())
                                .then(data => {
                                    if (data.success) {
                                        availableSlots = data.data;
                                        renderTimeSlots();
                                    }
                                });
                        }

                        function renderTimeSlots() {
                            const container = document.getElementById('time-slots-container');
                            container.innerHTML = '';

                            availableSlots.forEach(slot => {
                                const div = document.createElement('div');
                                div.className = 'time-slot';
                                div.textContent = slot;
                                div.onclick = () => selectTimeSlot(slot);
                                container.appendChild(div);
                            });
                        }

                        function selectTimeSlot(slot) {
                            selectedTime = slot;
                            document.querySelectorAll('.time-slot').forEach(el => {
                                el.classList.remove('selected');
                            });
                            event.target.classList.add('selected');
                            document.getElementById('confirm-reschedule-btn').style.display = 'inline-block';
                        }

                        function submitReschedule() {
                            if (!selectedDate || !selectedTime) {
                                alert('Please select both a date and time');
                                return;
                            }

                            const formData = new FormData();
                            formData.append('action', 'wpbc_reschedule_booking');
                            formData.append('booking_id', bookingId);
                            formData.append('token', cancelToken);
                            formData.append('new_date', selectedDate);
                            formData.append('new_time', selectedTime);

                            fetch(ajaxUrl, {
                                method: 'POST',
                                body: formData
                            })
                            .then(res => res.json())
                            .then(data => {
                                if (data.success) {
                                    window.location.href = '?wpbc_cancel=' + cancelToken + '&booking_id=' + bookingId + '&rescheduled=1';
                                } else {
                                    alert(data.data.message || 'Failed to reschedule booking');
                                }
                            });
                        }
                    </script>
                <?php endif; ?>
            </div>
        </body>
        </html>
        <?php
    }

    /**
     * AJAX: Reschedule booking (public endpoint with token auth)
     */
    public function ajax_reschedule_booking() {
        global $wpdb;

        $booking_id = intval($_POST['booking_id']);
        $token = sanitize_text_field($_POST['token']);
        $new_date = sanitize_text_field($_POST['new_date']);
        $new_time = sanitize_text_field($_POST['new_time']);

        // Verify token
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d AND cancel_token = %s",
            $booking_id, $token
        ));

        if (!$booking) {
            wp_send_json_error(array('message' => 'Invalid token'));
        }

        if ($booking->status === 'cancelled') {
            wp_send_json_error(array('message' => 'This booking has been cancelled'));
        }

        // Check if new slot is available
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name}
            WHERE booking_date = %s AND booking_time = %s
            AND status = 'confirmed' AND id != %d",
            $new_date, $new_time, $booking_id
        ));

        if ($existing > 0) {
            wp_send_json_error(array('message' => 'This time slot is no longer available'));
        }

        // Store old values for email
        $old_date = $booking->booking_date;
        $old_time = $booking->booking_time;

        // Update booking
        $result = $wpdb->update(
            $this->table_name,
            array(
                'booking_date' => $new_date,
                'booking_time' => $new_time
            ),
            array('id' => $booking_id),
            array('%s', '%s'),
            array('%d')
        );

        if ($result !== false) {
            // Generate cancel URL
            $cancel_url = add_query_arg(array(
                'wpbc_cancel' => $booking->cancel_token,
                'booking_id' => $booking->id
            ), home_url('/'));

            // Send reschedule email
            $this->send_booking_email('reschedule', array(
                'email' => $booking->customer_email,
                'name' => $booking->customer_name,
                'old_date' => $old_date,
                'old_time' => $old_time,
                'new_date' => $new_date,
                'new_time' => $new_time,
                'booking_id' => $booking->id,
                'cancel_token' => $booking->cancel_token,
                'cancel_url' => $cancel_url
            ));

            wp_send_json_success();
        } else {
            wp_send_json_error(array('message' => 'Failed to update booking'));
        }
    }

    /**
     * AJAX: Toggle manual block for slot/day
     */
    public function ajax_toggle_block() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) {
            wp_send_json_error('Invalid security token');
        }

        global $wpdb;

        $date = sanitize_text_field($_POST['date']);
        $time = sanitize_text_field($_POST['time']);
        $block_all = isset($_POST['block_all']) && $_POST['block_all'];
        $unblock_all = isset($_POST['unblock_all']) && $_POST['unblock_all'];

        if ($block_all) {
            // Block all unbooked slots for this date
            $time_slots = $this->get_time_slots();
            $booked = $wpdb->get_col($wpdb->prepare(
                "SELECT booking_time FROM {$this->table_name} WHERE booking_date = %s AND status = 'confirmed'",
                $date
            ));

            foreach ($time_slots as $slot) {
                if (!in_array($slot, $booked)) {
                    $wpdb->replace($this->blocks_table, array(
                        'block_date' => $date,
                        'block_time' => $slot,
                        'block_type' => 'slot'
                    ), array('%s', '%s', '%s'));
                }
            }
            wp_send_json_success(array('blocked_all' => true));

        } elseif ($unblock_all) {
            // Remove all blocks for this date
            $wpdb->delete($this->blocks_table, array('block_date' => $date), array('%s'));
            wp_send_json_success(array('unblocked_all' => true));

        } else {
            // Toggle single slot
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$this->blocks_table} WHERE block_date = %s AND block_time = %s",
                $date, $time
            ));

            if ($exists) {
                $wpdb->delete($this->blocks_table, array('block_date' => $date, 'block_time' => $time), array('%s', '%s'));
                wp_send_json_success(array('blocked' => false));
            } else {
                $wpdb->insert($this->blocks_table, array(
                    'block_date' => $date,
                    'block_time' => $time,
                    'block_type' => 'slot'
                ), array('%s', '%s', '%s'));
                wp_send_json_success(array('blocked' => true));
            }
        }
    }

    /**
     * AJAX: Get all blocks
     */
    public function ajax_get_blocks() {
        global $wpdb;
        $blocks = $wpdb->get_results("SELECT block_date, block_time FROM {$this->blocks_table}");
        wp_send_json_success($blocks);
    }

    /**
     * AJAX: Get calendar data (blocks + bookings)
     */
    public function ajax_get_calendar_data() {
        global $wpdb;

        $blocks = $wpdb->get_results("SELECT block_date, block_time FROM {$this->blocks_table}");
        $bookings = $wpdb->get_results(
            "SELECT booking_date, booking_time FROM {$this->table_name} WHERE status = 'confirmed'"
        );

        wp_send_json_success(array(
            'blocks' => $blocks,
            'bookings' => $bookings
        ));
    }

    /**
     * Cron job: Send reminder emails for upcoming appointments
     */
    public function send_reminder_emails($return_details = false) {
        global $wpdb;

        // Check for simulated time (for testing)
        $simulated_time = get_option('wpbc_simulated_time', '');
        if ($simulated_time) {
            $now = $simulated_time;
            $base_timestamp = strtotime($simulated_time);
        } else {
            $now = current_time('mysql');
            $base_timestamp = current_time('timestamp');
        }

        $one_day_from_now = date('Y-m-d H:i:s', strtotime('+24 hours', $base_timestamp));
        $one_hour_from_now = date('Y-m-d H:i:s', strtotime('+1 hour', $base_timestamp));

        $details = array();
        $details[] = "Current time (simulated: " . ($simulated_time ? 'yes' : 'no') . "): " . $now;
        $details[] = "24h window: " . $now . " to " . $one_day_from_now;
        $details[] = "1h window: " . $now . " to " . $one_hour_from_now;

        // Get bookings that need 24-hour reminders
        // Use STR_TO_DATE to properly parse AM/PM time format
        $day_reminders = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name}
            WHERE status = 'confirmed'
            AND reminder_24h_sent = 0
            AND STR_TO_DATE(CONCAT(booking_date, ' ', booking_time), '%%Y-%%m-%%d %%h:%%i %%p') BETWEEN %s AND %s",
            $now, $one_day_from_now
        ));

        // Get bookings that need 1-hour reminders (only after 24h reminder has been sent)
        // Use STR_TO_DATE to properly parse AM/PM time format
        $hour_reminders = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name}
            WHERE status = 'confirmed'
            AND reminder_24h_sent = 1
            AND reminder_1h_sent = 0
            AND STR_TO_DATE(CONCAT(booking_date, ' ', booking_time), '%%Y-%%m-%%d %%h:%%i %%p') BETWEEN %s AND %s",
            $now, $one_hour_from_now
        ));

        $details[] = "Found " . count($day_reminders) . " bookings for 24h reminders";
        $details[] = "Found " . count($hour_reminders) . " bookings for 1h reminders";

        $sent_count = 0;

        // Send 24-hour reminders
        foreach ($day_reminders as $booking) {
            // Ensure booking has a cancel token (generate if missing)
            $cancel_token = $booking->cancel_token;
            if (empty($cancel_token)) {
                $cancel_token = wp_generate_password(32, false, false);
                $wpdb->update(
                    $this->table_name,
                    array('cancel_token' => $cancel_token),
                    array('id' => $booking->id),
                    array('%s'),
                    array('%d')
                );
                $details[] = "Generated missing cancel_token for booking #{$booking->id}";
            }

            $cancel_url = add_query_arg(array(
                'wpbc_cancel' => $cancel_token,
                'booking_id' => $booking->id
            ), home_url('/'));

            $sent = $this->send_booking_email('reminder', array(
                'email' => $booking->customer_email,
                'name' => $booking->customer_name,
                'date' => $booking->booking_date,
                'time' => $booking->booking_time,
                'booking_id' => $booking->id,
                'cancel_url' => $cancel_url,
                'reminder_type' => '24 hours'
            ));

            $details[] = "24h reminder to {$booking->customer_email} for booking #{$booking->id}: " . ($sent ? 'SENT' : 'FAILED');

            if ($sent) {
                $sent_count++;
                // Mark as sent
                $wpdb->update(
                    $this->table_name,
                    array('reminder_24h_sent' => 1),
                    array('id' => $booking->id),
                    array('%d'),
                    array('%d')
                );
            }
        }

        // Send 1-hour reminders
        foreach ($hour_reminders as $booking) {
            $cancel_token = $booking->cancel_token;
            if (empty($cancel_token)) {
                $cancel_token = wp_generate_password(32, false, false);
                $wpdb->update(
                    $this->table_name,
                    array('cancel_token' => $cancel_token),
                    array('id' => $booking->id),
                    array('%s'),
                    array('%d')
                );
            }

            $cancel_url = add_query_arg(array(
                'wpbc_cancel' => $cancel_token,
                'booking_id' => $booking->id
            ), home_url('/'));

            $sent = $this->send_booking_email('reminder', array(
                'email' => $booking->customer_email,
                'name' => $booking->customer_name,
                'date' => $booking->booking_date,
                'time' => $booking->booking_time,
                'booking_id' => $booking->id,
                'cancel_url' => $cancel_url,
                'reminder_type' => '1 hour'
            ));

            $details[] = "1h reminder to {$booking->customer_email} for booking #{$booking->id}: " . ($sent ? 'SENT' : 'FAILED');

            if ($sent) {
                $sent_count++;
                // Mark as sent
                $wpdb->update(
                    $this->table_name,
                    array('reminder_1h_sent' => 1),
                    array('id' => $booking->id),
                    array('%d'),
                    array('%d')
                );
            }
        }

        $details[] = "Total reminders sent: {$sent_count}";

        if ($return_details) {
            return $details;
        }
    }

    /**
     * Schedule reminder cron job if not already scheduled
     */
    public function schedule_reminder_cron() {
        if (!wp_next_scheduled('wpbc_send_reminders')) {
            wp_schedule_event(time(), 'hourly', 'wpbc_send_reminders');
        }
    }

    /**
     * AJAX: Fix missing cancel tokens
     */
    public function ajax_fix_missing_tokens() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) {
            wp_send_json_error('Invalid security token');
        }

        global $wpdb;

        $bookings = $wpdb->get_results(
            "SELECT id FROM {$this->table_name} WHERE cancel_token = '' OR cancel_token IS NULL"
        );

        $fixed = 0;
        foreach ($bookings as $booking) {
            $cancel_token = wp_generate_password(32, false, false);
            $wpdb->update(
                $this->table_name,
                array('cancel_token' => $cancel_token),
                array('id' => $booking->id),
                array('%s'),
                array('%d')
            );
            $fixed++;
        }

        wp_send_json_success(array('fixed' => $fixed));
    }

    /**
     * AJAX handler for ICS file download
     */
    public function ajax_download_ics() {
        // Get parameters
        $date = sanitize_text_field($_GET['date'] ?? '');
        $time = sanitize_text_field($_GET['time'] ?? '');
        $title = sanitize_text_field($_GET['title'] ?? 'Appointment');
        $description = sanitize_text_field($_GET['description'] ?? '');
        $location = sanitize_text_field($_GET['location'] ?? '');

        if (empty($date) || empty($time)) {
            wp_die('Missing required parameters');
        }

        // Parse the time to convert to 24-hour format
        $time_24h = date('H:i:s', strtotime($time));
        $datetime = strtotime($date . ' ' . $time_24h);
        $end_datetime = $datetime + 3600; // 1 hour appointment

        // Get the site's timezone
        $timezone = wp_timezone_string();

        // Format dates for ICS (UTC)
        $dtstart = gmdate('Ymd\THis\Z', $datetime);
        $dtend = gmdate('Ymd\THis\Z', $end_datetime);
        $dtstamp = gmdate('Ymd\THis\Z');

        // Generate unique UID
        $uid = md5($date . $time . $title) . '@' . parse_url(home_url(), PHP_URL_HOST);

        // Escape text for ICS format
        $title = $this->ics_escape_text($title);
        $description = $this->ics_escape_text($description);
        $location = $this->ics_escape_text($location);

        // Build ICS content
        $ics = "BEGIN:VCALENDAR\r\n";
        $ics .= "VERSION:2.0\r\n";
        $ics .= "PRODID:-//MA Calendar//Booking System//EN\r\n";
        $ics .= "CALSCALE:GREGORIAN\r\n";
        $ics .= "METHOD:PUBLISH\r\n";
        $ics .= "X-WR-TIMEZONE:{$timezone}\r\n";
        $ics .= "BEGIN:VEVENT\r\n";
        $ics .= "UID:{$uid}\r\n";
        $ics .= "DTSTAMP:{$dtstamp}\r\n";
        $ics .= "DTSTART:{$dtstart}\r\n";
        $ics .= "DTEND:{$dtend}\r\n";
        $ics .= "SUMMARY:{$title}\r\n";
        if (!empty($description)) {
            $ics .= "DESCRIPTION:{$description}\r\n";
        }
        if (!empty($location)) {
            $ics .= "LOCATION:{$location}\r\n";
        }
        $ics .= "STATUS:CONFIRMED\r\n";
        $ics .= "END:VEVENT\r\n";
        $ics .= "END:VCALENDAR\r\n";

        // Set headers for file download
        header('Content-Type: text/calendar; charset=utf-8');
        header('Content-Disposition: attachment; filename="appointment.ics"');
        header('Content-Length: ' . strlen($ics));
        header('Cache-Control: no-cache');

        echo $ics;
        exit;
    }

    /**
     * Escape text for ICS format
     */
    private function ics_escape_text($text) {
        $text = str_replace('\\', '\\\\', $text);
        $text = str_replace(',', '\,', $text);
        $text = str_replace(';', '\;', $text);
        $text = str_replace("\n", '\\n', $text);
        return $text;
    }

    /**
     * Short URL system: Generate a short URL for a long URL
     */
    private function shorten_url($long_url) {
        $domain = get_option('wpbc_short_domain', '');
        $prefix = get_option('wpbc_short_prefix', 'r');

        if (empty($domain)) {
            return $long_url; // No domain configured - return original URL
        }

        // Support {site_url} placeholder — replaced with the WordPress home URL
        if ($domain === '{site_url}' || $domain === '{site_url}/') {
            $domain = untrailingslashit(home_url());
        }

        // Generate a unique 8-character token
        $token = substr(md5(uniqid($long_url, true)), 0, 8);

        // Store the mapping: token => long URL (keyed the same way handle_short_redirect reads it)
        $option_key = 'wpbc_redirect_' . $token;
        update_option($option_key, $long_url, false); // false = do not autoload

        // Build the short URL as  domain/prefix/token
        $prefix = trim($prefix, '/');
        $domain = rtrim($domain, '/');

        // Ensure domain has a scheme
        if (strpos($domain, 'http') !== 0) {
            $domain = 'https://' . $domain;
        }

        return $domain . '/' . $prefix . '/' . $token;
    }

    /**
     * Register wpbc_r as a recognised WordPress query variable.
     * This handles both ?wpbc_r=TOKEN (legacy) and path-based /prefix/TOKEN rewrite rules.
     */
    public function register_short_redirect_query_var($vars) {
        $vars[] = 'wpbc_r';
        return $vars;
    }

    /**
     * Add rewrite rules so path-based short URLs like /appt/TOKEN are handled by WordPress.
     * Called on 'init'. Re-registers whenever the prefix setting changes.
     */
    public function add_short_redirect_rewrite_rules() {
        $prefix = get_option('wpbc_short_prefix', 'r');
        $prefix = trim($prefix, '/');

        if (!empty($prefix)) {
            // Match  /PREFIX/TOKEN  where TOKEN is 8 hex chars
            add_rewrite_rule(
                '^' . preg_quote($prefix, '/') . '/([a-f0-9]{8})/?$',
                'index.php?wpbc_r=$matches[1]',
                'top'
            );
        }
    }

    /**
     * Flush rewrite rules once after activation or prefix change
     */
    public function maybe_flush_rewrite_rules() {
        if (get_option('wpbc_flush_rewrite_rules') === '1') {
            flush_rewrite_rules();
            delete_option('wpbc_flush_rewrite_rules');
        }
    }

    /**
     * Schedule a rewrite flush on next init (triggered by settings update)
     */
    public function schedule_rewrite_flush() {
        update_option('wpbc_flush_rewrite_rules', '1');
    }

    /**
     * Handle short URL redirect
     */
    public function handle_short_redirect() {
        $token = get_query_var('wpbc_r', '');

        if (empty($token)) {
            return;
        }

        $token      = sanitize_text_field($token);
        $option_key = 'wpbc_redirect_' . $token;
        $long_url   = get_option($option_key, '');

        if (empty($long_url)) {
            wp_die('Link not found or expired.', 'Invalid Link', array('response' => 404));
        }

        // 302 (temporary) so phones don't cache the redirect and always hit the fresh ICS
        wp_redirect($long_url, 302);
        exit;
    }

    /**
     * Get or generate a cached short URL for a booking's calendar ICS link.
     */
    private function get_booking_cal_url($booking, $force_refresh = false) {
        global $wpdb;

        if (!$force_refresh && !empty($booking->cal_short_url)) {
            return $booking->cal_short_url;
        }

        $site_name = get_bloginfo('name');

        $long_url = admin_url('admin-ajax.php') . '?action=wpbc_download_ics'
            . '&date=' . urlencode($booking->booking_date)
            . '&time=' . urlencode($booking->booking_time)
            . '&title=' . urlencode('Appointment at ' . $site_name);

        $short_url = $this->shorten_url($long_url);

        // Persist to DB so all future SMS for this booking reuse the same link
        $wpdb->update(
            $this->table_name,
            array('cal_short_url' => $short_url),
            array('id' => $booking->id),
            array('%s'),
            array('%d')
        );

        return $short_url;
    }

    /**
     * Email Testing AJAX Handlers (stubs for now - full implementation in Session 2)
     */
    public function ajax_set_simulated_time() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        $time = sanitize_text_field($_POST['time']);
        update_option('wpbc_simulated_time', $time);
        wp_send_json_success();
    }

    public function ajax_clear_simulated_time() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        delete_option('wpbc_simulated_time');
        wp_send_json_success();
    }

    public function ajax_trigger_reminder_check() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        $details = $this->send_reminder_emails(true);
        wp_send_json_success(array('details' => $details));
    }

    public function ajax_send_test_reminder() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        global $wpdb;
        $booking_id = intval($_POST['booking_id']);
        $type = sanitize_text_field($_POST['type']);

        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $booking_id
        ));

        if (!$booking) {
            wp_send_json_error('Booking not found');
        }

        $cancel_url = add_query_arg(array(
            'wpbc_cancel' => $booking->cancel_token,
            'booking_id' => $booking->id
        ), home_url('/'));

        $sent = $this->send_booking_email('reminder', array(
            'email' => $booking->customer_email,
            'name' => $booking->customer_name,
            'date' => $booking->booking_date,
            'time' => $booking->booking_time,
            'booking_id' => $booking->id,
            'cancel_url' => $cancel_url,
            'reminder_type' => $type === '24h' ? '24 hours' : '1 hour'
        ));

        wp_send_json_success(array('sent' => $sent));
    }

    public function ajax_reset_reminder_flags() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        global $wpdb;
        $booking_id = intval($_POST['booking_id']);

        $wpdb->update(
            $this->table_name,
            array('reminder_24h_sent' => 0, 'reminder_1h_sent' => 0),
            array('id' => $booking_id),
            array('%d', '%d'),
            array('%d')
        );

        wp_send_json_success();
    }

    public function ajax_schedule_reminder_cron() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        wp_clear_scheduled_hook('wpbc_send_reminders');
        wp_schedule_event(time(), 'hourly', 'wpbc_send_reminders');
        wp_send_json_success();
    }

    /**
     * Admin menu and settings (stubs - full implementation in Session 2)
     */
    public function add_admin_menu() {
        // Admin pages will be implemented in Session 2
    }

    public function register_settings() {
        // Settings registration will be implemented in Session 2
    }

    /**
     * Frontend rendering (stub - implementation in Session 3)
     */
    public function render_calendar($atts) {
        return '<div class="wpbc-container">Calendar will be rendered here in Session 3</div>';
    }

    /**
     * Enqueue assets (stub - implementation in Session 3)
     */
    public function enqueue_assets() {
        // Asset enqueuing will be implemented in Session 3
    }
}

// Initialize plugin
WP_Booking_Calendar::get_instance();
