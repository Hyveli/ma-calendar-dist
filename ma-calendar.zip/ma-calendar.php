<?php
/**
 * Plugin Name: MA Calendar
 * Description: Real-time booking calendar with WebSocket support
 * Version: 1.0.23
 * Author: MarketingAid
 * License: GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

// Load SEC_Survey_Email class
require_once dirname(__FILE__) . '/includes/class-survey-email.php';

// Activation hook must be at file level, not inside class
register_activation_hook(__FILE__, 'wpbc_activate_plugin');

function wpbc_activate_plugin() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'wpbc_bookings';
    $blocks_table = $wpdb->prefix . 'wpbc_blocks';
    $charset_collate = $wpdb->get_charset_collate();

    // Schedule rewrite flush so the wpbc_r query var is recognised immediately
    update_option('wpbc_flush_rewrite_rules', '1');

    // Bookings table
    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        booking_date date NOT NULL,
        booking_time varchar(20) NOT NULL,
        customer_name varchar(255) NOT NULL,
        customer_email varchar(255) NOT NULL,
        customer_phone varchar(50) DEFAULT '',
        customer_address text DEFAULT '',
        status varchar(20) DEFAULT 'confirmed',
        cancel_token varchar(64) DEFAULT '',
        notes text DEFAULT '',
        reminder_24h_sent tinyint(1) DEFAULT 0,
        reminder_1h_sent tinyint(1) DEFAULT 0,
        cal_short_url varchar(255) DEFAULT '',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY booking_date (booking_date),
        KEY status (status),
        KEY customer_email (customer_email),
        KEY cancel_token (cancel_token)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Manual blocks table (for admin to block specific slots/days)
    $sql_blocks = "CREATE TABLE $blocks_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        block_date date NOT NULL,
        block_time varchar(20) DEFAULT '',
        block_type varchar(20) DEFAULT 'slot',
        reason varchar(255) DEFAULT '',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY date_time (block_date, block_time),
        KEY block_date (block_date),
        KEY block_type (block_type)
    ) $charset_collate;";
    dbDelta($sql_blocks);

    // Store version for future upgrades
    update_option('wpbc_db_version', '1.2.0');
}

class WP_Booking_Calendar {

    private static $instance = null;
    private $table_name;
    private $blocks_table;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'wpbc_bookings';
        $this->blocks_table = $wpdb->prefix . 'wpbc_blocks';

        // Check if table exists, create if not (fallback)
        $this->maybe_create_table();

        // Admin
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));

        // Frontend
        add_shortcode('booking_calendar', array($this, 'render_calendar'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));

        // AJAX handlers (for both logged in and non-logged in users)
        add_action('wp_ajax_wpbc_get_booked_slots', array($this, 'ajax_get_booked_slots'));
        add_action('wp_ajax_nopriv_wpbc_get_booked_slots', array($this, 'ajax_get_booked_slots'));
        add_action('wp_ajax_wpbc_create_booking', array($this, 'ajax_create_booking'));
        add_action('wp_ajax_nopriv_wpbc_create_booking', array($this, 'ajax_create_booking'));

        // Admin AJAX
        add_action('wp_ajax_wpbc_cancel_booking', array($this, 'ajax_cancel_booking'));
        add_action('wp_ajax_wpbc_update_booking', array($this, 'ajax_update_booking'));
        add_action('wp_ajax_wpbc_get_available_slots', array($this, 'ajax_get_available_slots'));
        add_action('wp_ajax_nopriv_wpbc_get_available_slots', array($this, 'ajax_get_available_slots'));

        // Token-based cancellation/reschedule
        add_action('template_redirect', array($this, 'handle_token_cancellation'));

        // Custom short URL redirect (/prefix/TOKEN  or  ?wpbc_r=TOKEN)
        add_action('template_redirect', array($this, 'handle_short_redirect'));
        add_filter('query_vars', array($this, 'register_short_redirect_query_var'));

        // Register path-based rewrite rule for short URLs (must run on every init)
        add_action('init', array($this, 'add_short_redirect_rewrite_rules'));

        // Flush rewrite rules once after activation (or prefix change) so the rule is picked up
        add_action('init', array($this, 'maybe_flush_rewrite_rules'));

        // Trigger a rewrite flush whenever the prefix or domain setting is updated
        add_action('update_option_wpbc_short_prefix', array($this, 'schedule_rewrite_flush'));
        add_action('update_option_wpbc_short_domain', array($this, 'schedule_rewrite_flush'));

        // Reminder email cron system
        add_action('wpbc_send_reminders', array($this, 'send_reminder_emails'));
        add_action('wp', array($this, 'schedule_reminder_cron'));

        // AJAX for reschedule and cancel pages (public with token auth)
        add_action('wp_ajax_wpbc_reschedule_booking', array($this, 'ajax_reschedule_booking'));
        add_action('wp_ajax_nopriv_wpbc_reschedule_booking', array($this, 'ajax_reschedule_booking'));
        add_action('wp_ajax_wpbc_cancel_booking_public', array($this, 'ajax_cancel_booking_public'));
        add_action('wp_ajax_nopriv_wpbc_cancel_booking_public', array($this, 'ajax_cancel_booking_public'));

        // Email Testing AJAX handlers (admin only)
        add_action('wp_ajax_wpbc_set_simulated_time', array($this, 'ajax_set_simulated_time'));
        add_action('wp_ajax_wpbc_clear_simulated_time', array($this, 'ajax_clear_simulated_time'));
        add_action('wp_ajax_wpbc_trigger_reminder_check', array($this, 'ajax_trigger_reminder_check'));
        add_action('wp_ajax_wpbc_send_test_reminder', array($this, 'ajax_send_test_reminder'));
        add_action('wp_ajax_wpbc_reset_reminder_flags', array($this, 'ajax_reset_reminder_flags'));
        add_action('wp_ajax_wpbc_schedule_reminder_cron', array($this, 'ajax_schedule_reminder_cron'));
        add_action('wp_ajax_wpbc_fix_missing_tokens', array($this, 'ajax_fix_missing_tokens'));
        add_action('wp_ajax_wpbc_delete_booking', array($this, 'ajax_delete_booking'));
        add_action('wp_ajax_wpbc_clear_bookings', array($this, 'ajax_clear_bookings'));

        // Block rest of today (admin-only quick toggle)
        add_action('wp_ajax_wpbc_block_today',   array($this, 'ajax_block_today'));
        add_action('wp_ajax_wpbc_unblock_today', array($this, 'ajax_unblock_today'));

        // Manual slot/day blocking (admin availability management)
        add_action('wp_ajax_wpbc_toggle_block', array($this, 'ajax_toggle_block'));
        add_action('wp_ajax_wpbc_get_blocks', array($this, 'ajax_get_blocks'));
        add_action('wp_ajax_wpbc_get_calendar_data', array($this, 'ajax_get_calendar_data'));

        // ICS file download (works for both logged-in and non-logged-in users)
        add_action('wp_ajax_wpbc_download_ics', array($this, 'ajax_download_ics'));
        add_action('wp_ajax_nopriv_wpbc_download_ics', array($this, 'ajax_download_ics'));
    }

    /**
     * Create table if it doesn't exist (fallback)
     */
    private function maybe_create_table() {
        global $wpdb;

        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->table_name}'") === $this->table_name;

        if (!$table_exists) {
            wpbc_activate_plugin();
        } else {
            // Check if cancel_token column exists, add if not (for upgrades)
            $column_exists = $wpdb->get_var(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                 AND TABLE_NAME = '{$this->table_name}'
                 AND COLUMN_NAME = 'cancel_token'"
            );

            if (!$column_exists) {
                $wpdb->query("ALTER TABLE {$this->table_name} ADD COLUMN cancel_token varchar(64) DEFAULT '' AFTER status");
                $wpdb->query("ALTER TABLE {$this->table_name} ADD INDEX cancel_token (cancel_token)");
            }

            // Check if reminder columns exist, add if not (for upgrades)
            $reminder_24h_exists = $wpdb->get_var(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                 AND TABLE_NAME = '{$this->table_name}'
                 AND COLUMN_NAME = 'reminder_24h_sent'"
            );

            if (!$reminder_24h_exists) {
                $wpdb->query("ALTER TABLE {$this->table_name} ADD COLUMN reminder_24h_sent tinyint(1) DEFAULT 0 AFTER notes");
                $wpdb->query("ALTER TABLE {$this->table_name} ADD COLUMN reminder_1h_sent tinyint(1) DEFAULT 0 AFTER reminder_24h_sent");
            }

            // Check if cal_short_url column exists, add if not (v1.1.0 upgrade)
            $cal_short_url_exists = $wpdb->get_var(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                 AND TABLE_NAME = '{$this->table_name}'
                 AND COLUMN_NAME = 'cal_short_url'"
            );

            if (!$cal_short_url_exists) {
                $wpdb->query("ALTER TABLE {$this->table_name} ADD COLUMN cal_short_url varchar(255) DEFAULT '' AFTER reminder_1h_sent");
            }
        }

        // Check if blocks table exists, create if not
        $blocks_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->blocks_table}'") === $this->blocks_table;
        if (!$blocks_exists) {
            $charset_collate = $wpdb->get_charset_collate();
            $sql_blocks = "CREATE TABLE {$this->blocks_table} (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                block_date date NOT NULL,
                block_time varchar(20) DEFAULT '',
                block_type varchar(20) DEFAULT 'slot',
                reason varchar(255) DEFAULT '',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY date_time (block_date, block_time),
                KEY block_date (block_date),
                KEY block_type (block_type)
            ) $charset_collate;";
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql_blocks);
        }
    }

    /**
     * Build the list of allowed time slots from saved time-range settings.
     * Each range is "HH:MM-HH:MM" producing 1-hour slots between start and end.
     * Falls back to the original hardcoded defaults when nothing is saved yet.
     */
    public function get_time_slots() {
        $ranges_raw = get_option('wpbc_time_ranges', '');
        if (empty($ranges_raw)) {
            return array('9:00 AM', '10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM');
        }
        $ranges = json_decode($ranges_raw, true);
        if (!is_array($ranges) || empty($ranges)) {
            return array('9:00 AM', '10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM');
        }
        $slots = array();
        foreach ($ranges as $range) {
            if (empty($range['start']) || empty($range['end'])) continue;
            $start = strtotime('2000-01-01 ' . $range['start']);
            $end   = strtotime('2000-01-01 ' . $range['end']);
            if (!$start || !$end || $end <= $start) continue;
            for ($t = $start; $t < $end; $t += 3600) {
                $label = date('g:i A', $t);
                if (!in_array($label, $slots)) $slots[] = $label;
            }
        }
        return !empty($slots)
            ? $slots
            : array('9:00 AM', '10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM');
    }

    /**
     * Returns configured available weekday numbers using PHP date('N'): 1=Mon … 7=Sun.
     */
    public function get_available_days() {
        $saved = get_option('wpbc_available_days', '');
        if (empty($saved)) return array(1, 2, 3, 4, 5); // Mon–Fri default
        $days = json_decode($saved, true);
        return is_array($days) ? array_map('intval', $days) : array(1, 2, 3, 4, 5);
    }

    /** Returns true if $date_string falls on a configured available day. */
    private function is_available_day($date_string) {
        return in_array((int) date('N', strtotime($date_string)), $this->get_available_days(), true);
    }

    /**
     * AJAX: Block all remaining slots for today until midnight.
     */
    public function ajax_block_today() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        $today = current_time('Y-m-d');
        $ttl   = strtotime('tomorrow midnight', current_time('timestamp')) - current_time('timestamp');
        set_transient('wpbc_block_today', $today, max(1, $ttl));

        wp_send_json_success(array('date' => $today));
    }

    /**
     * AJAX: Unblock today — clears the transient.
     */
    public function ajax_unblock_today() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        delete_transient('wpbc_block_today');
        wp_send_json_success();
    }

    /**
     * AJAX: Get all booked slots.
     * Returns {slots: {...}, todayBlocked: bool} so the frontend can sync UI state.
     */
    public function ajax_get_booked_slots() {
        global $wpdb;

        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->table_name}'") === $this->table_name;
        if (!$table_exists) {
            error_log('WPBC: Table does not exist: ' . $this->table_name);
            wp_send_json_success(array('slots' => array(), 'todayBlocked' => false));
            return;
        }

        $bookings = $wpdb->get_results(
            "SELECT booking_date, booking_time FROM {$this->table_name}
             WHERE status = 'confirmed' AND booking_date >= CURDATE()"
        );

        if ($wpdb->last_error) {
            error_log('WPBC Query Error: ' . $wpdb->last_error);
        }

        $booked_slots = array();
        foreach ($bookings as $booking) {
            if (!isset($booked_slots[$booking->booking_date])) {
                $booked_slots[$booking->booking_date] = array();
            }
            $booked_slots[$booking->booking_date][] = $booking->booking_time;
        }

        // Include manual blocks from the blocks table
        $blocks = $wpdb->get_results(
            "SELECT block_date, block_time FROM {$this->blocks_table} WHERE block_date >= CURDATE()"
        );
        foreach ($blocks as $block) {
            if (!isset($booked_slots[$block->block_date])) {
                $booked_slots[$block->block_date] = array();
            }
            if (!in_array($block->block_time, $booked_slots[$block->block_date])) {
                $booked_slots[$block->block_date][] = $block->block_time;
            }
        }

        // If "block rest of today" is active, stuff every configured slot into today's booked list
        $today        = current_time('Y-m-d');
        $block_date   = get_transient('wpbc_block_today');
        $today_blocked = ($block_date === $today);

        if ($today_blocked) {
            if (!isset($booked_slots[$today])) $booked_slots[$today] = array();
            foreach ($this->get_time_slots() as $slot) {
                if (!in_array($slot, $booked_slots[$today])) {
                    $booked_slots[$today][] = $slot;
                }
            }
        }

        wp_send_json_success(array(
            'slots'        => $booked_slots,
            'todayBlocked' => $today_blocked,
        ));
    }

    /**
     * AJAX: Create a new booking
     */
    public function ajax_create_booking() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_booking_nonce')) {
            wp_send_json_error('Invalid security token');
        }

        // Sanitize input
        $date = sanitize_text_field($_POST['date']);
        $time = sanitize_text_field($_POST['time']);
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);
        $address = sanitize_textarea_field($_POST['address']);

        // Validate required fields
        if (empty($date) || empty($time) || empty($name) || empty($email)) {
            wp_send_json_error('Please fill in all required fields');
        }

        // Validate email format
        if (!is_email($email)) {
            wp_send_json_error('Please enter a valid email address');
        }

        // Validate phone format (if provided)
        if (!empty($phone)) {
            $phone = trim($phone);
            $digits = preg_replace('/\D+/', '', $phone);
            $has_plus_prefix = (strpos($phone, '+') === 0);

            if (strlen($digits) < 10) {
                wp_send_json_error('Please enter a valid phone number (at least 10 digits)');
            }

            // Default plain US numbers to +1 if no explicit country code was provided.
            if (!$has_plus_prefix && strlen($digits) === 10) {
                $phone = '+1' . $digits;
            } elseif (!$has_plus_prefix && strlen($digits) === 11 && strpos($digits, '1') === 0) {
                $phone = '+' . $digits;
            } elseif ($has_plus_prefix || (strlen($digits) >= 8 && strlen($digits) <= 15)) {
                $phone = '+' . $digits;
            } else {
                wp_send_json_error('Please enter a valid phone number');
            }
        }

        // Validate date is in the future and on a configured available day
        $booking_date = strtotime($date);
        if ($booking_date < strtotime('today')) {
            wp_send_json_error('Cannot book dates in the past');
        }
        if (!$this->is_available_day($date)) {
            wp_send_json_error('Bookings are not available on that day');
        }

        // Validate time is one of the configured allowed slots
        $allowed_times = $this->get_time_slots();
        if (!in_array($time, $allowed_times)) {
            wp_send_json_error('Invalid time slot selected');
        }

        // Check if slot is still available
        global $wpdb;
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$this->table_name}
             WHERE booking_date = %s AND booking_time = %s AND status = 'confirmed'",
            $date, $time
        ));

        if ($existing) {
            wp_send_json_error('This time slot has already been booked');
        }

        // Generate unique cancel token
        $cancel_token = wp_generate_password(32, false, false);

        // Insert booking
        $result = $wpdb->insert(
            $this->table_name,
            array(
                'booking_date' => $date,
                'booking_time' => $time,
                'customer_name' => $name,
                'customer_email' => $email,
                'customer_phone' => $phone,
                'customer_address' => $address,
                'status' => 'confirmed',
                'cancel_token' => $cancel_token
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );

        if ($result) {
            $booking_id = $wpdb->insert_id;

            // Send confirmation email
            $this->send_booking_email('confirmation', array(
                'booking_id' => $booking_id,
                'date' => $date,
                'time' => $time,
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'address' => $address,
                'cancel_token' => $cancel_token
            ));

            wp_send_json_success(array(
                'booking_id' => $booking_id,
                'message' => 'Booking confirmed!'
            ));
        } else {
            error_log('WPBC Insert Error: ' . $wpdb->last_error);
            error_log('WPBC Table: ' . $this->table_name);
            wp_send_json_error('Failed to create booking. Please try again.');
        }
    }

    /**
     * Send booking-related emails using SEC_Survey_Email template system
     */
    public function send_booking_email($type, $data) {
        $to = $data['email'];
        $site_name = get_bloginfo('name');

        // Get custom email from/name settings or use defaults
        $from_name = get_option('wpbc_email_from_name', get_option('sec_email_from_name', $site_name));
        $from_email = get_option('wpbc_email_from_email', get_option('sec_email_from_email', get_option('admin_email')));
        $admin_email = get_option('admin_email');

        // Format date nicely
        $formatted_date = date('l, F j, Y', strtotime($data['date']));
        $day_month = date('l, F j', strtotime($data['date']));

        // Build plain-text body and subject based on type
        switch ($type) {
            case 'confirmation':
                $subject = "Booking Confirmed – {$day_month} at {$data['time']}";
                $cancel_url = add_query_arg(array(
                    'wpbc_cancel' => $data['cancel_token'],
                    'booking_id' => $data['booking_id']
                ), home_url('/'));

                $body = "Hi {$data['name']},\n\n";
                $body .= "Your appointment has been confirmed! Here are the details:\n\n";
                $body .= "Date: {$formatted_date}\n";
                $body .= "Time: {$data['time']}\n";
                $body .= "Booking ID: #{$data['booking_id']}\n\n";
                $body .= "We look forward to seeing you!\n\n";
                $body .= $this->generate_calendar_links(
                    $data['date'],
                    $data['time'],
                    'Appointment at ' . $site_name,
                    'Your appointment is scheduled for ' . $formatted_date . ' at ' . $data['time'] . '. Booking ID: #' . $data['booking_id']
                );
                $body .= $this->generate_manage_booking_button($cancel_url);
                break;

            case 'cancellation':
                $subject = "Booking Cancelled – {$day_month} at {$data['time']}";
                $body = "Hi {$data['name']},\n\n";
                $body .= "Your appointment has been cancelled.\n\n";
                $body .= "Date: {$formatted_date}\n";
                $body .= "Time: {$data['time']}\n\n";
                $body .= "If you'd like to book a new appointment, please visit our website.";
                break;

            case 'reschedule':
                $old_date = date('l, F j, Y', strtotime($data['old_date']));
                $new_date = date('l, F j, Y', strtotime($data['new_date']));
                $new_day_month = date('l, F j', strtotime($data['new_date']));
                $subject = "Booking Rescheduled – New Date: {$new_day_month} at {$data['new_time']}";

                $cancel_url = '';
                if (!empty($data['cancel_url'])) {
                    $cancel_url = $data['cancel_url'];
                } elseif (!empty($data['cancel_token']) && !empty($data['booking_id'])) {
                    $cancel_url = add_query_arg(array(
                        'wpbc_cancel' => $data['cancel_token'],
                        'booking_id' => $data['booking_id']
                    ), home_url('/'));
                }

                $body = "Hi {$data['name']},\n\n";
                $body .= "Your appointment has been rescheduled.\n\n";
                $body .= "Previous: {$old_date} at {$data['old_time']}\n\n";
                $body .= "New Date: {$new_date}\n";
                $body .= "New Time: {$data['new_time']}\n\n";
                $body .= "We look forward to seeing you!\n\n";
                $body .= $this->generate_calendar_links(
                    $data['new_date'],
                    $data['new_time'],
                    'Appointment at ' . $site_name,
                    'Your rescheduled appointment is on ' . $new_date . ' at ' . $data['new_time']
                );
                if (!empty($cancel_url)) {
                    $body .= $this->generate_manage_booking_button($cancel_url);
                }
                break;

            case 'reminder':
                $reminder_type = isset($data['reminder_type']) ? $data['reminder_type'] : '24 hours';

                if ($reminder_type === '24 hours') {
                    $subject = "Reminder: Your appointment is tomorrow at {$data['time']}";
                    $reminder_text = "This is a friendly reminder that your appointment is tomorrow.";
                } else {
                    $subject = "Reminder: Your appointment is in 1 hour – {$data['time']} today";
                    $reminder_text = "This is a friendly reminder that your appointment is in 1 hour.";
                }

                $cancel_url = isset($data['cancel_url']) ? $data['cancel_url'] : '#';

                $body = "Hi {$data['name']},\n\n";
                $body .= "{$reminder_text}\n\n";
                $body .= "Date: {$formatted_date}\n";
                $body .= "Time: {$data['time']}\n";
                $body .= "Booking ID: #{$data['booking_id']}\n\n";
                $body .= "We look forward to seeing you!\n\n";
                $body .= $this->generate_calendar_links(
                    $data['date'],
                    $data['time'],
                    'Appointment at ' . $site_name,
                    'Your appointment is scheduled for ' . $formatted_date . ' at ' . $data['time'] . '. Booking ID: #' . $data['booking_id']
                );
                if ($cancel_url !== '#') {
                    $body .= $this->generate_manage_booking_button($cancel_url);
                }
                break;

            case 'admin_notification':
                $subject = "[New Booking] {$data['name']} – {$day_month} at {$data['time']}";
                $body = "New booking received:\n\n";
                $body .= "Date: {$formatted_date}\n";
                $body .= "Time: {$data['time']}\n";
                $body .= "Booking ID: #{$data['booking_id']}\n\n";
                $body .= "Customer Details:\n";
                $body .= "Name: {$data['name']}\n";
                $body .= "Email: {$data['email']}\n";
                $body .= "Phone: {$data['phone']}\n";
                $body .= "Address: {$data['address']}";
                $to = $admin_email;
                break;

            default:
                return false;
        }

        // Set HTML headers - use proper "Business Name" <email@domain.com> format
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: "' . str_replace('"', '', $from_name) . '" <' . $from_email . '>'
        );

        // Build HTML email using our local email template methods
        $html  = $this->get_booking_email_header();
        $html .= '<div class="ma-content">' . $this->render_booking_email_body($body) . '</div>';
        $html .= $this->get_booking_email_footer();

        // Send email
        $sent = wp_mail($to, $subject, $html, $headers);

        // Also notify admin for new bookings
        if ($type === 'confirmation') {
            $this->send_booking_email('admin_notification', $data);
        }

        return $sent;
    }


    /**
     * Generate "Add to Calendar" links for emails (HTML format with provider logos)
     * Returns HTML with styled calendar links and proper provider icons
     */
    private function generate_calendar_links($date, $time, $title, $description = '', $location = '') {
        $site_name = get_bloginfo('name');

        // Parse date and time to create proper datetime
        $datetime = strtotime($date . ' ' . $time);
        $end_datetime = $datetime + 3600; // 1 hour appointment

        // Get the site's timezone
        $timezone = wp_timezone_string();
        $tz_object = timezone_open($timezone);
        $tz_name = $tz_object ? timezone_name_get($tz_object) : 'America/New_York';

        // Format for different calendars - use local time (no Z suffix)
        $start_local = date('Ymd\THis', $datetime);
        $end_local = date('Ymd\THis', $end_datetime);

        // Google Calendar - use local time format without Z (Google will use user's timezone)
        // Add reminders: 1440 minutes (24 hours) and 60 minutes (1 hour)
        $google_url = 'https://calendar.google.com/calendar/render?action=TEMPLATE'
            . '&text=' . urlencode($title)
            . '&dates=' . $start_local . '/' . $end_local
            . '&details=' . urlencode($description)
            . '&location=' . urlencode($location)
            . '&ctz=' . urlencode($tz_name)
            . '&rem=1440&rem=60';

        // Outlook.com / Office 365 - use ISO format with timezone
        $outlook_start = date('Y-m-d\TH:i:s', $datetime);
        $outlook_end = date('Y-m-d\TH:i:s', $end_datetime);
        $outlook_url = 'https://outlook.live.com/calendar/0/deeplink/compose?path=/calendar/action/compose&rru=addevent'
            . '&subject=' . urlencode($title)
            . '&startdt=' . urlencode($outlook_start)
            . '&enddt=' . urlencode($outlook_end)
            . '&body=' . urlencode($description)
            . '&location=' . urlencode($location);

        // Yahoo Calendar - use local time format
        $yahoo_url = 'https://calendar.yahoo.com/?v=60&view=d&type=20'
            . '&title=' . urlencode($title)
            . '&st=' . $start_local
            . '&et=' . $end_local
            . '&desc=' . urlencode($description)
            . '&in_loc=' . urlencode($location);

        // ICS file download URL (server-side endpoint)
        $ics_url = admin_url('admin-ajax.php') . '?action=wpbc_download_ics'
            . '&date=' . urlencode($date)
            . '&time=' . urlencode($time)
            . '&title=' . urlencode($title)
            . '&description=' . urlencode($description)
            . '&location=' . urlencode($location);

        // Get uploaded logos from admin settings
        $logo_apple = get_option('wpbc_logo_apple', '');
        $logo_google = get_option('wpbc_logo_google', '');
        $logo_outlook = get_option('wpbc_logo_outlook', '');
        $logo_yahoo = get_option('wpbc_logo_yahoo', '');

        // Build HTML with calendar provider logos
        $html = '
<div style="margin: 24px 0; padding: 20px; background: #ffffff; border-radius: 8px; text-align: center;">
    <p style="margin: 0 0 14px 0; font-weight: 500; color: #333; font-size: 14px; text-align: center;">Add appointment to calendar</p>
    <center>
        <table cellpadding="0" cellspacing="0" border="0" style="display: inline-block; margin: 0 auto;">
            <tr>';

        // Apple Calendar (white background with black logo)
        if ($logo_apple) {
            $html .= '
                <td style="padding: 0 8px;" align="center" valign="middle">
                    <a href="' . esc_url($ics_url) . '" style="display: inline-block; text-decoration: none;" target="_blank">
                        <img src="' . esc_url($logo_apple) . '" alt="Apple Calendar" style="width: 32px; height: 32px; display: block; vertical-align: middle;">
                    </a>
                </td>';
        }

        // Google Calendar
        if ($logo_google) {
            $html .= '
                <td style="padding: 0 8px;" align="center" valign="middle">
                    <a href="' . esc_url($google_url) . '" style="display: inline-block; text-decoration: none;" target="_blank">
                        <img src="' . esc_url($logo_google) . '" alt="Google Calendar" style="width: 32px; height: 32px; display: block; vertical-align: middle;">
                    </a>
                </td>';
        }

        // Outlook
        if ($logo_outlook) {
            $html .= '
                <td style="padding: 0 8px;" align="center" valign="middle">
                    <a href="' . esc_url($outlook_url) . '" style="display: inline-block; text-decoration: none;" target="_blank">
                        <img src="' . esc_url($logo_outlook) . '" alt="Outlook" style="width: 32px; height: 32px; display: block; vertical-align: middle;">
                    </a>
                </td>';
        }

        // Yahoo Calendar
        if ($logo_yahoo) {
            $html .= '
                <td style="padding: 0 8px;" align="center" valign="middle">
                    <a href="' . esc_url($yahoo_url) . '" style="display: inline-block; text-decoration: none;" target="_blank">
                        <img src="' . esc_url($logo_yahoo) . '" alt="Yahoo Calendar" style="width: 32px; height: 32px; display: block; vertical-align: middle;">
                    </a>
                </td>';
        }

        $html .= '
            </tr>
        </table>
    </center>
</div>';

        return $html;
    }

    /**
     * Generate manage booking button HTML for emails
     */
    private function generate_manage_booking_button($cancel_url) {
        $accent_color = get_option('wpbc_accent_color', '#2536eb');
        return '
<div style="margin: 20px 0; text-align: center;">
    <table cellpadding="0" cellspacing="0" align="center" style="margin: 0 auto;">
        <tr>
            <td align="center" style="border-radius: 6px; background: ' . esc_attr($accent_color) . ';">
                <a href="' . esc_url($cancel_url) . '" target="_blank" style="display: inline-block; padding: 12px 24px; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Arial, sans-serif; font-size: 14px; font-weight: 600; color: #ffffff; text-decoration: none; border-radius: 6px;">Manage Booking</a>
            </td>
        </tr>
    </table>
</div>';
    }

    /**
     * AJAX: Cancel a booking (admin only)
     */
    public function ajax_cancel_booking() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) {
            wp_send_json_error('Invalid security token');
        }

        $booking_id = intval($_POST['booking_id']);

        global $wpdb;

        // Get booking details before cancelling
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $booking_id
        ));

        if (!$booking) {
            wp_send_json_error('Booking not found');
        }

        $result = $wpdb->update(
            $this->table_name,
            array('status' => 'cancelled'),
            array('id' => $booking_id),
            array('%s'),
            array('%d')
        );

        if ($result !== false) {
            // Send cancellation email
            $this->send_booking_email('cancellation', array(
                'email' => $booking->customer_email,
                'name' => $booking->customer_name,
                'date' => $booking->booking_date,
                'time' => $booking->booking_time
            ));

            // Return booking data for WebSocket broadcast
            wp_send_json_success(array(
                'message' => 'Booking cancelled',
                'booking_id' => $booking_id,
                'date' => $booking->booking_date,
                'time' => $booking->booking_time,
                'customer_email' => $booking->customer_email,
                'customer_name' => $booking->customer_name
            ));
        } else {
            wp_send_json_error('Failed to cancel booking');
        }
    }

    /**
     * AJAX: Update a booking (admin only)
     */
    public function ajax_update_booking() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) {
            wp_send_json_error('Invalid security token');
        }

        $booking_id = intval($_POST['booking_id']);
        $new_date = sanitize_text_field($_POST['new_date']);
        $new_time = sanitize_text_field($_POST['new_time']);

        global $wpdb;

        // Get old booking details
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $booking_id
        ));

        if (!$booking) {
            wp_send_json_error('Booking not found');
        }

        // Check if new slot is available
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$this->table_name}
             WHERE booking_date = %s AND booking_time = %s AND status = 'confirmed' AND id != %d",
            $new_date, $new_time, $booking_id
        ));

        if ($existing) {
            wp_send_json_error('This time slot is not available');
        }

        $old_date = $booking->booking_date;
        $old_time = $booking->booking_time;

        $result = $wpdb->update(
            $this->table_name,
            array(
                'booking_date' => $new_date,
                'booking_time' => $new_time
            ),
            array('id' => $booking_id),
            array('%s', '%s'),
            array('%d')
        );

        if ($result !== false) {
            // Generate cancel URL
            $cancel_url = add_query_arg(array(
                'wpbc_cancel' => $booking->cancel_token,
                'booking_id' => $booking_id
            ), home_url('/'));

            // Send reschedule email
            $this->send_booking_email('reschedule', array(
                'email' => $booking->customer_email,
                'name' => $booking->customer_name,
                'old_date' => $old_date,
                'old_time' => $old_time,
                'new_date' => $new_date,
                'new_time' => $new_time,
                'booking_id' => $booking_id,
                'cancel_token' => $booking->cancel_token,
                'cancel_url' => $cancel_url
            ));

            // Return booking data for WebSocket broadcast
            wp_send_json_success(array(
                'message' => 'Booking updated',
                'booking_id' => $booking_id,
                'old_date' => $old_date,
                'old_time' => $old_time,
                'new_date' => $new_date,
                'new_time' => $new_time,
                'customer_email' => $booking->customer_email,
                'customer_name' => $booking->customer_name
            ));
        } else {
            wp_send_json_error('Failed to update booking');
        }
    }

    /**
     * AJAX: Get available time slots for a specific date
     */
    public function ajax_get_available_slots() {
        // Accept both GET and POST
        $date = isset($_POST['date']) ? sanitize_text_field($_POST['date']) : sanitize_text_field($_GET['date']);
        $booking_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : (isset($_GET['booking_id']) ? intval($_GET['booking_id']) : 0);

        if (empty($date)) {
            wp_send_json_error('Date required');
        }

        // Check if it's a configured available day
        if (!$this->is_available_day($date)) {
            wp_send_json_success(array()); // Not an available day
            return;
        }

        // All possible slots from settings
        $all_slots = $this->get_time_slots();

        // Get booked slots for this date (excluding current booking if provided)
        global $wpdb;

        if ($booking_id > 0) {
            $booked = $wpdb->get_col($wpdb->prepare(
                "SELECT booking_time FROM {$this->table_name}
                 WHERE booking_date = %s AND status = 'confirmed' AND id != %d",
                $date, $booking_id
            ));
        } else {
            $booked = $wpdb->get_col($wpdb->prepare(
                "SELECT booking_time FROM {$this->table_name}
                 WHERE booking_date = %s AND status = 'confirmed'",
                $date
            ));
        }

        // Get manually blocked slots for this date
        $blocked = $wpdb->get_col($wpdb->prepare(
            "SELECT block_time FROM {$this->blocks_table} WHERE block_date = %s",
            $date
        ));

        // Filter out booked AND blocked slots
        $unavailable = array_merge($booked, $blocked);
        $available = array_values(array_diff($all_slots, $unavailable));

        // If "block rest of today" is active, return no slots for today
        $today = current_time('Y-m-d');
        if ($date === $today && get_transient('wpbc_block_today') === $today) {
            wp_send_json_success(array());
            return;
        }

        wp_send_json_success($available);
    }

    // Properties to store modal state
    private $modal_status = null;
    private $modal_message = null;
    private $modal_booking = null;

    /**
     * Handle token-based cancellation from email link
     */
    public function handle_token_cancellation() {
        if (!isset($_GET['wpbc_cancel']) || !isset($_GET['booking_id'])) {
            return;
        }

        $token = sanitize_text_field($_GET['wpbc_cancel']);
        $booking_id = intval($_GET['booking_id']);

        if (empty($token) || empty($booking_id)) {
            return;
        }

        global $wpdb;

        // Verify token and get booking
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d AND cancel_token = %s",
            $booking_id, $token
        ));

        if (!$booking) {
            $this->modal_status = 'error';
            $this->modal_message = 'Invalid or expired cancellation link.';
            add_action('wp_footer', array($this, 'render_modal_overlay'), 9999);
            return;
        }

        if ($booking->status === 'cancelled') {
            $this->modal_status = 'already_cancelled';
            $this->modal_message = 'This booking has already been cancelled.';
            add_action('wp_footer', array($this, 'render_modal_overlay'), 9999);
            return;
        }

        // Check if user is actually cancelling (action=cancel in URL)
        if (isset($_GET['action']) && $_GET['action'] === 'cancel') {
            $wpdb->update(
                $this->table_name,
                array('status' => 'cancelled'),
                array('id' => $booking_id),
                array('%s'),
                array('%d')
            );

            $this->send_booking_email('cancellation', array(
                'email' => $booking->customer_email,
                'name' => $booking->customer_name,
                'date' => $booking->booking_date,
                'time' => $booking->booking_time
            ));

            $this->modal_status = 'cancelled';
            add_action('wp_footer', array($this, 'render_modal_overlay'), 9999);
            return;
        }

        // Check if user just rescheduled
        if (isset($_GET['rescheduled']) && $_GET['rescheduled'] === '1') {
            $this->modal_status = 'rescheduled';
            add_action('wp_footer', array($this, 'render_modal_overlay'), 9999);
            return;
        }

        // Show manage page (cancel or reschedule)
        $this->modal_status = 'manage';
        $this->modal_booking = $booking;
        add_action('wp_footer', array($this, 'render_modal_overlay'), 9999);
    }

    /**
     * Render modal overlay in footer
     */
    public function render_modal_overlay() {
        $status = $this->modal_status;
        $message = $this->modal_message;
        $booking = $this->modal_booking;

        $site_name = get_bloginfo('name');
        $accent_color = get_option('wpbc_accent_color', '#2536eb');
        $plugin_css_url = plugin_dir_url(__FILE__) . 'css/booking-calendar.css';

        // Get booked slots for calendar (if showing manage page)
        $booked_slots = array();
        $available_slots_by_date = array();

        if ($status === 'manage' && $booking) {
            global $wpdb;
            // Include ALL confirmed bookings for visual display
            $bookings = $wpdb->get_results(
                "SELECT booking_date, booking_time FROM {$this->table_name}
                WHERE status = 'confirmed'"
            );
            foreach ($bookings as $b) {
                $booked_slots[] = array(
                    'date' => $b->booking_date,
                    'time' => $b->booking_time
                );
            }

            // Include manual blocks from blocks table
            $blocks = $wpdb->get_results(
                "SELECT block_date, block_time FROM {$this->blocks_table}"
            );
            foreach ($blocks as $block) {
                $booked_slots[] = array(
                    'date' => $block->block_date,
                    'time' => $block->block_time
                );
            }

            // If block-today is active, add all configured slots for today as booked
            $today      = current_time('Y-m-d');
            $block_date = get_transient('wpbc_block_today');
            if ($block_date === $today) {
                foreach ($this->get_time_slots() as $slot) {
                    $booked_slots[] = array('date' => $today, 'time' => $slot);
                }
            }

            // Pre-calculate available slots for the calendar to show availability colors
            $all_slots = $this->get_time_slots();
            $booked_by_date = array();
            foreach ($booked_slots as $bs) {
                if (!isset($booked_by_date[$bs['date']])) {
                    $booked_by_date[$bs['date']] = array();
                }
                $booked_by_date[$bs['date']][] = $bs['time'];
            }

            // Calculate for next 60 days
            for ($i = 0; $i < 60; $i++) {
                $check_date = date('Y-m-d', strtotime("+{$i} days"));
                $check_day_of_week = date('N', strtotime($check_date));

                if (!$this->is_available_day($check_day_of_week)) {
                    continue;
                }

                $booked_for_date = isset($booked_by_date[$check_date]) ? $booked_by_date[$check_date] : array();
                $available_count = count($all_slots) - count($booked_for_date);
                $available_slots_by_date[$check_date] = $available_count;
            }
        }

        // Render modal overlay (injected into footer)
        ?>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        <link rel="stylesheet" href="<?php echo esc_url($plugin_css_url); ?>">
        <style>
            :root {
                --wpbc-accent-color: <?php echo esc_attr($accent_color); ?>;
            }

            /* Modal Overlay */
            .wpbc-modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
                z-index: 999999;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
                backdrop-filter: blur(8px);
                -webkit-backdrop-filter: blur(8px);
                animation: wpbc-modal-fade-in 0.3s ease;
            }

            /* Blur the background page */
            body.wpbc-modal-open > *:not(.wpbc-modal-overlay) {
                filter: blur(5px);
                -webkit-filter: blur(5px);
                transition: filter 0.3s ease;
            }

            body.wpbc-modal-open {
                overflow: hidden;
            }

            @keyframes wpbc-modal-fade-in {
                from {
                    opacity: 0;
                }
                to {
                    opacity: 1;
                }
            }

            .wpbc-modal-content {
                position: relative;
                max-width: 780px;
                width: 100%;
                animation: wpbc-modal-slide-up 0.3s ease;
            }

            @keyframes wpbc-modal-slide-up {
                from {
                    transform: translateY(30px);
                    opacity: 0;
                }
                to {
                    transform: translateY(0);
                    opacity: 1;
                }
            }

            /* Close button */
            .wpbc-modal-close {
                position: absolute;
                top: 16px;
                right: 16px;
                background: rgba(0, 0, 0, 0.05);
                border: 1px solid rgba(0, 0, 0, 0.1);
                border-radius: 50%;
                width: 32px;
                height: 32px;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                z-index: 10;
                transition: all 0.15s ease;
                font-size: 20px;
                color: #666;
                font-family: inherit;
            }

            .wpbc-modal-close:hover {
                background: rgba(0, 0, 0, 0.1);
                transform: scale(1.1);
            }

            /* Manage page specific styles */
            .wpbc-manage-container .wpbc-card {
                margin-bottom: 0;
            }

            .wpbc-manage-header {
                text-align: center;
                margin-bottom: 24px;
            }

            .wpbc-manage-title {
                font-size: 26px;
                font-weight: 700;
                letter-spacing: -0.5px;
                margin: 0 0 6px;
                color: #1a1a1a;
            }

            .wpbc-manage-subtitle {
                font-size: 14px;
                color: #888;
                margin: 0;
            }

            .wpbc-booking-info {
                background: #f9f9f9;
                border: 1px solid #eee;
                border-radius: 12px;
                padding: 20px;
                margin-bottom: 24px;
            }

            .wpbc-info-row {
                display: flex;
                justify-content: space-between;
                font-size: 13px;
                padding-bottom: 10px;
                margin-bottom: 10px;
                border-bottom: 1px solid #f0f0f0;
            }

            .wpbc-info-row:last-child {
                border-bottom: none;
                margin: 0;
                padding: 0;
            }

            .wpbc-info-label {
                color: #aaa;
                font-weight: 500;
            }

            .wpbc-info-value {
                font-weight: 600;
                color: #1a1a1a;
                text-align: right;
                max-width: 60%;
            }

            .wpbc-action-buttons {
                display: flex;
                gap: 12px;
                margin-bottom: 24px;
            }

            .wpbc-action-btn {
                flex: 1;
                background: var(--wpbc-accent-color, #2536eb);
                color: #fff;
                border: none;
                border-radius: 10px;
                padding: 14px;
                font-size: 14px;
                font-weight: 600;
                cursor: pointer;
                font-family: inherit;
                transition: all 0.15s ease;
            }

            .wpbc-action-btn:hover {
                transform: translateY(-1px);
                box-shadow: 0 4px 12px rgba(37, 54, 235, 0.3);
            }

            .wpbc-action-btn.danger {
                background: #fff;
                color: #dc2626;
                border: 1.5px solid #fecaca;
            }

            .wpbc-action-btn.danger:hover {
                background: #fef2f2;
                box-shadow: 0 4px 12px rgba(220, 38, 38, 0.2);
            }

            .wpbc-reschedule-section {
                display: none;
                padding-top: 24px;
                border-top: 1px solid #f0f0f0;
            }

            .wpbc-reschedule-section.active {
                display: block;
            }

            .wpbc-reschedule-section .wpbc-slots-col {
                display: flex;
                flex-direction: column;
            }

            .wpbc-reschedule-section .wpbc-slots-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 8px;
            }

            .wpbc-reschedule-section .wpbc-slots-empty-state {
                grid-column: 1 / -1;
                color: #ccc;
                text-align: center;
                padding-top: 48px;
            }

            .wpbc-reschedule-section .wpbc-slots-empty-state span {
                font-size: 32px;
                display: block;
                margin-bottom: 8px;
            }

            .wpbc-reschedule-section .wpbc-slots-empty-state p {
                font-size: 13px;
                margin: 0;
            }

            .wpbc-reschedule-title {
                font-size: 16px;
                font-weight: 700;
                margin-bottom: 20px;
                color: #1a1a1a;
            }

            /* Status messages */
            .wpbc-status-message {
                text-align: center;
                padding: 32px 0 16px;
            }

            .wpbc-status-icon {
                width: 56px;
                height: 56px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 22px;
                margin: 0 auto 20px;
            }

            .wpbc-status-icon.success {
                background: #f0f3ff;
                border: 2px solid rgba(37, 54, 235, 0.2);
                color: var(--wpbc-accent-color, #2536eb);
            }

            .wpbc-status-icon.error {
                background: #fef2f2;
                border: 2px solid rgba(220, 38, 38, 0.2);
                color: #dc2626;
            }

            .wpbc-status-message h2 {
                font-size: 22px;
                font-weight: 700;
                letter-spacing: -0.4px;
                margin: 0 0 6px;
                color: #1a1a1a;
            }

            .wpbc-status-message p {
                font-size: 14px;
                color: #888;
                margin: 0 0 24px;
            }

            .wpbc-message-box {
                background: #f9f9f9;
                border: 1px solid #eee;
                border-radius: 12px;
                padding: 16px;
                font-size: 14px;
                margin-bottom: 24px;
            }

            .wpbc-message-box.success {
                background: #ecfdf3;
                border-color: #abefc6;
                color: #065f46;
            }

            .wpbc-message-box.error {
                background: #fff2f2;
                border-color: #fdcdcd;
                color: #991b1b;
            }

            @media (max-width: 640px) {
                .wpbc-modal-content {
                    width: 95%;
                    margin: 0 auto;
                }

                .wpbc-action-buttons {
                    flex-direction: column;
                }

                .wpbc-modal-close {
                    top: 12px;
                    right: 12px;
                }

                .wpbc-manage-title {
                    font-size: 22px;
                }

                .wpbc-booking-info {
                    padding: 16px;
                }

                .wpbc-reschedule-section .wpbc-date-time-grid {
                    grid-template-columns: 1fr;
                    gap: 20px;
                }

                .wpbc-reschedule-section .wpbc-slots-grid {
                    max-height: none;
                }
            }
        </style>

        <div class="wpbc-modal-overlay">
            <div class="wpbc-modal-content">
                <button class="wpbc-modal-close" onclick="wpbcCloseModal()" aria-label="Close">&times;</button>

                <div class="wpbc-manage-container">
                    <?php if ($status === 'error'): ?>
                        <div class="wpbc-card">
                            <div class="wpbc-card-body">
                                <div class="wpbc-status-message">
                                    <div class="wpbc-status-icon error">✕</div>
                                    <h2>Error</h2>
                                    <p>This booking link could not be processed.</p>
                                    <div class="wpbc-message-box error"><?php echo esc_html($message); ?></div>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($status === 'already_cancelled'): ?>
                        <div class="wpbc-card">
                            <div class="wpbc-card-body">
                                <div class="wpbc-status-message">
                                    <div class="wpbc-status-icon error">✕</div>
                                    <h2>Already Cancelled</h2>
                                    <p>This appointment was previously canceled.</p>
                                    <div class="wpbc-message-box error"><?php echo esc_html($message); ?></div>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($status === 'cancelled'): ?>
                        <div class="wpbc-card">
                            <div class="wpbc-card-body">
                                <div class="wpbc-status-message">
                                    <div class="wpbc-status-icon success">✓</div>
                                    <h2>Booking Cancelled</h2>
                                    <p>Your time has been released in the calendar.</p>
                                    <div class="wpbc-message-box success">Your booking has been successfully cancelled.</div>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($status === 'rescheduled'): ?>
                        <div class="wpbc-card">
                            <div class="wpbc-card-body">
                                <div class="wpbc-status-message">
                                    <div class="wpbc-status-icon success">✓</div>
                                    <h2>Booking Rescheduled</h2>
                                    <p>Your updated appointment details are now active.</p>
                                    <div class="wpbc-message-box success">Your booking has been successfully rescheduled. You will receive a confirmation email shortly.</div>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($status === 'manage' && $booking): ?>
                        <div class="wpbc-card">
                            <div class="wpbc-card-body">
                                <div class="wpbc-manage-header">
                                    <h1 class="wpbc-manage-title">Manage Your Booking</h1>
                                    <p class="wpbc-manage-subtitle">Choose to cancel or pick a new available time.</p>
                                </div>

                                <div class="wpbc-booking-info">
                                    <div class="wpbc-info-row">
                                        <span class="wpbc-info-label">Name</span>
                                        <span class="wpbc-info-value"><?php echo esc_html($booking->customer_name); ?></span>
                                    </div>
                                    <div class="wpbc-info-row">
                                        <span class="wpbc-info-label">Date</span>
                                        <span class="wpbc-info-value"><?php echo esc_html(date('l, F j, Y', strtotime($booking->booking_date))); ?></span>
                                    </div>
                                    <div class="wpbc-info-row">
                                        <span class="wpbc-info-label">Time</span>
                                        <span class="wpbc-info-value"><?php echo esc_html($booking->booking_time); ?></span>
                                    </div>
                                    <div class="wpbc-info-row">
                                        <span class="wpbc-info-label">Booking ID</span>
                                        <span class="wpbc-info-value">#<?php echo esc_html($booking->id); ?></span>
                                    </div>
                                </div>

                                <div class="wpbc-action-buttons">
                                    <button class="wpbc-action-btn" onclick="wpbcShowReschedule()">Reschedule Appointment</button>
                                    <button class="wpbc-action-btn danger" onclick="wpbcConfirmCancel()">Cancel Appointment</button>
                                </div>

                                <div id="wpbc-reschedule-section" class="wpbc-reschedule-section">
                                    <h3 class="wpbc-reschedule-title">Choose a New Date & Time</h3>

                                    <div class="wpbc-date-time-grid">
                                        <div class="wpbc-calendar-col">
                                            <input type="text" id="wpbc-reschedule-calendar" style="display: none;">
                                        </div>
                                        <div class="wpbc-slots-col">
                                            <div id="wpbc-reschedule-slots" class="wpbc-slots-grid">
                                                <div class="wpbc-slots-empty-state"><span>📅</span><p>Select a date to see available times</p></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="wpbc-continue-row">
                                        <button class="wpbc-continue-btn" onclick="wpbcSubmitReschedule()" id="wpbc-confirm-reschedule-btn" disabled>Confirm Reschedule</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if ($status === 'manage' && $booking): ?>
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script>
            // Add modal-open class to body
            document.body.classList.add('wpbc-modal-open');

            const wpbcBookingId = <?php echo json_encode($booking->id); ?>;
            const wpbcCancelToken = <?php echo json_encode($booking->cancel_token); ?>;
            const wpbcAjaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
            const wpbcBookedSlots = <?php echo json_encode($booked_slots); ?>;
            const wpbcAvailableDays = <?php echo json_encode($this->get_available_days()); ?>;
            const wpbcAllTimeSlots = <?php echo json_encode($this->get_time_slots()); ?>;
            const wpbcAvailabilityByDate = <?php echo json_encode($available_slots_by_date); ?>;

            let wpbcSelectedDate = null;
            let wpbcSelectedTime = null;
            let wpbcAvailableSlots = [];
            let wpbcFlatpickr = null;

            function wpbcCloseModal() {
                const overlay = document.querySelector('.wpbc-modal-overlay');
                document.body.classList.remove('wpbc-modal-open');
                overlay.style.opacity = '0';
                overlay.style.transition = 'opacity 0.3s ease';
                setTimeout(() => {
                    overlay.remove();
                }, 300);
            }

            function wpbcShowReschedule() {
                const section = document.getElementById('wpbc-reschedule-section');
                section.classList.add('active');
                section.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

                // Initialize Flatpickr if not already done
                if (!wpbcFlatpickr) {
                    wpbcFlatpickr = flatpickr('#wpbc-reschedule-calendar', {
                        inline: true,
                        minDate: 'today',
                        dateFormat: 'Y-m-d',
                        disable: [
                            function(date) {
                                const dayOfWeek = date.getDay() === 0 ? 7 : date.getDay();
                                return !wpbcAvailableDays.includes(dayOfWeek);
                            }
                        ],
                        onChange: function(selectedDates, dateStr) {
                            wpbcSelectedDate = dateStr;
                            wpbcSelectedTime = null;
                            wpbcLoadAvailableSlots(dateStr);
                            document.getElementById('wpbc-confirm-reschedule-btn').disabled = true;
                            // Reapply colors after selection
                            setTimeout(wpbcColorCalendarCells, 0);
                            requestAnimationFrame(wpbcColorCalendarCells);
                        },
                        onReady: function() {
                            wpbcColorCalendarCells();
                            setTimeout(wpbcColorCalendarCells, 0);
                            requestAnimationFrame(wpbcColorCalendarCells);
                        },
                        onMonthChange: function() {
                            wpbcColorCalendarCells();
                            setTimeout(wpbcColorCalendarCells, 50);
                            requestAnimationFrame(wpbcColorCalendarCells);
                        }
                    });
                }
            }

            function wpbcHideReschedule() {
                const section = document.getElementById('wpbc-reschedule-section');
                section.classList.remove('active');
                document.getElementById('wpbc-confirm-reschedule-btn').disabled = true;
                wpbcSelectedDate = null;
                wpbcSelectedTime = null;
            }

            function wpbcConfirmCancel() {
                if (confirm('Are you sure you want to cancel this appointment?')) {
                    // Call AJAX to cancel the booking
                    const formData = new FormData();
                    formData.append('action', 'wpbc_cancel_booking_public');
                    formData.append('booking_id', wpbcBookingId);
                    formData.append('token', wpbcCancelToken);

                    fetch(wpbcAjaxUrl, {
                        method: 'POST',
                        body: formData
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            wpbcShowSuccessMessage('Booking Cancelled', 'Your time has been released in the calendar.', 'Your booking has been successfully cancelled.');
                        } else {
                            alert('Error: ' + (data.data || 'Could not cancel booking'));
                        }
                    })
                    .catch(err => {
                        alert('Error cancelling booking. Please try again.');
                    });
                }
            }

            function wpbcColorCalendarCells() {
                const cells = document.querySelectorAll('.flatpickr-day');
                cells.forEach(cell => {
                    const ariaLabel = cell.getAttribute('aria-label');
                    if (!ariaLabel) return;

                    const parsed = new Date(ariaLabel);
                    if (isNaN(parsed)) return;

                    const year = parsed.getFullYear();
                    const month = String(parsed.getMonth() + 1).padStart(2, '0');
                    const day = String(parsed.getDate()).padStart(2, '0');
                    const dateKey = year + '-' + month + '-' + day;

                    // Disabled cells are always booked
                    if (cell.classList.contains('flatpickr-disabled')) {
                        cell.setAttribute('data-availability', 'booked');
                        return;
                    }

                    const availableCount = wpbcAvailabilityByDate[dateKey] || 0;

                    if (availableCount > 3) {
                        cell.setAttribute('data-availability', 'open');
                    } else if (availableCount >= 1) {
                        cell.setAttribute('data-availability', 'limited');
                    } else {
                        cell.setAttribute('data-availability', 'booked');
                    }
                });
            }

            function wpbcLoadAvailableSlots(date) {
                fetch(wpbcAjaxUrl + '?action=wpbc_get_available_slots&date=' + encodeURIComponent(date) + '&booking_id=' + wpbcBookingId)
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            wpbcAvailableSlots = data.data;
                            wpbcRenderTimeSlots();
                        }
                    });
            }

            function wpbcRenderTimeSlots() {
                const container = document.getElementById('wpbc-reschedule-slots');
                container.innerHTML = '';

                if (!wpbcAvailableSlots.length) {
                    container.innerHTML = '<div class="wpbc-slots-empty-state"><span>📅</span><p>No available slots</p></div>';
                    return;
                }

                wpbcAvailableSlots.forEach(slot => {
                    const btn = document.createElement('button');
                    btn.className = 'wpbc-time-slot';
                    btn.textContent = slot;
                    btn.onclick = () => wpbcSelectTimeSlot(slot, btn);
                    container.appendChild(btn);
                });
            }

            function wpbcSelectTimeSlot(slot, element) {
                wpbcSelectedTime = slot;
                document.querySelectorAll('#wpbc-reschedule-slots .wpbc-time-slot').forEach(el => {
                    el.classList.remove('selected');
                });
                if (element) {
                    element.classList.add('selected');
                }
                document.getElementById('wpbc-confirm-reschedule-btn').disabled = false;
            }

            function wpbcSubmitReschedule() {
                if (!wpbcSelectedDate || !wpbcSelectedTime) {
                    alert('Please select both a date and time');
                    return;
                }

                const formData = new FormData();
                formData.append('action', 'wpbc_reschedule_booking');
                formData.append('booking_id', wpbcBookingId);
                formData.append('token', wpbcCancelToken);
                formData.append('new_date', wpbcSelectedDate);
                formData.append('new_time', wpbcSelectedTime);

                fetch(wpbcAjaxUrl, {
                    method: 'POST',
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        wpbcShowSuccessMessage('Booking Rescheduled', 'Your updated appointment details are now active.', 'Your booking has been successfully rescheduled. You will receive a confirmation email shortly.');
                    } else {
                        alert(data.data.message || 'Failed to reschedule booking');
                    }
                });
            }

            function wpbcShowSuccessMessage(title, subtitle, message) {
                const manageContainer = document.querySelector('.wpbc-manage-container');
                manageContainer.innerHTML = `
                    <div class="wpbc-card">
                        <div class="wpbc-card-body">
                            <div class="wpbc-status-message">
                                <div class="wpbc-status-icon success">✓</div>
                                <h2>${title}</h2>
                                <p>${subtitle}</p>
                                <div class="wpbc-message-box success">${message}</div>
                                <button class="wpbc-reset-btn" onclick="wpbcCloseModal()" style="margin-top: 16px; padding: 12px 24px;">Close</button>
                            </div>
                        </div>
                    </div>
                `;
            }
        </script>
        <?php else: ?>
        <script>
            // Add modal-open class to body
            document.body.classList.add('wpbc-modal-open');

            function wpbcCloseModal() {
                const overlay = document.querySelector('.wpbc-modal-overlay');
                document.body.classList.remove('wpbc-modal-open');
                overlay.style.opacity = '0';
                overlay.style.transition = 'opacity 0.3s ease';
                setTimeout(() => {
                    overlay.remove();
                }, 300);
            }
        </script>
        <?php endif; ?>

        <style>
            @keyframes wpbc-modal-fade-out {
                from { opacity: 1; }
                to { opacity: 0; }
            }
        </style>
        <?php
    }

    /**
     * AJAX: Reschedule booking (public endpoint with token auth)
     */
    public function ajax_reschedule_booking() {
        global $wpdb;

        $booking_id = intval($_POST['booking_id']);
        $token = sanitize_text_field($_POST['token']);
        $new_date = sanitize_text_field($_POST['new_date']);
        $new_time = sanitize_text_field($_POST['new_time']);

        // Verify token
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d AND cancel_token = %s",
            $booking_id, $token
        ));

        if (!$booking) {
            wp_send_json_error(array('message' => 'Invalid token'));
        }

        if ($booking->status === 'cancelled') {
            wp_send_json_error(array('message' => 'This booking has been cancelled'));
        }

        // Check if new slot is available
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name}
            WHERE booking_date = %s AND booking_time = %s
            AND status = 'confirmed' AND id != %d",
            $new_date, $new_time, $booking_id
        ));

        if ($existing > 0) {
            wp_send_json_error(array('message' => 'This time slot is no longer available'));
        }

        // Store old values for email
        $old_date = $booking->booking_date;
        $old_time = $booking->booking_time;

        // Update booking
        $result = $wpdb->update(
            $this->table_name,
            array(
                'booking_date' => $new_date,
                'booking_time' => $new_time
            ),
            array('id' => $booking_id),
            array('%s', '%s'),
            array('%d')
        );

        if ($result !== false) {
            // Generate cancel URL
            $cancel_url = add_query_arg(array(
                'wpbc_cancel' => $booking->cancel_token,
                'booking_id' => $booking->id
            ), home_url('/'));

            // Send reschedule email
            $this->send_booking_email('reschedule', array(
                'email' => $booking->customer_email,
                'name' => $booking->customer_name,
                'old_date' => $old_date,
                'old_time' => $old_time,
                'new_date' => $new_date,
                'new_time' => $new_time,
                'booking_id' => $booking->id,
                'cancel_token' => $booking->cancel_token,
                'cancel_url' => $cancel_url
            ));

            wp_send_json_success();
        } else {
            wp_send_json_error(array('message' => 'Failed to update booking'));
        }
    }

    /**
     * AJAX: Cancel booking (public endpoint with token auth)
     */
    public function ajax_cancel_booking_public() {
        global $wpdb;

        $booking_id = intval($_POST['booking_id']);
        $token = sanitize_text_field($_POST['token']);

        // Verify token
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d AND cancel_token = %s",
            $booking_id, $token
        ));

        if (!$booking) {
            wp_send_json_error('Invalid token or booking not found');
        }

        if ($booking->status === 'cancelled') {
            wp_send_json_error('This booking has already been cancelled');
        }

        // Update status to cancelled
        $result = $wpdb->update(
            $this->table_name,
            array('status' => 'cancelled'),
            array('id' => $booking_id),
            array('%s'),
            array('%d')
        );

        if ($result !== false) {
            // Send cancellation email
            $this->send_booking_email('cancellation', array(
                'email' => $booking->customer_email,
                'name' => $booking->customer_name,
                'date' => $booking->booking_date,
                'time' => $booking->booking_time
            ));

            wp_send_json_success();
        } else {
            wp_send_json_error('Failed to cancel booking');
        }
    }

    /**
     * AJAX: Toggle manual block for slot/day
     */
    public function ajax_toggle_block() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) {
            wp_send_json_error('Invalid security token');
        }

        global $wpdb;

        $date = sanitize_text_field($_POST['date']);
        $time = sanitize_text_field($_POST['time']);
        $block_all = isset($_POST['block_all']) && $_POST['block_all'];
        $unblock_all = isset($_POST['unblock_all']) && $_POST['unblock_all'];

        if ($block_all) {
            // Block all unbooked slots for this date
            $time_slots = $this->get_time_slots();
            $booked = $wpdb->get_col($wpdb->prepare(
                "SELECT booking_time FROM {$this->table_name} WHERE booking_date = %s AND status = 'confirmed'",
                $date
            ));

            foreach ($time_slots as $slot) {
                if (!in_array($slot, $booked)) {
                    $wpdb->replace($this->blocks_table, array(
                        'block_date' => $date,
                        'block_time' => $slot,
                        'block_type' => 'slot'
                    ), array('%s', '%s', '%s'));
                }
            }
            wp_send_json_success(array('blocked_all' => true));

        } elseif ($unblock_all) {
            // Remove all blocks for this date
            $wpdb->delete($this->blocks_table, array('block_date' => $date), array('%s'));
            wp_send_json_success(array('unblocked_all' => true));

        } else {
            // Toggle single slot
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$this->blocks_table} WHERE block_date = %s AND block_time = %s",
                $date, $time
            ));

            if ($exists) {
                $wpdb->delete($this->blocks_table, array('block_date' => $date, 'block_time' => $time), array('%s', '%s'));
                wp_send_json_success(array('blocked' => false));
            } else {
                $wpdb->insert($this->blocks_table, array(
                    'block_date' => $date,
                    'block_time' => $time,
                    'block_type' => 'slot'
                ), array('%s', '%s', '%s'));
                wp_send_json_success(array('blocked' => true));
            }
        }
    }

    /**
     * AJAX: Get all blocks
     */
    public function ajax_get_blocks() {
        global $wpdb;
        $blocks = $wpdb->get_results("SELECT block_date, block_time FROM {$this->blocks_table}");
        wp_send_json_success($blocks);
    }

    /**
     * AJAX: Get calendar data (blocks + bookings)
     */
    public function ajax_get_calendar_data() {
        global $wpdb;

        $blocks = $wpdb->get_results("SELECT block_date, block_time FROM {$this->blocks_table}");
        $bookings = $wpdb->get_results(
            "SELECT booking_date, booking_time FROM {$this->table_name} WHERE status = 'confirmed'"
        );

        wp_send_json_success(array(
            'blocks' => $blocks,
            'bookings' => $bookings
        ));
    }

    /**
     * Cron job: Send reminder emails for upcoming appointments
     */
    public function send_reminder_emails($return_details = false) {
        global $wpdb;

        // Check for simulated time (for testing)
        $simulated_time = get_option('wpbc_simulated_time', '');
        if ($simulated_time) {
            $now = $simulated_time;
            $base_timestamp = strtotime($simulated_time);
        } else {
            $now = current_time('mysql');
            $base_timestamp = current_time('timestamp');
        }

        $one_day_from_now = date('Y-m-d H:i:s', strtotime('+24 hours', $base_timestamp));
        $one_hour_from_now = date('Y-m-d H:i:s', strtotime('+1 hour', $base_timestamp));

        $details = array();
        $details[] = "Current time (simulated: " . ($simulated_time ? 'yes' : 'no') . "): " . $now;
        $details[] = "24h window: " . $now . " to " . $one_day_from_now;
        $details[] = "1h window: " . $now . " to " . $one_hour_from_now;

        // Get bookings that need 24-hour reminders
        // Use STR_TO_DATE to properly parse AM/PM time format
        $day_reminders = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name}
            WHERE status = 'confirmed'
            AND reminder_24h_sent = 0
            AND STR_TO_DATE(CONCAT(booking_date, ' ', booking_time), '%%Y-%%m-%%d %%h:%%i %%p') BETWEEN %s AND %s",
            $now, $one_day_from_now
        ));

        // Get bookings that need 1-hour reminders (only after 24h reminder has been sent)
        // Use STR_TO_DATE to properly parse AM/PM time format
        $hour_reminders = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name}
            WHERE status = 'confirmed'
            AND reminder_24h_sent = 1
            AND reminder_1h_sent = 0
            AND STR_TO_DATE(CONCAT(booking_date, ' ', booking_time), '%%Y-%%m-%%d %%h:%%i %%p') BETWEEN %s AND %s",
            $now, $one_hour_from_now
        ));

        $details[] = "Found " . count($day_reminders) . " bookings for 24h reminders";
        $details[] = "Found " . count($hour_reminders) . " bookings for 1h reminders";

        $sent_count = 0;

        // Send 24-hour reminders
        foreach ($day_reminders as $booking) {
            // Ensure booking has a cancel token (generate if missing)
            $cancel_token = $booking->cancel_token;
            if (empty($cancel_token)) {
                $cancel_token = wp_generate_password(32, false, false);
                $wpdb->update(
                    $this->table_name,
                    array('cancel_token' => $cancel_token),
                    array('id' => $booking->id),
                    array('%s'),
                    array('%d')
                );
                $details[] = "Generated missing cancel_token for booking #{$booking->id}";
            }

            $cancel_url = add_query_arg(array(
                'wpbc_cancel' => $cancel_token,
                'booking_id' => $booking->id
            ), home_url('/'));

            $sent = $this->send_booking_email('reminder', array(
                'email' => $booking->customer_email,
                'name' => $booking->customer_name,
                'date' => $booking->booking_date,
                'time' => $booking->booking_time,
                'booking_id' => $booking->id,
                'cancel_url' => $cancel_url,
                'reminder_type' => '24 hours'
            ));

            $details[] = "24h reminder to {$booking->customer_email} for booking #{$booking->id}: " . ($sent ? 'SENT' : 'FAILED');

            if ($sent) {
                $sent_count++;
                // Mark as sent
                $wpdb->update(
                    $this->table_name,
                    array('reminder_24h_sent' => 1),
                    array('id' => $booking->id),
                    array('%d'),
                    array('%d')
                );
            }
        }

        // Send 1-hour reminders
        foreach ($hour_reminders as $booking) {
            $cancel_token = $booking->cancel_token;
            if (empty($cancel_token)) {
                $cancel_token = wp_generate_password(32, false, false);
                $wpdb->update(
                    $this->table_name,
                    array('cancel_token' => $cancel_token),
                    array('id' => $booking->id),
                    array('%s'),
                    array('%d')
                );
            }

            $cancel_url = add_query_arg(array(
                'wpbc_cancel' => $cancel_token,
                'booking_id' => $booking->id
            ), home_url('/'));

            $sent = $this->send_booking_email('reminder', array(
                'email' => $booking->customer_email,
                'name' => $booking->customer_name,
                'date' => $booking->booking_date,
                'time' => $booking->booking_time,
                'booking_id' => $booking->id,
                'cancel_url' => $cancel_url,
                'reminder_type' => '1 hour'
            ));

            $details[] = "1h reminder to {$booking->customer_email} for booking #{$booking->id}: " . ($sent ? 'SENT' : 'FAILED');

            if ($sent) {
                $sent_count++;
                // Mark as sent
                $wpdb->update(
                    $this->table_name,
                    array('reminder_1h_sent' => 1),
                    array('id' => $booking->id),
                    array('%d'),
                    array('%d')
                );
            }
        }

        $details[] = "Total reminders sent: {$sent_count}";

        if ($return_details) {
            return $details;
        }
    }

    /**
     * Schedule reminder cron job if not already scheduled
     */
    public function schedule_reminder_cron() {
        if (!wp_next_scheduled('wpbc_send_reminders')) {
            wp_schedule_event(time(), 'hourly', 'wpbc_send_reminders');
        }
    }

    /**
     * AJAX: Fix missing cancel tokens
     */
    public function ajax_fix_missing_tokens() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) {
            wp_send_json_error('Invalid security token');
        }

        global $wpdb;

        $bookings = $wpdb->get_results(
            "SELECT id FROM {$this->table_name} WHERE cancel_token = '' OR cancel_token IS NULL"
        );

        $fixed = 0;
        foreach ($bookings as $booking) {
            $cancel_token = wp_generate_password(32, false, false);
            $wpdb->update(
                $this->table_name,
                array('cancel_token' => $cancel_token),
                array('id' => $booking->id),
                array('%s'),
                array('%d')
            );
            $fixed++;
        }

        wp_send_json_success(array('fixed' => $fixed));
    }

    /**
     * AJAX handler for ICS file download
     */
    public function ajax_download_ics() {
        // Get parameters
        $date = sanitize_text_field($_GET['date'] ?? '');
        $time = sanitize_text_field($_GET['time'] ?? '');
        $title = sanitize_text_field($_GET['title'] ?? 'Appointment');
        $description = sanitize_text_field($_GET['description'] ?? '');
        $location = sanitize_text_field($_GET['location'] ?? '');

        if (empty($date) || empty($time)) {
            wp_die('Missing required parameters');
        }

        // Parse the time to convert to 24-hour format
        $time_24h = date('H:i:s', strtotime($time));
        $datetime = strtotime($date . ' ' . $time_24h);
        $end_datetime = $datetime + 3600; // 1 hour appointment

        // Get the site's timezone
        $timezone = wp_timezone_string();

        // Format dates for ICS (UTC)
        $dtstart = gmdate('Ymd\THis\Z', $datetime);
        $dtend = gmdate('Ymd\THis\Z', $end_datetime);
        $dtstamp = gmdate('Ymd\THis\Z');

        // Generate unique UID
        $uid = md5($date . $time . $title) . '@' . parse_url(home_url(), PHP_URL_HOST);

        // Escape text for ICS format
        $title = $this->ics_escape_text($title);
        $description = $this->ics_escape_text($description);
        $location = $this->ics_escape_text($location);

        // Build ICS content
        $ics = "BEGIN:VCALENDAR\r\n";
        $ics .= "VERSION:2.0\r\n";
        $ics .= "PRODID:-//MA Calendar//Booking System//EN\r\n";
        $ics .= "CALSCALE:GREGORIAN\r\n";
        $ics .= "METHOD:PUBLISH\r\n";
        $ics .= "X-WR-TIMEZONE:{$timezone}\r\n";
        $ics .= "BEGIN:VEVENT\r\n";
        $ics .= "UID:{$uid}\r\n";
        $ics .= "DTSTAMP:{$dtstamp}\r\n";
        $ics .= "DTSTART:{$dtstart}\r\n";
        $ics .= "DTEND:{$dtend}\r\n";
        $ics .= "SUMMARY:{$title}\r\n";
        if (!empty($description)) {
            $ics .= "DESCRIPTION:{$description}\r\n";
        }
        if (!empty($location)) {
            $ics .= "LOCATION:{$location}\r\n";
        }
        $ics .= "STATUS:CONFIRMED\r\n";

        // Add reminders: 24 hours and 1 hour before
        $ics .= "BEGIN:VALARM\r\n";
        $ics .= "ACTION:DISPLAY\r\n";
        $ics .= "DESCRIPTION:Reminder: Appointment tomorrow\r\n";
        $ics .= "TRIGGER:-PT24H\r\n";
        $ics .= "END:VALARM\r\n";

        $ics .= "BEGIN:VALARM\r\n";
        $ics .= "ACTION:DISPLAY\r\n";
        $ics .= "DESCRIPTION:Reminder: Appointment in 1 hour\r\n";
        $ics .= "TRIGGER:-PT1H\r\n";
        $ics .= "END:VALARM\r\n";

        $ics .= "END:VEVENT\r\n";
        $ics .= "END:VCALENDAR\r\n";

        // Set headers for file download
        header('Content-Type: text/calendar; charset=utf-8');
        header('Content-Disposition: attachment; filename="appointment.ics"');
        header('Content-Length: ' . strlen($ics));
        header('Cache-Control: no-cache');

        echo $ics;
        exit;
    }

    /**
     * Escape text for ICS format
     */
    private function ics_escape_text($text) {
        $text = str_replace('\\', '\\\\', $text);
        $text = str_replace(',', '\,', $text);
        $text = str_replace(';', '\;', $text);
        $text = str_replace("\n", '\\n', $text);
        return $text;
    }

    /**
     * Short URL system: Generate a short URL for a long URL
     */
    private function shorten_url($long_url) {
        $domain = get_option('wpbc_short_domain', '');
        $prefix = get_option('wpbc_short_prefix', 'r');

        if (empty($domain)) {
            return $long_url; // No domain configured - return original URL
        }

        // Support {site_url} placeholder — replaced with the WordPress home URL
        if ($domain === '{site_url}' || $domain === '{site_url}/') {
            $domain = untrailingslashit(home_url());
        }

        // Generate a unique 8-character token
        $token = substr(md5(uniqid($long_url, true)), 0, 8);

        // Store the mapping: token => long URL (keyed the same way handle_short_redirect reads it)
        $option_key = 'wpbc_redirect_' . $token;
        update_option($option_key, $long_url, false); // false = do not autoload

        // Build the short URL as  domain/prefix/token
        $prefix = trim($prefix, '/');
        $domain = rtrim($domain, '/');

        // Ensure domain has a scheme
        if (strpos($domain, 'http') !== 0) {
            $domain = 'https://' . $domain;
        }

        return $domain . '/' . $prefix . '/' . $token;
    }

    /**
     * Register wpbc_r as a recognised WordPress query variable.
     * This handles both ?wpbc_r=TOKEN (legacy) and path-based /prefix/TOKEN rewrite rules.
     */
    public function register_short_redirect_query_var($vars) {
        $vars[] = 'wpbc_r';
        return $vars;
    }

    /**
     * Add rewrite rules so path-based short URLs like /appt/TOKEN are handled by WordPress.
     * Called on 'init'. Re-registers whenever the prefix setting changes.
     */
    public function add_short_redirect_rewrite_rules() {
        $prefix = get_option('wpbc_short_prefix', 'r');
        $prefix = trim($prefix, '/');

        if (!empty($prefix)) {
            // Match  /PREFIX/TOKEN  where TOKEN is 8 hex chars
            add_rewrite_rule(
                '^' . preg_quote($prefix, '/') . '/([a-f0-9]{8})/?$',
                'index.php?wpbc_r=$matches[1]',
                'top'
            );
        }
    }

    /**
     * Flush rewrite rules once after activation or prefix change
     */
    public function maybe_flush_rewrite_rules() {
        if (get_option('wpbc_flush_rewrite_rules') === '1') {
            flush_rewrite_rules();
            delete_option('wpbc_flush_rewrite_rules');
        }
    }

    /**
     * Schedule a rewrite flush on next init (triggered by settings update)
     */
    public function schedule_rewrite_flush() {
        update_option('wpbc_flush_rewrite_rules', '1');
    }

    /**
     * Handle short URL redirect
     */
    public function handle_short_redirect() {
        $token = get_query_var('wpbc_r', '');

        if (empty($token)) {
            return;
        }

        $token      = sanitize_text_field($token);
        $option_key = 'wpbc_redirect_' . $token;
        $long_url   = get_option($option_key, '');

        if (empty($long_url)) {
            wp_die('Link not found or expired.', 'Invalid Link', array('response' => 404));
        }

        // 302 (temporary) so phones don't cache the redirect and always hit the fresh ICS
        wp_redirect($long_url, 302);
        exit;
    }

    /**
     * Get or generate a cached short URL for a booking's calendar ICS link.
     */
    private function get_booking_cal_url($booking, $force_refresh = false) {
        global $wpdb;

        if (!$force_refresh && !empty($booking->cal_short_url)) {
            return $booking->cal_short_url;
        }

        $site_name = get_bloginfo('name');

        $long_url = admin_url('admin-ajax.php') . '?action=wpbc_download_ics'
            . '&date=' . urlencode($booking->booking_date)
            . '&time=' . urlencode($booking->booking_time)
            . '&title=' . urlencode('Appointment at ' . $site_name);

        $short_url = $this->shorten_url($long_url);

        // Persist to DB so all future SMS for this booking reuse the same link
        $wpdb->update(
            $this->table_name,
            array('cal_short_url' => $short_url),
            array('id' => $booking->id),
            array('%s'),
            array('%d')
        );

        return $short_url;
    }

    /**
     * Email Testing AJAX Handlers (stubs for now - full implementation in Session 2)
     */
    public function ajax_set_simulated_time() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        $time = sanitize_text_field($_POST['time']);
        update_option('wpbc_simulated_time', $time);
        wp_send_json_success();
    }

    public function ajax_clear_simulated_time() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        delete_option('wpbc_simulated_time');
        wp_send_json_success();
    }

    public function ajax_trigger_reminder_check() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        $details = $this->send_reminder_emails(true);
        wp_send_json_success(array('details' => $details));
    }

    public function ajax_send_test_reminder() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        global $wpdb;
        $booking_id = intval($_POST['booking_id']);
        $type = sanitize_text_field($_POST['type']);

        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $booking_id
        ));

        if (!$booking) {
            wp_send_json_error('Booking not found');
        }

        $cancel_url = add_query_arg(array(
            'wpbc_cancel' => $booking->cancel_token,
            'booking_id' => $booking->id
        ), home_url('/'));

        $sent = $this->send_booking_email('reminder', array(
            'email' => $booking->customer_email,
            'name' => $booking->customer_name,
            'date' => $booking->booking_date,
            'time' => $booking->booking_time,
            'booking_id' => $booking->id,
            'cancel_url' => $cancel_url,
            'reminder_type' => $type === '24h' ? '24 hours' : '1 hour'
        ));

        wp_send_json_success(array('sent' => $sent));
    }

    public function ajax_reset_reminder_flags() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        global $wpdb;
        $booking_id = intval($_POST['booking_id']);

        $wpdb->update(
            $this->table_name,
            array('reminder_24h_sent' => 0, 'reminder_1h_sent' => 0),
            array('id' => $booking_id),
            array('%d', '%d'),
            array('%d')
        );

        wp_send_json_success();
    }

    public function ajax_schedule_reminder_cron() {
        if (!current_user_can('manage_options')) { wp_send_json_error('Unauthorized'); }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) { wp_send_json_error('Invalid nonce'); }

        wp_clear_scheduled_hook('wpbc_send_reminders');
        wp_schedule_event(time(), 'hourly', 'wpbc_send_reminders');
        wp_send_json_success();
    }

    /**
     * Restrict destructive admin actions to Administrator role specifically.
     */
    private function is_administrator_role() {
        if (!is_user_logged_in()) {
            return false;
        }
        $user = wp_get_current_user();
        return in_array('administrator', (array) $user->roles, true);
    }

    /**
     * AJAX: Delete a booking row permanently (administrator role only).
     */
    public function ajax_delete_booking() {
        if (!current_user_can('manage_options') || !$this->is_administrator_role()) {
            wp_send_json_error('Unauthorized');
        }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) {
            wp_send_json_error('Invalid nonce');
        }

        global $wpdb;
        $booking_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;
        if ($booking_id <= 0) {
            wp_send_json_error('Invalid booking ID');
        }

        $deleted = $wpdb->delete(
            $this->table_name,
            array('id' => $booking_id),
            array('%d')
        );

        if ($deleted === false) {
            wp_send_json_error('Failed to delete booking');
        }

        wp_send_json_success(array('deleted' => (int) $deleted));
    }

    /**
     * AJAX: Clear all bookings permanently (administrator role only).
     */
    public function ajax_clear_bookings() {
        if (!current_user_can('manage_options') || !$this->is_administrator_role()) {
            wp_send_json_error('Unauthorized');
        }
        if (!wp_verify_nonce($_POST['nonce'], 'wpbc_admin_nonce')) {
            wp_send_json_error('Invalid nonce');
        }

        global $wpdb;
        $deleted = $wpdb->query("DELETE FROM {$this->table_name}");

        if ($deleted === false) {
            wp_send_json_error('Failed to clear bookings');
        }

        wp_send_json_success(array('deleted' => (int) $deleted));
    }

    /**
     * Add admin menu pages
     */
    public function add_admin_menu() {
        // Main bookings page
        add_menu_page(
            'Bookings',
            'Booking Calendar',
            'manage_options',
            'wpbc-bookings',
            array($this, 'admin_bookings_page'),
            'dashicons-calendar-alt',
            30
        );

        // Settings submenu
        add_submenu_page(
            'wpbc-bookings',
            'Settings',
            'Settings',
            'manage_options',
            'wpbc-settings',
            array($this, 'settings_page')
        );

        // Availability submenu (calendar-based blocking)
        add_submenu_page(
            'wpbc-bookings',
            'Availability',
            'Availability',
            'manage_options',
            'wpbc-availability',
            array($this, 'availability_page')
        );

        // Email Testing submenu (for debugging)
        add_submenu_page(
            'wpbc-bookings',
            'Email Testing',
            'Email Testing',
            'manage_options',
            'wpbc-email-testing',
            array($this, 'email_testing_page')
        );
    }

    /**
     * Register plugin settings
     */
    public function register_settings() {
        register_setting('wp_booking_calendar', 'wpbc_websocket_url');
        register_setting('wp_booking_calendar', 'wpbc_websocket_token');
        register_setting('wp_booking_calendar', 'wpbc_site_id');
        register_setting('wp_booking_calendar', 'wpbc_calendar_id');

        // Calendar logo settings (admin only)
        if (current_user_can('manage_options')) {
            register_setting('wp_booking_calendar', 'wpbc_logo_google', array('sanitize_callback' => 'esc_url_raw'));
            register_setting('wp_booking_calendar', 'wpbc_logo_outlook', array('sanitize_callback' => 'esc_url_raw'));
            register_setting('wp_booking_calendar', 'wpbc_logo_yahoo', array('sanitize_callback' => 'esc_url_raw'));
            register_setting('wp_booking_calendar', 'wpbc_logo_apple', array('sanitize_callback' => 'esc_url_raw'));
        }

        // Custom URL shortener settings
        register_setting('wp_booking_calendar', 'wpbc_short_domain');
        register_setting('wp_booking_calendar', 'wpbc_short_prefix');

        // Availability schedule
        register_setting('wp_booking_calendar', 'wpbc_available_days');
        register_setting('wp_booking_calendar', 'wpbc_time_ranges');

        // Email settings
        register_setting('wp_booking_calendar', 'wpbc_email_from_name');
        register_setting('wp_booking_calendar', 'wpbc_email_from_email');
        register_setting('wp_booking_calendar', 'sec_email_logo_max_width');
        register_setting('wp_booking_calendar', 'sec_email_logo_max_height');

        // Branding settings
        register_setting('wp_booking_calendar', 'wpbc_accent_color', array('sanitize_callback' => 'sanitize_hex_color'));

        // Email branding settings (admin only)
        if (current_user_can('manage_options')) {
            register_setting('wp_booking_calendar', 'sec_email_logo_url', array('sanitize_callback' => 'esc_url_raw'));
            register_setting('wp_booking_calendar', 'sec_email_header_gradient_start', array('sanitize_callback' => 'sanitize_hex_color'));
            register_setting('wp_booking_calendar', 'sec_email_header_gradient_end', array('sanitize_callback' => 'sanitize_hex_color'));
        }
    }

    /**
     * Admin bookings page
     */
    public function admin_bookings_page() {
        global $wpdb;

        // Keep at most one year of bookings in storage.
        $retention_cutoff = wp_date('Y-m-d', strtotime('-1 year', current_time('timestamp')));
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$this->table_name} WHERE booking_date < %s",
            $retention_cutoff
        ));

        $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'all';
        $month_filter = isset($_GET['month']) ? sanitize_text_field($_GET['month']) : '';
        $search_filter = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        $export_csv = isset($_GET['export']) && sanitize_text_field($_GET['export']) === 'csv';
        $is_admin_role = $this->is_administrator_role();

        $allowed_statuses = array('all', 'confirmed', 'cancelled');
        if (!in_array($status_filter, $allowed_statuses, true)) {
            $status_filter = 'all';
        }

        $where_parts = array('booking_date >= %s');
        $where_params = array($retention_cutoff);

        if ($status_filter !== 'all') {
            $where_parts[] = 'status = %s';
            $where_params[] = $status_filter;
        }

        if (preg_match('/^\d{4}-\d{2}$/', $month_filter)) {
            $month_start = $month_filter . '-01';
            $month_end = wp_date('Y-m-d', strtotime($month_start . ' +1 month'));
            $where_parts[] = 'booking_date >= %s';
            $where_parts[] = 'booking_date < %s';
            $where_params[] = $month_start;
            $where_params[] = $month_end;
        } else {
            $month_filter = '';
        }

        if ($search_filter !== '') {
            $where_parts[] = 'customer_name LIKE %s';
            $where_params[] = '%' . $wpdb->esc_like($search_filter) . '%';
        }

        $where_sql = implode(' AND ', $where_parts);
        $query = "SELECT * FROM {$this->table_name} WHERE {$where_sql} ORDER BY booking_date DESC, booking_time ASC";
        $bookings = $wpdb->get_results($wpdb->prepare($query, $where_params));

        $counts = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT status, COUNT(*) as count FROM {$this->table_name} WHERE booking_date >= %s GROUP BY status",
                $retention_cutoff
            ),
            OBJECT_K
        );
        $total_count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE booking_date >= %s",
            $retention_cutoff
        ));
        $available_months = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT DATE_FORMAT(booking_date, '%%Y-%%m') AS booking_month
             FROM {$this->table_name}
             WHERE booking_date >= %s
             ORDER BY booking_month DESC",
            $retention_cutoff
        ));

        if ($export_csv) {
            $filename = 'wpbc-bookings-' . current_time('Ymd-His') . '.csv';
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Pragma: no-cache');
            header('Expires: 0');

            $output = fopen('php://output', 'w');
            fputcsv($output, array(
                'ID',
                'Booking Date',
                'Booking Time',
                'Customer Name',
                'Customer Email',
                'Customer Phone',
                'Customer Address',
                'Status',
                'Created At'
            ));
            foreach ($bookings as $booking) {
                fputcsv($output, array(
                    $booking->id,
                    $booking->booking_date,
                    $booking->booking_time,
                    $booking->customer_name,
                    $booking->customer_email,
                    $booking->customer_phone,
                    $booking->customer_address,
                    $booking->status,
                    $booking->created_at
                ));
            }
            fclose($output);
            exit;
        }

        $base_filters = array(
            'page' => 'wpbc-bookings',
            'month' => $month_filter,
            's' => $search_filter
        );
        ?>
        <?php
        $today_str  = current_time('Y-m-d');
        $is_blocked = (get_transient('wpbc_block_today') === $today_str);
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">Bookings</h1>
            <a href="<?php echo esc_url(add_query_arg(array_merge($base_filters, array('status' => $status_filter, 'export' => 'csv')), admin_url('admin.php'))); ?>" class="page-title-action">Export CSV</a>
            <?php if ($is_admin_role): ?>
                <button type="button" id="wpbc-clear-bookings-btn" class="page-title-action" style="color:#b91c1c;border-color:#fecaca;">
                    Clear Bookings
                </button>
            <?php endif; ?>
            <span id="wpbc-block-status" style="margin-left:10px;font-size:13px;vertical-align:middle;color:#6b7280;"></span>

            <ul class="subsubsub">
                <li>
                    <a href="<?php echo esc_url(add_query_arg(array_merge($base_filters, array('status' => 'all')), admin_url('admin.php'))); ?>" <?php echo $status_filter === 'all' ? 'class="current"' : ''; ?>>
                        All <span class="count">(<?php echo esc_html($total_count); ?>)</span>
                    </a> |
                </li>
                <li>
                    <a href="<?php echo esc_url(add_query_arg(array_merge($base_filters, array('status' => 'confirmed')), admin_url('admin.php'))); ?>" <?php echo $status_filter === 'confirmed' ? 'class="current"' : ''; ?>>
                        Confirmed <span class="count">(<?php echo isset($counts['confirmed']) ? $counts['confirmed']->count : 0; ?>)</span>
                    </a> |
                </li>
                <li>
                    <a href="<?php echo esc_url(add_query_arg(array_merge($base_filters, array('status' => 'cancelled')), admin_url('admin.php'))); ?>" <?php echo $status_filter === 'cancelled' ? 'class="current"' : ''; ?>>
                        Cancelled <span class="count">(<?php echo isset($counts['cancelled']) ? $counts['cancelled']->count : 0; ?>)</span>
                    </a>
                </li>
            </ul>

            <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>" style="display:flex;gap:10px;align-items:center;margin:10px 0 14px;">
                <input type="hidden" name="page" value="wpbc-bookings">
                <input type="hidden" name="status" value="<?php echo esc_attr($status_filter); ?>">
                <label for="wpbc-month-filter" class="screen-reader-text">Filter by month</label>
                <select id="wpbc-month-filter" name="month">
                    <option value="">All months (last 12 months)</option>
                    <?php foreach ($available_months as $month_key): ?>
                        <option value="<?php echo esc_attr($month_key); ?>" <?php selected($month_filter, $month_key); ?>>
                            <?php echo esc_html(date_i18n('F Y', strtotime($month_key . '-01'))); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <label for="wpbc-name-search" class="screen-reader-text">Search by name</label>
                <input type="search" id="wpbc-name-search" name="s" value="<?php echo esc_attr($search_filter); ?>" placeholder="Search customer name">
                <button type="submit" class="button">Filter</button>
                <a href="<?php echo esc_url(add_query_arg(array('page' => 'wpbc-bookings', 'status' => 'all'), admin_url('admin.php'))); ?>" class="button">Reset</a>
            </form>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Date & Time</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($bookings)): ?>
                        <tr>
                            <td colspan="9">No bookings found.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($bookings as $booking): ?>
                            <tr data-id="<?php echo esc_attr($booking->id); ?>">
                                <td><?php echo esc_html($booking->id); ?></td>
                                <td>
                                    <strong><?php echo esc_html(date('M j, Y', strtotime($booking->booking_date))); ?></strong><br>
                                    <?php echo esc_html($booking->booking_time); ?>
                                </td>
                                <td><?php echo esc_html($booking->customer_name); ?></td>
                                <td><a href="mailto:<?php echo esc_attr($booking->customer_email); ?>"><?php echo esc_html($booking->customer_email); ?></a></td>
                                <td><?php echo esc_html($booking->customer_phone); ?></td>
                                <td><?php echo esc_html($booking->customer_address); ?></td>
                                <td>
                                    <span class="wpbc-status wpbc-status-<?php echo esc_attr($booking->status); ?>">
                                        <?php echo esc_html(ucfirst($booking->status)); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html(date('M j, Y g:i A', strtotime($booking->created_at))); ?></td>
                                <td>
                                    <?php if ($booking->status === 'confirmed'): ?>
                                        <button type="button" class="button wpbc-reschedule-btn" data-id="<?php echo esc_attr($booking->id); ?>" data-date="<?php echo esc_attr($booking->booking_date); ?>" data-time="<?php echo esc_attr($booking->booking_time); ?>">
                                            Reschedule
                                        </button>
                                        <button type="button" class="button wpbc-cancel-btn" data-id="<?php echo esc_attr($booking->id); ?>">
                                            Cancel
                                        </button>
                                    <?php endif; ?>
                                    <?php if ($is_admin_role): ?>
                                        <button type="button" class="button wpbc-delete-btn" data-id="<?php echo esc_attr($booking->id); ?>" style="color:#b91c1c;border-color:#fecaca;">
                                            Delete
                                        </button>
                                    <?php endif; ?>
                                    <?php if ($booking->status !== 'confirmed' && !$is_admin_role): ?>
                                        <em>-</em>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Reschedule Modal -->
        <div id="wpbc-reschedule-modal">
            <div class="wpbc-modal-overlay"></div>
            <div class="wpbc-modal-content">
                <h2>Reschedule Booking</h2>
                <form id="wpbc-reschedule-form">
                    <input type="hidden" name="booking_id" id="reschedule-booking-id">
                    <input type="hidden" name="old_date" id="reschedule-old-date">
                    <input type="hidden" name="old_time" id="reschedule-old-time">
                    <p>
                        <label><strong>Current:</strong></label><br>
                        <span id="reschedule-current-display" style="color: #6b7280;"></span>
                    </p>
                    <p>
                        <label><strong>New Date:</strong></label><br>
                        <input type="date" name="new_date" id="reschedule-date" required min="<?php echo date('Y-m-d'); ?>">
                    </p>
                    <p>
                        <label><strong>New Time:</strong></label><br>
                        <select name="new_time" id="reschedule-time" required>
                            <option value="">-- Select a date first --</option>
                        </select>
                        <span id="reschedule-loading" style="display:none; color: #6b7280;">Loading...</span>
                    </p>
                    <p style="margin-top: 20px;">
                        <button type="submit" class="button button-primary" id="reschedule-submit">Update Booking</button>
                        <button type="button" class="button wpbc-modal-close">Cancel</button>
                    </p>
                </form>
            </div>
        </div>

        <style>
            :root {
                --wpbc-accent-color: <?php echo esc_attr(get_option('wpbc_accent_color', '#2536eb')); ?>;
            }

            .wpbc-status {
                display: inline-block;
                padding: 3px 8px;
                border-radius: 3px;
                font-size: 12px;
                font-weight: 600;
            }
            .wpbc-status-confirmed {
                background: #d4edda;
                color: #155724;
            }
            .wpbc-status-cancelled {
                background: #f8d7da;
                color: #721c24;
            }
            .wpbc-modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.5);
                z-index: 99999;
            }
            .wpbc-modal-content {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background: white;
                padding: 25px;
                border-radius: 8px;
                z-index: 100000;
                min-width: 350px;
                box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            }
            .wpbc-modal-content h2 {
                margin-top: 0;
                color: #374151;
            }
            .wpbc-modal-content label {
                color: #374151;
            }
            .wpbc-modal-content input[type="date"],
            .wpbc-modal-content select {
                width: 100%;
                padding: 8px 12px;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                font-size: 14px;
            }
            #wpbc-reschedule-modal {
                display: none;
            }
            #wpbc-reschedule-modal.active {
                display: block;
            }
            .wpbc-ws-status {
                position: fixed;
                bottom: 20px;
                right: 20px;
                padding: 8px 16px;
                border-radius: 20px;
                font-size: 12px;
                font-weight: 600;
                z-index: 9999;
            }
            .wpbc-ws-connected {
                background: #d4edda;
                color: #155724;
            }
            .wpbc-ws-disconnected {
                background: #f8d7da;
                color: #721c24;
            }
        </style>

        <!-- WebSocket Status Indicator -->
        <div id="wpbc-ws-status" class="wpbc-ws-status wpbc-ws-disconnected">WebSocket: Disconnected</div>

        <!-- Socket.io for real-time updates -->
        <script src="https://cdn.socket.io/4.6.1/socket.io.min.js"></script>

        <script>
        jQuery(document).ready(function($) {
            var adminNonce = '<?php echo wp_create_nonce('wpbc_admin_nonce'); ?>';
            var socket = null;

            // WebSocket configuration
            var wsUrl = '<?php echo esc_js(get_option('wpbc_websocket_url', 'http://162.0.220.48:3000')); ?>';
            wsUrl = wsUrl.replace(/^ws:\/\//, 'http://').replace(/^wss:\/\//, 'https://');
            var wsToken = '<?php echo esc_js(get_option('wpbc_websocket_token', '')); ?>';
            var siteId = '<?php echo esc_js(get_option('wpbc_site_id', sanitize_title(get_bloginfo('name')))); ?>';
            var calendarId = '<?php echo esc_js(get_option('wpbc_calendar_id', 'main-calendar')); ?>';

            // Initialize WebSocket
            function initWebSocket() {
                if (typeof io === 'undefined') {
                    console.log('Socket.io not available');
                    return;
                }

                try {
                    socket = io(wsUrl, {
                        transports: ['websocket', 'polling'],
                        reconnection: true,
                        auth: { token: wsToken }
                    });

                    socket.on('connect', function() {
                        console.log('Admin WebSocket connected');
                        $('#wpbc-ws-status').removeClass('wpbc-ws-disconnected').addClass('wpbc-ws-connected').text('WebSocket: Connected');
                        socket.emit('join-calendar', { siteId: siteId, calendarId: calendarId, userId: 'admin' });
                    });

                    socket.on('disconnect', function() {
                        $('#wpbc-ws-status').removeClass('wpbc-ws-connected').addClass('wpbc-ws-disconnected').text('WebSocket: Disconnected');
                    });
                } catch (e) {
                    console.log('WebSocket error:', e);
                }
            }

            initWebSocket();

            // ── Block / Unblock rest of today ─────────────────────────────────
            $('#wpbc-block-today-btn').on('click', function() {
                var $btn     = $(this);
                var isBlocked = ($btn.data('blocked') === '1' || $btn.data('blocked') === 1);
                var today    = $btn.data('today');
                var action   = isBlocked ? 'wpbc_unblock_today' : 'wpbc_block_today';

                $btn.prop('disabled', true);
                $('#wpbc-block-status').text('Updating...');

                $.post(ajaxurl, { action: action, nonce: adminNonce }, function(response) {
                    $btn.prop('disabled', false);
                    if (response.success) {
                        var nowBlocked = !isBlocked;
                        $btn.data('blocked', nowBlocked ? '1' : '0');
                        $btn.text(nowBlocked ? '🔓 Unblock Today' : '🔒 Block Rest of Today');
                        $btn.toggleClass('button-primary', nowBlocked);
                        $('#wpbc-block-status').text(
                            nowBlocked ? "Today's remaining slots are now hidden from visitors."
                                       : "Today's slots are visible again."
                        );
                        setTimeout(function() { $('#wpbc-block-status').text(''); }, 4000);

                        // Broadcast via WebSocket so public calendar updates instantly
                        if (socket && socket.connected) {
                            socket.emit(nowBlocked ? 'block-today' : 'unblock-today', {
                                siteId: siteId,
                                calendarId: calendarId,
                                date: today
                            });
                        }
                    } else {
                        $('#wpbc-block-status').text('Error: ' + (response.data || 'unknown'));
                    }
                });
            });

            $('#wpbc-clear-bookings-btn').on('click', function() {
                var $btn = $(this);
                if (!confirm('Delete ALL bookings? This cannot be undone.')) return;

                $btn.prop('disabled', true).text('Clearing...');
                $.post(ajaxurl, {
                    action: 'wpbc_clear_bookings',
                    nonce: adminNonce
                }, function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert('Error: ' + response.data);
                        $btn.prop('disabled', false).text('Clear Bookings');
                    }
                });
            });

            $('.wpbc-delete-btn').on('click', function() {
                var $btn = $(this);
                var bookingId = $btn.data('id');
                var $row = $btn.closest('tr');

                if (!confirm('Delete this booking permanently?')) return;

                $btn.prop('disabled', true).text('Deleting...');
                $.post(ajaxurl, {
                    action: 'wpbc_delete_booking',
                    nonce: adminNonce,
                    booking_id: bookingId
                }, function(response) {
                    if (response.success) {
                        $row.fadeOut(180, function() { $(this).remove(); });
                    } else {
                        alert('Error: ' + response.data);
                        $btn.prop('disabled', false).text('Delete');
                    }
                });
            });

            $('.wpbc-cancel-btn').on('click', function() {
                if (!confirm('Are you sure you want to cancel this booking? The customer will be notified by email.')) return;

                var $btn = $(this);
                var bookingId = $btn.data('id');
                var row = $btn.closest('tr');

                $btn.prop('disabled', true).text('Cancelling...');

                $.post(ajaxurl, {
                    action: 'wpbc_cancel_booking',
                    nonce: adminNonce,
                    booking_id: bookingId
                }, function(response) {
                    if (response.success) {
                        // Broadcast via WebSocket — emit both events for compatibility
                        // booking-cancelled is caught by the updated frontend JS
                        // slot-available is caught by older/other listeners
                        if (socket && socket.connected) {
                            socket.emit('booking-cancelled', {
                                siteId: siteId,
                                calendarId: calendarId,
                                date: response.data.date,
                                time: response.data.time,
                                bookingId: bookingId
                            });
                            socket.emit('slot-available', {
                                siteId: siteId,
                                calendarId: calendarId,
                                date: response.data.date,
                                time: response.data.time
                            });
                        }
                        // Delay reload to allow WebSocket events to be sent
                        setTimeout(function() {
                            location.reload();
                        }, 500);
                    } else {
                        alert('Error: ' + response.data);
                        $btn.prop('disabled', false).text('Cancel');
                    }
                });
            });

            // Load available slots when date changes
            $('#reschedule-date').on('change', function() {
                var date = $(this).val();
                var $select = $('#reschedule-time');
                var $loading = $('#reschedule-loading');
                var currentBookingId = $('#reschedule-booking-id').val();

                if (!date) {
                    $select.html('<option value="">-- Select a date first --</option>');
                    return;
                }

                // Check if weekday
                var dayOfWeek = new Date(date + 'T00:00:00').getDay();
                if (dayOfWeek === 0 || dayOfWeek === 6) {
                    $select.html('<option value="">Weekends not available</option>');
                    return;
                }

                $select.hide();
                $loading.show();

                $.post(ajaxurl, {
                    action: 'wpbc_get_available_slots',
                    date: date
                }, function(response) {
                    $loading.hide();
                    $select.show();

                    if (response.success && response.data.length > 0) {
                        var html = '';
                        response.data.forEach(function(slot) {
                            html += '<option value="' + slot + '">' + slot + '</option>';
                        });
                        $select.html(html);
                    } else {
                        $select.html('<option value="">No slots available</option>');
                    }
                });
            });

            // Reschedule modal
            $('.wpbc-reschedule-btn').on('click', function() {
                var bookingId = $(this).data('id');
                var date = $(this).data('date');
                var time = $(this).data('time');

                var formattedDate = new Date(date + 'T00:00:00').toLocaleDateString('en-US', {
                    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
                });

                $('#reschedule-booking-id').val(bookingId);
                $('#reschedule-old-date').val(date);
                $('#reschedule-old-time').val(time);
                $('#reschedule-current-display').text(formattedDate + ' at ' + time);
                $('#reschedule-date').val('');
                $('#reschedule-time').html('<option value="">-- Select a date first --</option>');
                $('#wpbc-reschedule-modal').addClass('active');
            });

            $('.wpbc-modal-close, .wpbc-modal-overlay').on('click', function() {
                $('#wpbc-reschedule-modal').removeClass('active');
            });

            $('#wpbc-reschedule-form').on('submit', function(e) {
                e.preventDefault();

                var newDate = $('#reschedule-date').val();
                var newTime = $('#reschedule-time').val();

                if (!newDate || !newTime) {
                    alert('Please select a date and time');
                    return;
                }

                var $btn = $('#reschedule-submit');
                $btn.prop('disabled', true).text('Updating...');

                $.post(ajaxurl, {
                    action: 'wpbc_update_booking',
                    nonce: adminNonce,
                    booking_id: $('#reschedule-booking-id').val(),
                    new_date: newDate,
                    new_time: newTime
                }, function(response) {
                    if (response.success) {
                        // Broadcast via WebSocket so public calendar updates live
                        if (socket && socket.connected) {
                            // Old slot is now free — emit both for compatibility
                            socket.emit('booking-cancelled', {
                                siteId: siteId,
                                calendarId: calendarId,
                                date: response.data.old_date,
                                time: response.data.old_time,
                                bookingId: response.data.booking_id
                            });
                            socket.emit('slot-available', {
                                siteId: siteId,
                                calendarId: calendarId,
                                date: response.data.old_date,
                                time: response.data.old_time
                            });
                            // New slot becomes unavailable
                            socket.emit('slot-booked', {
                                siteId: siteId,
                                calendarId: calendarId,
                                date: response.data.new_date,
                                time: response.data.new_time,
                                bookingId: response.data.booking_id,
                                userId: 'admin'
                            });
                        }
                        // Delay reload to allow WebSocket events to be sent
                        setTimeout(function() {
                            location.reload();
                        }, 500);
                    } else {
                        alert('Error: ' + response.data);
                        $btn.prop('disabled', false).text('Update Booking');
                    }
                });
            });
        });
        </script>
        <?php
    }

    /**
     * Settings page
     */
    public function settings_page() {
        // Enqueue media uploader and color picker
        wp_enqueue_media();
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        ?>
        <div class="wrap">
            <h1>Booking Calendar Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields('wp_booking_calendar'); ?>

                <h2>General Settings</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">WebSocket Server URL</th>
                        <td>
                            <input type="text" name="wpbc_websocket_url"
                                   value="<?php echo esc_attr(get_option('wpbc_websocket_url', 'http://162.0.220.48:3000')); ?>"
                                   class="regular-text" placeholder="http://your-server:3000">
                            <p class="description">Your WebSocket server URL (e.g., http://162.0.220.48:3000)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">WebSocket Secret Token</th>
                        <td>
                            <input type="text" name="wpbc_websocket_token"
                                   value="<?php echo esc_attr(get_option('wpbc_websocket_token', '')); ?>"
                                   class="regular-text" placeholder="your-secret-key">
                            <p class="description">Handshake token sent as <code>auth.token</code>. Must match server <code>SECRET_TOKEN</code>.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Site ID</th>
                        <td>
                            <input type="text" name="wpbc_site_id"
                                   value="<?php echo esc_attr(get_option('wpbc_site_id', sanitize_title(get_bloginfo('name')))); ?>"
                                   class="regular-text">
                            <p class="description">Unique identifier for this site</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Calendar ID</th>
                        <td>
                            <input type="text" name="wpbc_calendar_id"
                                   value="<?php echo esc_attr(get_option('wpbc_calendar_id', 'main-calendar')); ?>"
                                   class="regular-text">
                            <p class="description">Identifier for this calendar instance</p>
                        </td>
                    </tr>
                </table>

                <hr>
                <h2>Email Settings</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">From Name</th>
                        <td>
                            <input type="text" name="wpbc_email_from_name"
                                   value="<?php echo esc_attr(get_option('wpbc_email_from_name', get_bloginfo('name'))); ?>"
                                   class="regular-text" placeholder="<?php echo esc_attr(get_bloginfo('name')); ?>">
                            <p class="description">Name shown in "From" field of booking emails</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">From Email</th>
                        <td>
                            <input type="email" name="wpbc_email_from_email"
                                   value="<?php echo esc_attr(get_option('wpbc_email_from_email', get_option('admin_email'))); ?>"
                                   class="regular-text" placeholder="<?php echo esc_attr(get_option('admin_email')); ?>">
                            <p class="description">Email address shown in "From" field of booking emails</p>
                        </td>
                    </tr>
                    <?php if (current_user_can('manage_options')): ?>
                    <tr>
                        <th scope="row">Email Header Logo <span style="color: #dc3232;">(Admin Only)</span></th>
                        <td>
                            <?php $email_logo = get_option('sec_email_logo_url', ''); ?>
                            <input type="text" name="sec_email_logo_url" id="sec_email_logo_url"
                                   value="<?php echo esc_attr($email_logo); ?>"
                                   class="regular-text" placeholder="https://example.com/logo.png">
                            <button type="button" class="button wpbc-upload-btn" data-target="sec_email_logo_url">Upload</button>
                            <?php if ($email_logo): ?>
                                <br><img src="<?php echo esc_url($email_logo); ?>" style="max-height: 60px; margin-top: 10px; background: linear-gradient(135deg, #B8C7E6, #94B5F0); padding: 10px; border-radius: 4px;">
                            <?php endif; ?>
                            <p class="description">Logo displayed in email header. Leave empty to use "MARKETINGAID" text wordmark. Maximum recommended height: 68px.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Email Logo Max Width <span style="color: #dc3232;">(Admin Only)</span></th>
                        <td>
                            <input type="number" name="sec_email_logo_max_width"
                                   value="<?php echo esc_attr(get_option('sec_email_logo_max_width', '220')); ?>"
                                   class="small-text" min="50" max="600" step="1">
                            <span>px</span>
                            <p class="description">Maximum width for email header logo (default: 220px)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Email Logo Max Height <span style="color: #dc3232;">(Admin Only)</span></th>
                        <td>
                            <input type="number" name="sec_email_logo_max_height"
                                   value="<?php echo esc_attr(get_option('sec_email_logo_max_height', '68')); ?>"
                                   class="small-text" min="20" max="200" step="1">
                            <span>px</span>
                            <p class="description">Maximum height for email header logo (default: 68px)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Header Gradient Start Color <span style="color: #dc3232;">(Admin Only)</span></th>
                        <td>
                            <input type="text" name="sec_email_header_gradient_start" id="sec_email_header_gradient_start"
                                   value="<?php echo esc_attr(get_option('sec_email_header_gradient_start', '#B8C7E6')); ?>"
                                   class="regular-text wpbc-color-picker" placeholder="#B8C7E6">
                            <p class="description">Start color for email header gradient (default: #B8C7E6)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Header Gradient End Color <span style="color: #dc3232;">(Admin Only)</span></th>
                        <td>
                            <input type="text" name="sec_email_header_gradient_end" id="sec_email_header_gradient_end"
                                   value="<?php echo esc_attr(get_option('sec_email_header_gradient_end', '#94B5F0')); ?>"
                                   class="regular-text wpbc-color-picker" placeholder="#94B5F0">
                            <p class="description">End color for email header gradient (default: #94B5F0)</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </table>

                <hr>
                <h2>Button & Accent Color</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">Accent Color</th>
                        <td>
                            <input type="text" name="wpbc_accent_color" id="wpbc_accent_color"
                                   value="<?php echo esc_attr(get_option('wpbc_accent_color', '#2536eb')); ?>"
                                   class="regular-text wpbc-color-picker" placeholder="#2536eb">
                            <p class="description">Primary color used for buttons, links, and accents throughout the booking system (default: #2536eb)</p>
                        </td>
                    </tr>
                </table>

                <?php if (current_user_can('manage_options')): ?>
                <hr>
                <h2>Calendar Button Logos <span style="color: #dc3232;">(Admin Only)</span></h2>
                <p class="description">Customize the "Add to Calendar" button logos in confirmation emails. Upload logo images for each provider.</p>
                <table class="form-table">
                    <tr>
                        <th scope="row">Google Calendar Logo</th>
                        <td>
                            <?php $google_logo = get_option('wpbc_logo_google', ''); ?>
                            <input type="text" name="wpbc_logo_google" id="wpbc_logo_google"
                                   value="<?php echo esc_attr($google_logo); ?>"
                                   class="regular-text" placeholder="https://example.com/google-logo.png">
                            <button type="button" class="button wpbc-upload-btn" data-target="wpbc_logo_google">Upload</button>
                            <?php if ($google_logo): ?>
                                <br><img src="<?php echo esc_url($google_logo); ?>" style="max-height: 30px; margin-top: 10px; background: #fff; border: 1px solid #dadce0; padding: 5px; border-radius: 4px;">
                            <?php endif; ?>
                            <p class="description">Upload Google Calendar logo. Recommended size: 24x24px. Will display on white background with border.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Outlook Logo</th>
                        <td>
                            <?php $outlook_logo = get_option('wpbc_logo_outlook', ''); ?>
                            <input type="text" name="wpbc_logo_outlook" id="wpbc_logo_outlook"
                                   value="<?php echo esc_attr($outlook_logo); ?>"
                                   class="regular-text" placeholder="https://example.com/outlook-logo.png">
                            <button type="button" class="button wpbc-upload-btn" data-target="wpbc_logo_outlook">Upload</button>
                            <?php if ($outlook_logo): ?>
                                <br><img src="<?php echo esc_url($outlook_logo); ?>" style="max-height: 30px; margin-top: 10px; background: #fff; border: 1px solid #dadce0; padding: 5px; border-radius: 4px;">
                            <?php endif; ?>
                            <p class="description">Upload Outlook logo. Recommended size: 24x24px. Will display on white background with border.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Yahoo Calendar Logo</th>
                        <td>
                            <?php $yahoo_logo = get_option('wpbc_logo_yahoo', ''); ?>
                            <input type="text" name="wpbc_logo_yahoo" id="wpbc_logo_yahoo"
                                   value="<?php echo esc_attr($yahoo_logo); ?>"
                                   class="regular-text" placeholder="https://example.com/yahoo-logo.png">
                            <button type="button" class="button wpbc-upload-btn" data-target="wpbc_logo_yahoo">Upload</button>
                            <?php if ($yahoo_logo): ?>
                                <br><img src="<?php echo esc_url($yahoo_logo); ?>" style="max-height: 30px; margin-top: 10px; background: #fff; border: 1px solid #dadce0; padding: 5px; border-radius: 4px;">
                            <?php endif; ?>
                            <p class="description">Upload Yahoo Calendar logo. Recommended size: 24x24px. Will display on white background with border.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Apple Calendar Logo</th>
                        <td>
                            <?php $apple_logo = get_option('wpbc_logo_apple', ''); ?>
                            <input type="text" name="wpbc_logo_apple" id="wpbc_logo_apple"
                                   value="<?php echo esc_attr($apple_logo); ?>"
                                   class="regular-text" placeholder="https://example.com/apple-logo.png">
                            <button type="button" class="button wpbc-upload-btn" data-target="wpbc_logo_apple">Upload</button>
                            <?php if ($apple_logo): ?>
                                <br><img src="<?php echo esc_url($apple_logo); ?>" style="max-height: 30px; margin-top: 10px; background: #fff; border: 1px solid #dadce0; padding: 5px; border-radius: 4px;">
                            <?php endif; ?>
                            <p class="description">Upload a <strong>black logo</strong> (it will display on a white background). Recommended size: 24x24px.</p>
                        </td>
                    </tr>
                </table>
                <?php endif; ?>

                <hr>
                <h2>SMS Link Shortener</h2>
                <p class="description">Calendar links sent via SMS will be shortened using your own domain (e.g. <code>yourdomain.com/r/abc12345</code>). No third-party service needed — links are stored in your WordPress database and redirect instantly. Leave the domain blank to send full-length links.</p>
                <table class="form-table">
                    <tr>
                        <th scope="row">Short Link Domain</th>
                        <td>
                            <input type="text" name="wpbc_short_domain"
                                   value="<?php echo esc_attr(get_option('wpbc_short_domain', '')); ?>"
                                   class="regular-text" placeholder="yourdomain.com">
                            <p class="description">
                                Enter your domain without a trailing slash. Can be your main site domain or a separate short domain (e.g. <code>mktg.ai</code>).<br>
                                Use <code>{site_url}</code> to automatically use this WordPress site's URL (<code><?php echo esc_html(untrailingslashit(home_url())); ?></code>).<br>
                                Leave empty to send full-length links in SMS.
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">URL Prefix</th>
                        <td>
                            <input type="text" name="wpbc_short_prefix"
                                   value="<?php echo esc_attr(get_option('wpbc_short_prefix', 'r')); ?>"
                                   class="regular-text" placeholder="r">
                            <p class="description">The path segment before the token. Default is <code>r</code>, producing links like <code>yourdomain.com/r/abc12345</code>. Can be any slug (e.g. <code>go</code>, <code>cal</code>, <code>appt</code>).</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Test Short Link</th>
                        <td>
                            <?php
                            $test_domain = get_option('wpbc_short_domain', '');
                            $test_prefix = get_option('wpbc_short_prefix', 'r');
                            $domain_configured = !empty($test_domain);
                            if ($domain_configured) {
                                $resolved = ($test_domain === '{site_url}' || $test_domain === '{site_url}/') ? untrailingslashit(home_url()) : rtrim($test_domain, '/');
                                if (strpos($resolved, 'http') !== 0) { $resolved = 'https://' . $resolved; }
                                $example = $resolved . '/' . trim($test_prefix, '/') . '/abc12345';
                            }
                            ?>
                            <?php if ($domain_configured): ?>
                                <p>Short links will look like: <code><?php echo esc_html($example); ?></code></p>
                                <p><strong>Rewrite rules status:</strong>
                                <?php
                                global $wp_rewrite;
                                $rules = get_option('rewrite_rules', array());
                                $prefix_escaped = preg_quote(trim($test_prefix, '/'), '/');
                                $rule_found = false;
                                foreach ((array)$rules as $pattern => $query) {
                                    if (strpos($pattern, $prefix_escaped) !== false && strpos($query, 'wpbc_r') !== false) {
                                        $rule_found = true;
                                        break;
                                    }
                                }
                                if ($rule_found): ?>
                                    <span style="color:green;">✓ Rewrite rule registered — short links should work.</span>
                                <?php else: ?>
                                    <span style="color:red;">✗ Rewrite rule not found.</span>
                                    <a href="<?php echo admin_url('options-permalink.php'); ?>" class="button button-small" style="margin-left:8px;">Flush Rewrite Rules</a>
                                    <p class="description" style="color:#c00;">After saving these settings, visit <a href="<?php echo admin_url('options-permalink.php'); ?>">Settings → Permalinks</a> and click Save to flush rewrite rules if the link still doesn't work.</p>
                                <?php endif; ?>
                                </p>
                            <?php else: ?>
                                <p class="description">No domain configured — full-length ICS links will be sent in SMS.</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>

                <?php submit_button(); ?>
            </form>

            <hr>
            <h2>Usage</h2>
            <p>Add this shortcode to any page or post:</p>
            <code>[booking_calendar]</code>
        </div>

        <script>
        jQuery(document).ready(function($) {
            // ── Media uploader ────────────────────────────────────────────────
            $('.wpbc-upload-btn').off('click').on('click', function(e) {
                e.preventDefault();
                var targetInput = $(this).data('target');
                var frame = wp.media({ title: 'Select or Upload Logo', multiple: false });
                frame.on('select', function() {
                    var url = frame.state().get('selection').first().toJSON().url;
                    $('#' + targetInput).val(url);
                });
                frame.open();
            });

            // ── Color picker ──────────────────────────────────────────────────
            if ($.fn.wpColorPicker) {
                $('.wpbc-color-picker').wpColorPicker();
            }
        });
        </script>
        <?php
    }

    /**
     * Availability Page - Calendar-based slot blocking
     */
    public function availability_page() {
        global $wpdb;

        $time_slots = $this->get_time_slots();
        $available_days = $this->get_available_days();

        // Get all blocks
        $blocks = $wpdb->get_results("SELECT * FROM {$this->blocks_table} ORDER BY block_date ASC");
        $blocks_by_date = array();
        foreach ($blocks as $block) {
            if (!isset($blocks_by_date[$block->block_date])) {
                $blocks_by_date[$block->block_date] = array();
            }
            $blocks_by_date[$block->block_date][] = $block->block_time;
        }

        // Get all confirmed bookings
        $bookings = $wpdb->get_results(
            "SELECT booking_date, booking_time, customer_name FROM {$this->table_name} WHERE status = 'confirmed'"
        );
        $bookings_by_date = array();
        foreach ($bookings as $booking) {
            if (!isset($bookings_by_date[$booking->booking_date])) {
                $bookings_by_date[$booking->booking_date] = array();
            }
            $bookings_by_date[$booking->booking_date][$booking->booking_time] = $booking->customer_name;
        }

        ?>
        <div class="wrap">
            <h1>Availability</h1>
            <p class="description">Configure your availability schedule and manage individual time slots.</p>

            <!-- Availability Schedule Settings -->
            <form method="post" action="options.php" style="margin-bottom: 30px;">
                <?php settings_fields('wp_booking_calendar'); ?>

                <div style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; border-radius: 4px; margin-bottom: 20px;">
                    <h2 style="margin-top: 0;">Availability Schedule</h2>
                    <p class="description">Choose which days you accept bookings, and set time ranges that automatically generate 1-hour slots.</p>

                    <?php
                    $saved_days       = $this->get_available_days();
                    $saved_ranges_raw = get_option('wpbc_time_ranges', '');
                    $saved_ranges     = (!empty($saved_ranges_raw)) ? json_decode($saved_ranges_raw, true) : array();
                    if (empty($saved_ranges)) {
                        $saved_ranges = array(
                            array('start' => '09:00', 'end' => '12:00'),
                            array('start' => '13:00', 'end' => '17:00'),
                        );
                    }
                    $day_labels = array(1=>'Mon',2=>'Tue',3=>'Wed',4=>'Thu',5=>'Fri',6=>'Sat',7=>'Sun');
                    ?>

                    <table class="form-table">
                        <tr>
                            <th scope="row">Available Days</th>
                            <td>
                                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                                <?php foreach ($day_labels as $num => $label): $active = in_array($num, $saved_days); ?>
                                    <label class="wpbc-day-label" data-day="<?php echo $num; ?>"
                                           style="display:flex;align-items:center;gap:5px;padding:6px 14px;border:2px solid <?php echo $active ? '#667eea' : '#ddd'; ?>;border-radius:6px;cursor:pointer;font-weight:600;background:<?php echo $active ? '#f0f4ff' : '#fff'; ?>;">
                                        <input type="checkbox" class="wpbc-day-cb" value="<?php echo $num; ?>"
                                               <?php checked($active); ?> style="margin:0;">
                                        <?php echo $label; ?>
                                    </label>
                                <?php endforeach; ?>
                                </div>
                                <input type="hidden" name="wpbc_available_days" id="wpbc_available_days_input"
                                       value="<?php echo esc_attr(json_encode($saved_days)); ?>">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Time Ranges</th>
                            <td>
                                <div id="wpbc-time-ranges">
                                <?php foreach ($saved_ranges as $range): ?>
                                    <div class="wpbc-range-row" style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
                                        <input type="time" class="wpbc-range-start" value="<?php echo esc_attr($range['start']); ?>"
                                               style="padding:6px 10px;border:1px solid #ccc;border-radius:4px;font-size:14px;">
                                        <span style="color:#6b7280;font-weight:600;">to</span>
                                        <input type="time" class="wpbc-range-end" value="<?php echo esc_attr($range['end']); ?>"
                                               style="padding:6px 10px;border:1px solid #ccc;border-radius:4px;font-size:14px;">
                                        <button type="button" class="button wpbc-remove-range">✕</button>
                                    </div>
                                <?php endforeach; ?>
                                </div>
                                <button type="button" class="button" id="wpbc-add-range">+ Add Time Range</button>
                                <input type="hidden" name="wpbc_time_ranges" id="wpbc_time_ranges_input"
                                       value="<?php echo esc_attr(json_encode($saved_ranges)); ?>">
                                <p class="description" style="margin-top:8px;">
                                    Each range creates 1-hour slots. <strong>09:00 → 12:00</strong> = 9:00 AM, 10:00 AM, 11:00 AM.
                                    A gap (e.g. end at 12:00, start again at 13:00) skips that hour.
                                </p>
                                <div style="margin-top:10px;padding:10px 14px;background:#f0f4ff;border-radius:6px;border:1px solid #c7d2fe;">
                                    <strong style="font-size:13px;color:#374151;">Current slots:</strong>
                                    <div style="margin-top:6px;display:flex;flex-wrap:wrap;gap:6px;" id="wpbc-preview-tags">
                                    <?php foreach ($this->get_time_slots() as $slot): ?>
                                        <span style="background:#667eea;color:white;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;"><?php echo esc_html($slot); ?></span>
                                    <?php endforeach; ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </table>

                    <?php submit_button('Save Availability Schedule'); ?>
                </div>
            </form>

            <!-- Calendar-Based Slot Management -->
            <h2>Manage Individual Time Slots</h2>
            <p class="description">Use the calendar below to block or unblock specific time slots.</p>

            <div class="wpbc-admin-availability-shell">
                <div class="wpbc-card wpbc-admin-availability-card">
                    <div class="wpbc-card-body">
                        <div class="wpbc-date-time-grid">
                            <div class="wpbc-calendar-col">
                                <input type="text" id="wpbc-availability-calendar" readonly>
                                <div class="wpbc-admin-legend">
                                    <span><i class="wpbc-admin-dot wpbc-admin-dot-open"></i>Open</span>
                                    <span><i class="wpbc-admin-dot wpbc-admin-dot-limited"></i>Limited</span>
                                    <span><i class="wpbc-admin-dot wpbc-admin-dot-booked"></i>Full/Blocked</span>
                                </div>
                            </div>
                            <div class="wpbc-slots-col" id="wpbc-slots-panel">
                                <div class="wpbc-slots-empty-state">
                                    <span>&#128197;</span>
                                    <p>Select a date to manage time slots</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <link rel="stylesheet" href="<?php echo esc_url(plugins_url('css/booking-calendar.css', __FILE__)); ?>">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script src="https://cdn.socket.io/4.5.4/socket.io.min.js"></script>
        <style>
            :root {
                --wpbc-accent-color: <?php echo esc_attr(get_option('wpbc_accent_color', '#2536eb')); ?>;
            }

            .wpbc-admin-availability-shell {
                max-width: 1120px;
                margin-top: 14px;
            }
            .wpbc-admin-availability-card {
                max-width: none;
            }
            #wpbc-availability-calendar {
                display: none;
            }
            .wpbc-admin-availability-card .wpbc-calendar-col .flatpickr-calendar {
                margin: 0 auto;
            }
            .wpbc-admin-legend {
                display: flex;
                gap: 14px;
                align-items: center;
                justify-content: center;
                margin-top: 12px;
                font-size: 12px;
                color: #4b5563;
            }
            .wpbc-admin-legend span {
                display: inline-flex;
                align-items: center;
                gap: 6px;
            }
            .wpbc-admin-dot {
                width: 10px;
                height: 10px;
                border-radius: 999px;
                display: inline-block;
            }
            .wpbc-admin-dot-open { background: #10b981; }
            .wpbc-admin-dot-limited { background: #f59e0b; }
            .wpbc-admin-dot-booked { background: #ef4444; }
            .wpbc-admin-slots-head {
                display: flex;
                align-items: center;
                justify-content: space-between;
                margin-bottom: 12px;
                gap: 10px;
                flex-wrap: wrap;
            }
            .wpbc-admin-slots-actions {
                display: flex;
                gap: 8px;
            }
            .wpbc-admin-slots-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 8px;
                max-height: 340px;
                overflow-y: auto;
            }
            .wpbc-time-slot.wpbc-admin-slot {
                text-align: left;
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 12px;
                padding: 10px 12px;
            }
            .wpbc-time-slot.wpbc-admin-slot:hover:not(:disabled) {
                border-color: var(--wpbc-accent-color, #2536eb);
            }
            .wpbc-time-slot.wpbc-admin-slot.wpbc-admin-booked {
                background: #eef2ff;
                border-color: #c7d2fe;
                color: #1e3a8a;
                cursor: not-allowed;
                text-decoration: none;
            }
            .wpbc-time-slot.wpbc-admin-slot.wpbc-admin-blocked {
                background: #fef2f2;
                border-color: #fecaca;
                color: #991b1b;
                text-decoration: none;
            }
            .wpbc-time-slot.wpbc-admin-slot.wpbc-admin-open {
                background: #fff;
                border-color: #d1d5db;
                color: #111827;
            }
            .wpbc-admin-slot-status {
                font-size: 11px;
                font-weight: 700;
                letter-spacing: 0.04em;
                text-transform: uppercase;
            }
            .wpbc-admin-slot-status-open { color: #047857; }
            .wpbc-admin-slot-status-booked { color: #1d4ed8; }
            .wpbc-admin-slot-status-blocked { color: #b91c1c; }
            .wpbc-admin-slot-customer {
                font-size: 11px;
                color: #64748b;
                margin-top: 2px;
            }
            @media (max-width: 900px) {
                .wpbc-admin-slots-grid {
                    grid-template-columns: 1fr;
                }
            }
        </style>
        <script>
        jQuery(document).ready(function($) {
            const timeSlots = <?php echo json_encode($time_slots); ?>;
            const availableDays = <?php echo json_encode($available_days); ?>;
            const blocksByDate = <?php echo json_encode($blocks_by_date); ?>;
            const bookingsByDate = <?php echo json_encode($bookings_by_date); ?>;
            const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
            const nonce = '<?php echo wp_create_nonce('wpbc_admin_nonce'); ?>';
            let selectedDate = null;
            let calendar = null;

            // WebSocket configuration
            const wsUrl = '<?php echo esc_js(get_option('wpbc_websocket_url', 'http://localhost:3000')); ?>';
            const wsToken = '<?php echo esc_js(get_option('wpbc_websocket_token', '')); ?>';
            const siteId = '<?php echo esc_js(get_option('wpbc_site_id', sanitize_title(get_bloginfo('name')))); ?>';
            const calendarId = '<?php echo esc_js(get_option('wpbc_calendar_id', 'main-calendar')); ?>';
            let socket = null;

            // Initialize WebSocket
            function initWebSocket() {
                if (typeof io === 'undefined') {
                    console.log('[Availability] Socket.io not available');
                    return;
                }
                try {
                    socket = io(wsUrl, {
                        transports: ['websocket', 'polling'],
                        reconnection: true,
                        auth: { token: wsToken }
                    });
                    socket.on('connect', function() {
                        console.log('[Availability] WebSocket connected');
                        socket.emit('join-calendar', { siteId: siteId, calendarId: calendarId, userId: 'admin' });
                    });
                    socket.on('disconnect', function() {
                        console.log('[Availability] WebSocket disconnected');
                    });
                } catch (e) {
                    console.log('[Availability] WebSocket error:', e);
                }
            }
            initWebSocket();

            function availabilityLevelForDate(dateStr) {
                const bookings = bookingsByDate[dateStr] || {};
                const blocks = blocksByDate[dateStr] || [];
                const bookedCount = Object.keys(bookings).length;
                const blockedCount = blocks.length;
                const openCount = Math.max(timeSlots.length - bookedCount - blockedCount, 0);

                if (openCount <= 0) return 'booked';
                if (openCount <= 2) return 'limited';
                return 'open';
            }

            function paintCalendarDays() {
                if (!calendar) return;
                requestAnimationFrame(function() {
                    $(calendar.calendarContainer).find('.flatpickr-day').each(function() {
                        if (!this.dateObj) return;
                        if (this.classList.contains('flatpickr-disabled')) return;
                        const y = this.dateObj.getFullYear();
                        const m = String(this.dateObj.getMonth() + 1).padStart(2, '0');
                        const d = String(this.dateObj.getDate()).padStart(2, '0');
                        const dateStr = y + '-' + m + '-' + d;
                        this.setAttribute('data-availability', availabilityLevelForDate(dateStr));
                    });
                });
            }

            // Broadcast slot blocked/unblocked via WebSocket
            function broadcastSlotChange(date, time, blocked) {
                if (socket && socket.connected) {
                    if (blocked) {
                        socket.emit('slot-booked', {
                            siteId: siteId,
                            calendarId: calendarId,
                            date: date,
                            time: time,
                            userId: 'admin',
                            bookingId: 'block'
                        });
                    } else {
                        socket.emit('slot-available', {
                            siteId: siteId,
                            calendarId: calendarId,
                            date: date,
                            time: time
                        });
                    }
                }
            }

            // Initialize Flatpickr
            calendar = flatpickr('#wpbc-availability-calendar', {
                inline: true,
                minDate: 'today',
                maxDate: new Date().fp_incr(120),
                enable: [function(date) {
                    var jsDay = date.getDay();
                    var phpDay = jsDay === 0 ? 7 : jsDay;
                    return availableDays.indexOf(phpDay) !== -1;
                }],
                onReady: function() {
                    paintCalendarDays();
                },
                onMonthChange: function() {
                    paintCalendarDays();
                },
                onChange: function(selectedDates, dateStr) {
                    selectedDate = dateStr;
                    renderSlots(dateStr);
                    paintCalendarDays();
                }
            });

            function renderSlots(date) {
                const blocks = blocksByDate[date] || [];
                const bookings = bookingsByDate[date] || {};
                const panel = $('#wpbc-slots-panel');

                // Format date for display
                const parts = date.split('-');
                const dateObj = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
                const formattedDate = dateObj.toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                });

                let html = `
                    <div class="wpbc-admin-slots-head">
                        <div>
                            <h3 style="margin: 0; font-size: 18px; color: #374151;">${formattedDate}</h3>
                            <p style="margin: 5px 0 0 0; font-size: 13px; color: #6b7280;">Click open slots to block/unblock</p>
                        </div>
                        <div class="wpbc-admin-slots-actions">
                            <button type="button" class="button" style="border-color:#fecaca;color:#b91c1c;" onclick="blockAllSlots('${date}')">
                                Block All
                            </button>
                            <button type="button" class="button" style="border-color:#bbf7d0;color:#047857;" onclick="unblockAllSlots('${date}')">
                                Unblock All
                            </button>
                        </div>
                    </div>
                    <div class="wpbc-admin-slots-grid">
                `;

                timeSlots.forEach(function(time) {
                    const isBooked = bookings.hasOwnProperty(time);
                    const isBlocked = blocks.indexOf(time) !== -1;
                    let statusClass = 'wpbc-admin-open';
                    let statusText = 'Available';
                    let customerName = '';
                    let statusTextClass = 'wpbc-admin-slot-status-open';

                    if (isBooked) {
                        statusClass = 'wpbc-admin-booked';
                        statusText = 'Booked';
                        customerName = bookings[time];
                        statusTextClass = 'wpbc-admin-slot-status-booked';
                    } else if (isBlocked) {
                        statusClass = 'wpbc-admin-blocked';
                        statusText = 'Blocked';
                        statusTextClass = 'wpbc-admin-slot-status-blocked';
                    }

                    const clickHandler = isBooked ? '' : `onclick="toggleBlock('${date}', '${time}')"` ;
                    const disabledAttr = isBooked ? 'disabled' : '';

                    html += `
                        <button type="button" class="wpbc-time-slot wpbc-admin-slot ${statusClass}" ${disabledAttr} ${clickHandler}>
                            <div>
                                <div>${time}</div>
                                ${customerName ? `<div class="wpbc-admin-slot-customer">${customerName}</div>` : ''}
                            </div>
                            <span class="wpbc-admin-slot-status ${statusTextClass}">${statusText}</span>
                        </button>
                    `;
                });

                html += '</div>';
                panel.html(html);
            }

            // Toggle block for a single slot
            window.toggleBlock = function(date, time) {
                $.post(ajaxUrl, {
                    action: 'wpbc_toggle_block',
                    nonce: nonce,
                    date: date,
                    time: time
                }, function(response) {
                    if (response.success) {
                        // Update local data
                        if (!blocksByDate[date]) blocksByDate[date] = [];
                        if (response.data.blocked) {
                            if (blocksByDate[date].indexOf(time) === -1) {
                                blocksByDate[date].push(time);
                            }
                        } else {
                            const idx = blocksByDate[date].indexOf(time);
                            if (idx > -1) blocksByDate[date].splice(idx, 1);
                        }
                        renderSlots(date);
                        paintCalendarDays();

                        // Broadcast via WebSocket
                        broadcastSlotChange(date, time, response.data.blocked);
                    }
                });
            };

            // Block all slots for a date
            window.blockAllSlots = function(date) {
                const bookings = bookingsByDate[date] || {};
                const unbookedSlots = timeSlots.filter(t => !bookings.hasOwnProperty(t));

                $.post(ajaxUrl, {
                    action: 'wpbc_toggle_block',
                    nonce: nonce,
                    date: date,
                    time: '',
                    block_all: 1
                }, function(response) {
                    if (response.success) {
                        blocksByDate[date] = unbookedSlots.slice();
                        renderSlots(date);
                        paintCalendarDays();

                        // Broadcast each blocked slot via WebSocket
                        unbookedSlots.forEach(function(time) {
                            broadcastSlotChange(date, time, true);
                        });
                    }
                });
            };

            // Unblock all slots for a date
            window.unblockAllSlots = function(date) {
                const previouslyBlocked = (blocksByDate[date] || []).slice();

                $.post(ajaxUrl, {
                    action: 'wpbc_toggle_block',
                    nonce: nonce,
                    date: date,
                    time: '',
                    unblock_all: 1
                }, function(response) {
                    if (response.success) {
                        blocksByDate[date] = [];
                        renderSlots(date);
                        paintCalendarDays();

                        // Broadcast each unblocked slot via WebSocket
                        previouslyBlocked.forEach(function(time) {
                            broadcastSlotChange(date, time, false);
                        });
                    }
                });
            };

            // ── Availability Schedule Management ──────────────────────────────
            function syncDaysInput() {
                var selected = [];
                $('.wpbc-day-cb:checked').each(function() { selected.push(parseInt($(this).val())); });
                $('#wpbc_available_days_input').val(JSON.stringify(selected));
            }
            $(document).on('change', '.wpbc-day-cb', function() {
                var $label = $(this).closest('.wpbc-day-label');
                if ($(this).is(':checked')) {
                    $label.css({ 'border-color': '#667eea', 'background': '#f0f4ff' });
                } else {
                    $label.css({ 'border-color': '#ddd', 'background': '#fff' });
                }
                syncDaysInput();
            });

            function pad(n) { return String(n).padStart(2, '0'); }

            function toMinutes(hhmm) {
                var p = hhmm.split(':');
                return parseInt(p[0]) * 60 + parseInt(p[1]);
            }

            function minutesToLabel(m) {
                var h = Math.floor(m / 60), min = m % 60;
                var ampm = h < 12 ? 'AM' : 'PM';
                var h12  = h % 12 === 0 ? 12 : h % 12;
                return h12 + ':' + pad(min) + ' ' + ampm;
            }

            function updatePreview() {
                var slots = [];
                $('#wpbc-time-ranges .wpbc-range-row').each(function() {
                    var s = toMinutes($(this).find('.wpbc-range-start').val() || '00:00');
                    var e = toMinutes($(this).find('.wpbc-range-end').val()   || '00:00');
                    for (var m = s; m < e; m += 60) {
                        var label = minutesToLabel(m);
                        if (slots.indexOf(label) === -1) slots.push(label);
                    }
                });
                var $tags = $('#wpbc-preview-tags');
                $tags.empty();
                if (!slots.length) {
                    $tags.append('<em style="color:#9ca3af;">No slots</em>');
                } else {
                    slots.forEach(function(s) {
                        $tags.append('<span style="background:#667eea;color:white;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;">' + s + '</span>');
                    });
                }
            }

            function syncRangesInput() {
                var ranges = [];
                $('#wpbc-time-ranges .wpbc-range-row').each(function() {
                    var s = $(this).find('.wpbc-range-start').val();
                    var e = $(this).find('.wpbc-range-end').val();
                    if (s && e) ranges.push({ start: s, end: e });
                });
                $('#wpbc_time_ranges_input').val(JSON.stringify(ranges));
                updatePreview();
            }

            function makeRangeRow(start, end) {
                start = start || '09:00'; end = end || '10:00';
                return $('<div class="wpbc-range-row" style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">' +
                    '<input type="time" class="wpbc-range-start" value="' + start + '" style="padding:6px 10px;border:1px solid #ccc;border-radius:4px;font-size:14px;">' +
                    '<span style="color:#6b7280;font-weight:600;">to</span>' +
                    '<input type="time" class="wpbc-range-end" value="' + end + '" style="padding:6px 10px;border:1px solid #ccc;border-radius:4px;font-size:14px;">' +
                    '<button type="button" class="button wpbc-remove-range">✕</button>' +
                    '</div>');
            }

            $('#wpbc-time-ranges').on('change', 'input[type="time"]', syncRangesInput);

            $('#wpbc-time-ranges').on('click', '.wpbc-remove-range', function() {
                $(this).closest('.wpbc-range-row').remove();
                syncRangesInput();
            });

            $('#wpbc-add-range').on('click', function() {
                var $last = $('#wpbc-time-ranges .wpbc-range-row').last();
                var defStart = '09:00', defEnd = '10:00';
                if ($last.length) {
                    var lastEnd = $last.find('.wpbc-range-end').val();
                    if (lastEnd) {
                        defStart = lastEnd;
                        var parts = lastEnd.split(':');
                        defEnd = pad((parseInt(parts[0]) + 1) % 24) + ':' + parts[1];
                    }
                }
                $('#wpbc-time-ranges').append(makeRangeRow(defStart, defEnd));
                syncRangesInput();
            });

            // Sync hidden fields before form submits
            $('form').on('submit', function() { syncDaysInput(); syncRangesInput(); });

            // Initial preview render
            updatePreview();

            paintCalendarDays();
        });
        </script>
        <?php
    }

    /**
     * Email Testing Page for debugging reminders
     */
    public function email_testing_page() {
        global $wpdb;

        // Get all confirmed bookings
        $bookings = $wpdb->get_results(
            "SELECT * FROM {$this->table_name} WHERE status = 'confirmed' ORDER BY booking_date ASC, booking_time ASC"
        );

        // Get current simulated time if set
        $simulated_time = get_option('wpbc_simulated_time', '');
        $current_time = $simulated_time ? $simulated_time : current_time('Y-m-d H:i:s');
        ?>
        <div class="wrap">
            <h1>Email Reminder Testing</h1>
            <p>Use this page to test email reminders without waiting for the real cron job.</p>

            <hr>

            <!-- Date/Time Simulator -->
            <h2>Date/Time Simulator</h2>
            <p>Simulate a different current time to test reminder triggers. The reminder system checks for bookings within 24 hours and 1 hour of the "current" time.</p>

            <table class="form-table">
                <tr>
                    <th scope="row">Current Server Time</th>
                    <td><code><?php echo current_time('Y-m-d H:i:s'); ?></code></td>
                </tr>
                <tr>
                    <th scope="row">Simulated Time</th>
                    <td>
                        <input type="datetime-local" id="wpbc-simulated-time"
                               value="<?php echo $simulated_time ? date('Y-m-d\TH:i', strtotime($simulated_time)) : ''; ?>"
                               style="width: 250px;">
                        <button type="button" class="button" id="wpbc-set-simulated-time">Set Simulated Time</button>
                        <button type="button" class="button" id="wpbc-clear-simulated-time">Clear (Use Real Time)</button>
                        <?php if ($simulated_time): ?>
                            <p class="description" style="color: #d63638;">Simulated time is active: <strong><?php echo $simulated_time; ?></strong></p>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>

            <hr>

            <!-- Manual Trigger -->
            <h2>Manual Reminder Check</h2>
            <p>Trigger the reminder email check manually (same as what the cron job does).</p>
            <button type="button" class="button button-primary" id="wpbc-trigger-reminders">
                Run Reminder Check Now
            </button>
            <div id="wpbc-trigger-result" style="margin-top: 10px;"></div>

            <hr>

            <!-- Test Specific Booking -->
            <h2>Send Test Reminder for Specific Booking</h2>
            <p>Send a test reminder email for any booking (ignores the reminder_sent flags).</p>

            <?php if (empty($bookings)): ?>
                <p><em>No confirmed bookings found. Create a booking first to test reminders.</em></p>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped" style="max-width: 900px;">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Date & Time</th>
                            <th>Customer</th>
                            <th>24h Sent</th>
                            <th>1h Sent</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bookings as $booking): ?>
                            <tr>
                                <td><?php echo esc_html($booking->id); ?></td>
                                <td>
                                    <?php echo esc_html(date('M j, Y', strtotime($booking->booking_date))); ?>
                                    at <?php echo esc_html($booking->booking_time); ?>
                                </td>
                                <td>
                                    <?php echo esc_html($booking->customer_name); ?><br>
                                    <small><?php echo esc_html($booking->customer_email); ?></small>
                                </td>
                                <td>
                                    <?php if (!empty($booking->reminder_24h_sent)): ?>
                                        <span style="color: green;">Yes</span>
                                    <?php else: ?>
                                        <span style="color: #999;">No</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($booking->reminder_1h_sent)): ?>
                                        <span style="color: green;">Yes</span>
                                    <?php else: ?>
                                        <span style="color: #999;">No</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button type="button" class="button wpbc-send-test-reminder"
                                            data-booking-id="<?php echo esc_attr($booking->id); ?>"
                                            data-reminder-type="24h">
                                        Send 24h Test
                                    </button>
                                    <button type="button" class="button wpbc-send-test-reminder"
                                            data-booking-id="<?php echo esc_attr($booking->id); ?>"
                                            data-reminder-type="1h">
                                        Send 1h Test
                                    </button>
                                    <button type="button" class="button wpbc-reset-reminder-flags"
                                            data-booking-id="<?php echo esc_attr($booking->id); ?>">
                                        Reset Flags
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <hr>

            <!-- Debug Log -->
            <h2>Debug Information</h2>
            <table class="form-table">
                <tr>
                    <th>Next Scheduled Cron</th>
                    <td>
                        <?php
                        $next = wp_next_scheduled('wpbc_send_reminders');
                        if ($next) {
                            echo date('Y-m-d H:i:s', $next) . ' (in ' . human_time_diff(time(), $next) . ')';
                        } else {
                            echo '<span style="color: #d63638;">Not scheduled!</span> ';
                            echo '<button type="button" class="button" id="wpbc-schedule-cron">Schedule Now</button>';
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <th>WP Cron Status</th>
                    <td>
                        <?php echo defined('DISABLE_WP_CRON') && DISABLE_WP_CRON ? '<span style="color: #d63638;">Disabled (DISABLE_WP_CRON is true)</span>' : '<span style="color: green;">Enabled</span>'; ?>
                    </td>
                </tr>
                <tr>
                    <th>Missing Cancel Tokens</th>
                    <td>
                        <?php
                        $missing_tokens = $wpdb->get_var(
                            "SELECT COUNT(*) FROM {$this->table_name} WHERE cancel_token = '' OR cancel_token IS NULL"
                        );
                        if ($missing_tokens > 0) {
                            echo '<span style="color: #d63638;">' . $missing_tokens . ' bookings without cancel tokens</span> ';
                            echo '<button type="button" class="button" id="wpbc-fix-tokens">Generate Missing Tokens</button>';
                        } else {
                            echo '<span style="color: green;">All bookings have cancel tokens</span>';
                        }
                        ?>
                    </td>
                </tr>
            </table>
        </div>

        <script>
        jQuery(document).ready(function($) {
            var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
            var nonce = '<?php echo wp_create_nonce('wpbc_admin_nonce'); ?>';

            // Set simulated time
            $('#wpbc-set-simulated-time').on('click', function() {
                var simTime = $('#wpbc-simulated-time').val();
                if (!simTime) {
                    alert('Please select a date and time first.');
                    return;
                }

                $.post(ajaxurl, {
                    action: 'wpbc_set_simulated_time',
                    nonce: nonce,
                    time: simTime.replace('T', ' ') + ':00'
                }, function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert('Error: ' + response.data);
                    }
                });
            });

            // Clear simulated time
            $('#wpbc-clear-simulated-time').on('click', function() {
                $.post(ajaxurl, {
                    action: 'wpbc_clear_simulated_time',
                    nonce: nonce
                }, function(response) {
                    location.reload();
                });
            });

            // Trigger reminder check
            $('#wpbc-trigger-reminders').on('click', function() {
                var $btn = $(this);
                var $result = $('#wpbc-trigger-result');

                $btn.prop('disabled', true).text('Running...');
                $result.html('<p>Checking for reminders to send...</p>');

                $.post(ajaxurl, {
                    action: 'wpbc_trigger_reminder_check',
                    nonce: nonce
                }, function(response) {
                    $btn.prop('disabled', false).text('Run Reminder Check Now');
                    if (response.success && response.data.details) {
                        var details = response.data.details.join('<br>');
                        $result.html('<div class="notice notice-success" style="padding:10px;"><pre style="margin:0;white-space:pre-wrap;">' + details + '</pre></div>');
                        // Reload page after 2 seconds to show updated flags
                        setTimeout(function() { location.reload(); }, 2000);
                    } else {
                        $result.html('<div class="notice notice-error" style="padding:10px;"><p>Error: ' + (response.data || 'Unknown error') + '</p></div>');
                    }
                });
            });

            // Send test reminder
            $('.wpbc-send-test-reminder').on('click', function() {
                var $btn = $(this);
                var bookingId = $btn.data('booking-id');
                var reminderType = $btn.data('reminder-type');

                $btn.prop('disabled', true).text('Sending...');

                $.post(ajaxurl, {
                    action: 'wpbc_send_test_reminder',
                    nonce: nonce,
                    booking_id: bookingId,
                    type: reminderType
                }, function(response) {
                    $btn.prop('disabled', false).text('Send ' + reminderType + ' Test');
                    if (response.success) {
                        alert('Test reminder sent successfully!');
                    } else {
                        alert('Error: ' + response.data);
                    }
                });
            });

            // Reset reminder flags
            $('.wpbc-reset-reminder-flags').on('click', function() {
                var $btn = $(this);
                var bookingId = $btn.data('booking-id');

                $.post(ajaxurl, {
                    action: 'wpbc_reset_reminder_flags',
                    nonce: nonce,
                    booking_id: bookingId
                }, function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert('Error: ' + response.data);
                    }
                });
            });

            // Schedule cron
            $('#wpbc-schedule-cron').on('click', function() {
                $.post(ajaxurl, {
                    action: 'wpbc_schedule_reminder_cron',
                    nonce: nonce
                }, function(response) {
                    location.reload();
                });
            });

            // Fix missing tokens
            $('#wpbc-fix-tokens').on('click', function() {
                var $btn = $(this);
                $btn.prop('disabled', true).text('Fixing...');

                $.post(ajaxurl, {
                    action: 'wpbc_fix_missing_tokens',
                    nonce: nonce
                }, function(response) {
                    if (response.success) {
                        alert('Fixed ' + response.data.fixed + ' bookings.');
                        location.reload();
                    } else {
                        alert('Error: ' + response.data);
                        $btn.prop('disabled', false).text('Generate Missing Tokens');
                    }
                });
            });
        });
        </script>
        <?php
    }

    /**
     * Enqueue frontend assets (Flatpickr, Socket.io, plugin CSS/JS)
     */
    public function enqueue_assets() {
        if (!is_singular() || !has_shortcode(get_post()->post_content, 'booking_calendar')) {
            return;
        }

        // Flatpickr CSS & JS
        wp_enqueue_style('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css');
        wp_enqueue_script('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.js', array(), null, true);

        // Socket.io
        wp_enqueue_script('socket-io', 'https://cdn.socket.io/4.6.1/socket.io.min.js', array(), null, true);

        // Plugin assets - use filemtime for cache busting
        $css_version = filemtime(plugin_dir_path(__FILE__) . 'css/booking-calendar.css');
        $js_version = filemtime(plugin_dir_path(__FILE__) . 'js/booking-calendar.js');
        wp_enqueue_style('wpbc-style', plugin_dir_url(__FILE__) . 'css/booking-calendar.css', array(), $css_version);
        wp_enqueue_script('wpbc-script', plugin_dir_url(__FILE__) . 'js/booking-calendar.js', array('jquery', 'flatpickr', 'socket-io'), $js_version, true);

        // Socket.io needs http:// not ws://
        $ws_url = get_option('wpbc_websocket_url', 'http://162.0.220.48:3000');
        $ws_url = preg_replace('/^ws:\/\//', 'http://', $ws_url);
        $ws_url = preg_replace('/^wss:\/\//', 'https://', $ws_url);
        $ws_token = trim((string) get_option('wpbc_websocket_token', ''));

        wp_localize_script('wpbc-script', 'wpbcSettings', array(
            'websocketUrl' => $ws_url,
            'websocketToken' => $ws_token,
            'siteId'       => get_option('wpbc_site_id', sanitize_title(get_bloginfo('name'))),
            'calendarId'   => get_option('wpbc_calendar_id', 'main-calendar'),
            'userId'       => 'user-' . wp_generate_uuid4(),
            'ajaxUrl'      => admin_url('admin-ajax.php'),
            'nonce'        => wp_create_nonce('wpbc_booking_nonce'),
            'timeSlots'    => $this->get_time_slots(),
            'availableDays'=> $this->get_available_days(), // 1=Mon…7=Sun (PHP date N)
        ));
    }

    /**
     * Render the booking calendar (tab-based UI)
     */
    public function render_calendar($atts) {
        $atts = shortcode_atts(array(), $atts);

        $accent_color = get_option('wpbc_accent_color', '#2536eb');

        ob_start();
        ?>
        <style>
            :root {
                --wpbc-accent-color: <?php echo esc_attr($accent_color); ?>;
            }
        </style>
        <div class="wpbc-card">
          <div class="wpbc-tab-bar" id="wpbc-tab-bar">
            <button class="wpbc-tab active" data-tab="0">
              <span class="wpbc-tab-num">1</span> Date &amp; Time
            </button>
            <button class="wpbc-tab" data-tab="1">
              <span class="wpbc-tab-num">2</span> Your Info
            </button>
          </div>

          <div class="wpbc-card-body">

            <div class="wpbc-status-bar">
              <span class="wpbc-connection-status wpbc-status-connecting" id="wpbc-connection-status">Connecting...</span>
              <span class="wpbc-viewer-count" id="wpbc-viewer-count">0 viewing</span>
            </div>

            <!-- Tab 0: Date + Time -->
            <div class="wpbc-tab-panel active" data-panel="0">
              <div class="wpbc-date-time-grid">
                <div class="wpbc-calendar-col">
                  <input type="text" id="wpbc-calendar" readonly>
                </div>
                <div class="wpbc-slots-col" id="wpbc-slots-col">
                  <div class="wpbc-slots-empty-state">
                    <span>&#128197;</span>
                    <p>Select a date to see available times</p>
                  </div>
                </div>
              </div>
              <div class="wpbc-continue-row">
                <button class="wpbc-continue-btn" id="wpbc-continue-btn" disabled>Continue &#8594;</button>
              </div>
            </div>

            <!-- Tab 1: Contact Form -->
            <div class="wpbc-tab-panel" data-panel="1">
              <div class="wpbc-booking-pill" id="wpbc-booking-pill">
                <div>
                  <div class="wpbc-pill-label">YOUR SELECTED TIME</div>
                  <div class="wpbc-pill-value">
                    <span id="wpbc-summary-date"></span> &middot; <span id="wpbc-summary-time"></span>
                  </div>
                </div>
                <button type="button" class="wpbc-change-btn" id="wpbc-change-btn">Change</button>
              </div>
              <form id="wpbc-booking-form">
                <div class="wpbc-form-group">
                  <label for="wpbc-name">Full Name <span class="wpbc-required">*</span></label>
                  <input type="text" id="wpbc-name" name="name" required placeholder="Jane Smith">
                </div>
                <div class="wpbc-form-group">
                  <label for="wpbc-email">Email Address <span class="wpbc-required">*</span></label>
                  <input type="email" id="wpbc-email" name="email" required placeholder="jane@example.com">
                </div>
                <div class="wpbc-form-group">
                  <label for="wpbc-phone">Phone Number</label>
                  <input type="tel" id="wpbc-phone" name="phone" placeholder="+1 (555) 000-0000" autocomplete="tel" inputmode="tel">
                </div>
                <div class="wpbc-form-group">
                  <label for="wpbc-address">Address</label>
                  <textarea id="wpbc-address" name="address" rows="2" placeholder="123 Main St, City, State"></textarea>
                </div>
                <button type="submit" class="wpbc-submit-btn">Confirm Booking &#8594;</button>
                <p class="wpbc-form-footnote">You'll receive a confirmation email shortly after booking.</p>
              </form>
            </div>

            <!-- Tab 2: Confirmation -->
            <div class="wpbc-tab-panel" data-panel="2">
              <div class="wpbc-confirmation">
                <div class="wpbc-confirm-icon">&#10003;</div>
                <h2>You're confirmed.</h2>
                <p class="wpbc-confirm-ref">Confirmation #<span id="wpbc-confirm-id"></span></p>
                <div class="wpbc-confirm-details" id="wpbc-confirm-details"></div>
                <button type="button" class="wpbc-reset-btn" id="wpbc-reset-btn">Book another time</button>
              </div>
            </div>

          </div><!-- .wpbc-card-body -->
        </div><!-- .wpbc-card -->
        <?php
        return ob_get_clean();
    }

    /**
     * Get email header HTML
     * Replicates SEC_Survey_Email template structure for booking emails
     */
    private function get_booking_email_header() {
        $from_name = get_option('wpbc_email_from_name', get_bloginfo('name'));
        $logo_url = get_option('sec_email_logo_url', '');
        $gradient_start = sanitize_hex_color(get_option('sec_email_header_gradient_start', '#B8C7E6')) ?: '#B8C7E6';
        $gradient_end = sanitize_hex_color(get_option('sec_email_header_gradient_end', '#94B5F0')) ?: '#94B5F0';

        return '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="x-apple-disable-message-reformatting">
            <title>Booking Confirmation</title>
            <style>
                @import url("https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap");
                body { margin:0; padding:0; background:#f3f4f6; font-family:"DM Sans","Roboto",Arial,sans-serif; color:#253044; }
                .ma-wrap { width:100%; background:#f3f4f6; }
                .ma-card { width:600px; max-width:600px; background:#ffffff; border-radius:12px; overflow:hidden; border:1px solid #e7ebf3; }
                .ma-header { background:linear-gradient(135deg, ' . esc_attr($gradient_start) . ', ' . esc_attr($gradient_end) . '); padding:34px 20px; text-align:center; }
                .ma-logo-wordmark { font-family:"Roboto","DM Sans",Arial,sans-serif; font-size:42px; font-weight:700; letter-spacing:0.04em; color:#121A2D; line-height:1; text-transform:uppercase; }
                .ma-logo-wordmark span { color:#2F6BEB; }
                .ma-content { padding:32px 30px; font-family:"DM Sans","Roboto",Arial,sans-serif; color:#2f3c55; font-size:16px; line-height:1.62; }
                .ma-content a { color:#2536EB; text-decoration:none; }
                .ma-p { margin:0 0 14px 0; color:#334155; }
                .ma-footer { background:#f8fafc; padding:20px; color:#7b8498; font-size:12px; text-align:center; font-family:"DM Sans","Roboto",Arial,sans-serif; }
                @media only screen and (max-width:620px) {
                    .ma-card { width:100% !important; border-radius:0 !important; }
                    .ma-content { padding:24px 18px !important; }
                    .ma-logo-wordmark { font-size:34px !important; }
                }
            </style>
        </head>
        <body>
            <table class="ma-wrap" width="100%" cellpadding="0" cellspacing="0">
                <tr>
                    <td align="center" style="padding: 40px 20px;">
                        <table class="ma-card" width="600" cellpadding="0" cellspacing="0">
                            <tr>
                                <td align="center" class="ma-header">
                                    ' . (!empty($logo_url)
                                        ? '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr($from_name) . '" width="220" style="display:block; width:220px; max-width:220px; height:auto; max-height:68px; margin:0 auto;">'
                                        : '<div class="ma-logo-wordmark">Marketing<span>Aid</span></div>') . '
                                </td>
                            </tr>
                            <tr>
                                <td>';
    }

    /**
     * Get email footer HTML
     * Replicates SEC_Survey_Email template structure for booking emails
     */
    private function get_booking_email_footer() {
        return '                </td>
                            </tr>
                            <tr>
                                <td align="center" class="ma-footer">
                                    &copy; ' . date('Y') . ' ' . esc_html(get_bloginfo('name')) . '. All rights reserved.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </body>
        </html>';
    }

    /**
     * Convert plain text body to styled HTML paragraphs
     * Replicates SEC_Survey_Email::render_plaintext_body_html()
     * Now supports HTML blocks (like calendar links) mixed with plain text
     */
    private function render_booking_email_body($body) {
        $body = trim($body);
        if (empty($body)) {
            return '';
        }

        // Split by double line breaks to create paragraphs
        $chunks = preg_split("/\R{2,}/", $body);
        $html = '';

        foreach ($chunks as $chunk) {
            $chunk = trim($chunk);
            if (empty($chunk)) {
                continue;
            }

            // Check if this chunk contains HTML (calendar links, etc.)
            // Look for div, table, or other HTML tags
            if (preg_match('/<(div|table|a|img|p|span|h[1-6])\b[^>]*>/i', $chunk)) {
                // This is HTML content - output as-is without escaping
                $html .= $chunk;
            } else {
                // Plain text - escape HTML and auto-linkify URLs
                $escaped_chunk = esc_html($chunk);
                $escaped_chunk = preg_replace(
                    '#(https?://[^\s<]+)#i',
                    '<a href="$1" style="color:#2536EB; word-break:break-all; text-decoration:underline;">$1</a>',
                    $escaped_chunk
                );

                $html .= '<p class="ma-p">' . nl2br($escaped_chunk) . '</p>';
            }
        }

        return $html;
    }
}

// ============================================================================
// Plugin Update Checker - GitHub Integration
// ============================================================================

// Load update checker
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    // Prevent loading the autoloader multiple times
    if (!class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        require_once __DIR__ . '/vendor/autoload.php';
    }

    if (class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        $updateChecker = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
            'https://raw.githubusercontent.com/Hyveli/ma-calendar-dist/main/release.json',
            __FILE__,
            'ma-calendar'
        );

        // Optional: Enable debugging (comment out in production)
        // $updateChecker->getDebugInfo();

        // Force update check - must run after WordPress is fully loaded
        add_action('admin_init', function() use ($updateChecker) {
            if (isset($_GET['force_update_check']) && current_user_can('manage_options')) {
                delete_site_transient('update_plugins');
                $updateChecker->checkForUpdates();
                add_action('admin_notices', function() {
                    echo '<div class="notice notice-success is-dismissible"><p><strong>MA Calendar:</strong> Update check completed.</p></div>';
                });
                // Redirect to clean URL
                if (!headers_sent()) {
                    wp_redirect(admin_url('plugins.php'));
                    exit;
                }
            }
        });

        // Show detailed error messages in admin
        add_action('admin_notices', function() use ($updateChecker) {
            if (isset($_GET['puc_update_check_result']) && $_GET['puc_update_check_result'] === 'error' && isset($_GET['puc_slug']) && $_GET['puc_slug'] === 'ma-calendar') {
                // Try to get the last error
                $state = $updateChecker->getUpdateState();
                $errorMessage = 'Update check failed. ';

                if (is_wp_error($state)) {
                    $errorMessage .= $state->get_error_message();
                } else {
                    $errorMessage .= 'This usually means the release.json file is not accessible. Please ensure it exists at: <code>https://raw.githubusercontent.com/hyveli/ma-calendar/main/release.json</code>';
                }

                echo '<div class="notice notice-error is-dismissible">';
                echo '<p><strong>MA Calendar Update Check:</strong> ' . $errorMessage . '</p>';
                echo '</div>';
            }
        });
    }
}

// Initialize plugin
WP_Booking_Calendar::get_instance();
