<?php
/**
 * Plugin Name: MA Calendar
 * Plugin URI: https://github.com/hyveli/ma-calendar
 * Description: Calendar plugin for WordPress
 * Version: 1.0.0
 * Author: Hyveli
 * Author URI: https://github.com/hyveli
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ma-calendar
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('MA_CALENDAR_VERSION', '1.0.0');
define('MA_CALENDAR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MA_CALENDAR_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MA_CALENDAR_PLUGIN_FILE', __FILE__);

/**
 * Main Plugin Class
 */
if (!class_exists('MA_Calendar')) {
class MA_Calendar {

    /**
     * Instance of this class
     */
    private static $instance = null;

    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));

        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('init', array($this, 'init'));
    }

    /**
     * Load plugin text domain for translations
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'ma-calendar',
            false,
            dirname(plugin_basename(__FILE__)) . '/languages'
        );
    }

    /**
     * Initialize plugin
     */
    public function init() {
        // Add your initialization code here
    }

    /**
     * Activate plugin
     */
    public function activate() {
        // Activation code here
        flush_rewrite_rules();
    }

    /**
     * Deactivate plugin
     */
    public function deactivate() {
        // Deactivation code here
        flush_rewrite_rules();
    }
}

// Initialize the plugin
MA_Calendar::get_instance();
}

// ============================================================================
// Plugin Update Checker - GitHub Integration
// ============================================================================

// Load update checker directly to avoid Composer autoload recursion.
if (file_exists(__DIR__ . '/vendor/yahnis-elsts/plugin-update-checker/load-v5p6.php')) {
    if (!class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        require_once __DIR__ . '/vendor/yahnis-elsts/plugin-update-checker/load-v5p6.php';
    }

    if (class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        $updateChecker = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
            'https://raw.githubusercontent.com/hyveli/ma-calendar-dist/main/release.json',
            __FILE__,
            'ma-calendar'
        );

        // Force update check if URL parameter is present
        if (isset($_GET['force_update_check']) && current_user_can('manage_options')) {
            delete_site_transient('update_plugins');
            $updateChecker->checkForUpdates();
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>Update check completed.</p></div>';
            });
        }
    }
}
